/* Panel Frontend */
'use strict';

// ── Intercept 401 from any fetch call — reload to show lockscreen ─────────────
const _origFetch = window.fetch.bind(window);
window.fetch = async function(...args) {
  const res = await _origFetch(...args);
  if (res.status === 401) {
    // Clear any cached auth state and reload to show lockscreen
    try { await _origFetch('/api/panel/logout'); } catch (_) {}
    location.reload();
    return res;
  }
  return res;
};

const socket = io(window.BACKEND_URL, { transports: ['websocket', 'polling'], withCredentials: true, extraHeaders: { 'Bypass-Tunnel-Reminder': 'true' } });

let sessions = [];
let activeQrSession = null;
let qrRefreshInterval = null;
let uptimeInterval = null;
let startTime = Date.now();

// ── Backend Health Check ───────────────────────────────────────────────────────
let backendHealthy = true;
let healthCheckFailCount = 0;
const HEALTH_CHECK_INTERVAL = 30_000; // Every 30 seconds
const HEALTH_FAIL_THRESHOLD = 2; // Fail 2 times before showing error

async function checkBackendHealth() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000); // 8 second timeout
    
    const res = await fetch(window.BACKEND_URL + '/api/public/status', {
      signal: controller.signal,
      headers: { 'Bypass-Tunnel-Reminder': 'true' }
    });
    
    clearTimeout(timeoutId);
    
    if (res.ok) {
      // Backend is healthy
      if (!backendHealthy) {
        backendHealthy = true;
        healthCheckFailCount = 0;
        updateHealthIndicator(true);
        toast('✅ Backend reconnected!', 'success');
      }
      healthCheckFailCount = 0;
    } else {
      throw new Error(`HTTP ${res.status}`);
    }
  } catch (e) {
    healthCheckFailCount++;
    console.warn(`[Health Check] Attempt ${healthCheckFailCount}: ${e.message}`);
    
    if (healthCheckFailCount >= HEALTH_FAIL_THRESHOLD && backendHealthy) {
      backendHealthy = false;
      updateHealthIndicator(false);
      toast('⚠️ Backend temporarily unreachable. Retrying...', 'warning');
    }
  }
}

function updateHealthIndicator(isHealthy) {
  const indicator = document.getElementById('health-indicator');
  if (indicator) {
    indicator.className = `health-indicator ${isHealthy ? 'healthy' : 'unhealthy'}`;
    indicator.title = isHealthy ? 'Backend: Connected' : 'Backend: Temporarily Down (auto-retrying)';
  }
}

// Start health check on page load
checkBackendHealth();
setInterval(checkBackendHealth, HEALTH_CHECK_INTERVAL);

// ── Utils ──────────────────────────────────────────────────────────────────

function toast(msg, type = 'info') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  if (id === 'modal-qr') {
    clearInterval(qrRefreshInterval);
    qrRefreshInterval = null;
    activeQrSession = null;
    resetQRDisplay();
  }
}

function resetQRDisplay() {
  document.getElementById('qr-image').style.display = 'none';
  document.getElementById('qr-loading').style.display = 'flex';
  document.getElementById('qr-expired').style.display = 'none';
  document.getElementById('pair-code-result').style.display = 'none';
  document.getElementById('pair-code-text').textContent = '';
  document.getElementById('pair-phone').value = '';
}

function switchTab(tab) {
  document.getElementById('tab-qr').classList.toggle('active', tab === 'qr');
  document.getElementById('tab-pair').classList.toggle('active', tab === 'pair');
  document.getElementById('panel-qr').classList.toggle('active', tab === 'qr');
  document.getElementById('panel-pair').classList.toggle('active', tab === 'pair');
}

function statusLabel(s) {
  const map = {
    idle: '⚪ Idle',
    connecting: '🟡 Connecting',
    qr_ready: '🔵 Scan QR',
    pairing: '🟡 Pairing',
    connected: '🟢 Connected',
    disconnected: '🔴 Disconnected',
    error: '🔴 Error'
  };
  return map[s] || s;
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

// ── Render ─────────────────────────────────────────────────────────────────

function renderSessions(list) {
  sessions = list;
  const grid = document.getElementById('sessions-grid');
  const empty = document.getElementById('empty-state');

  const connected = list.filter(s => s.status === 'connected').length;
  document.getElementById('connected-count').textContent = connected;
  document.getElementById('total-count').textContent = list.length;

  if (list.length === 0) {
    grid.innerHTML = '';
    grid.appendChild(empty);
    empty.style.display = '';
    return;
  }

  empty.style.display = 'none';
  const cards = list.map(s => buildCard(s)).join('');

  const prevCards = grid.querySelectorAll('.session-card');
  if (prevCards.length !== list.length) {
    grid.innerHTML = cards;
  } else {
    list.forEach((s, i) => {
      const card = grid.children[i];
      if (card) card.outerHTML = buildCard(s);
    });
    grid.innerHTML = cards;
  }
}

function buildCard(s) {
  const statusClass = s.status.replace('_', '-');
  const connected = s.status === 'connected';
  const idle = s.status === 'idle' || s.status === 'disconnected' || s.status === 'error';
  const running = s.status === 'connecting' || s.status === 'qr_ready' || s.status === 'pairing';
  const hasSession = s.hasSession;

  const startBtn = idle
    ? `<button class="btn btn-primary btn-sm" onclick="startSession(${s.id})">▶ Start</button>`
    : '';
  const stopBtn = (connected || running)
    ? `<button class="btn btn-ghost btn-sm" onclick="stopSession(${s.id})">⏹ Stop</button>`
    : '';
  const qrBtn = (running || idle)
    ? `<button class="btn btn-outline btn-sm" onclick="openQRModal(${s.id})">📱 Connect</button>`
    : '';
  const deleteBtn = `<button class="btn btn-danger btn-sm" onclick="deleteSession(${s.id})">🗑</button>`;

  return `
    <div class="session-card ${connected ? 'connected' : ''} ${s.status === 'error' ? 'error' : ''}" id="card-${s.id}">
      <div class="card-header">
        <div class="card-title">
          <div class="session-num">${s.id}</div>
          <div>
            <div class="session-name">${escHtml(s.name)}</div>
          </div>
        </div>
        <div class="status-badge ${s.status}">${statusLabel(s.status)}</div>
      </div>
      <div class="card-info">
        ${s.connectedNumber ? `<span>📞 <strong>${s.connectedNumber}</strong></span>` : ''}
        ${s.ownerNumber ? `<span>👑 Owner: <strong>${escHtml(s.ownerNumber)}</strong></span>` : ''}
        <span>📁 ${hasSession ? '✅ Session saved' : '⚪ No session'}</span>
      </div>
      <div class="card-actions">
        ${startBtn}${stopBtn}${qrBtn}${deleteBtn}
      </div>
    </div>`;
}

function escHtml(str) {
  if (!str) return '';
  return String(str).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

// ── Session actions ────────────────────────────────────────────────────────

function startSession(id) {
  socket.emit('session:start', { id });
  toast(`Starting session ${id}...`, 'info');
}

function stopSession(id) {
  if (!confirm('Stop this session?')) return;
  socket.emit('session:stop', { id });
  toast(`Stopping session ${id}...`, 'info');
}

function deleteSession(id) {
  if (!confirm('Delete this session? This will remove all session data.')) return;
  socket.emit('session:delete', { id });
  toast(`Deleting session ${id}...`, 'info');
}

function openQRModal(id) {
  activeQrSession = id;
  resetQRDisplay();
  openModal('modal-qr');
  startSession(id);
  pollQR(id);
}

function pollQR(id) {
  clearInterval(qrRefreshInterval);

  const doFetch = async () => {
    if (!activeQrSession) return;
    try {
      const res = await fetch(`${window.BACKEND_URL}/api/sessions/${id}/qr`, {
        credentials: 'include',
        headers: { 'Bypass-Tunnel-Reminder': 'true' }
      });
      const data = await res.json();
      if (data.qr) {
        document.getElementById('qr-loading').style.display = 'none';
        document.getElementById('qr-expired').style.display = 'none';
        const img = document.getElementById('qr-image');
        img.src = data.qr;
        img.style.display = 'block';
      } else if (data.status === 'connected') {
        clearInterval(qrRefreshInterval);
        closeModal('modal-qr');
        toast('✅ Session connected!', 'success');
      }
    } catch (e) {}
  };

  doFetch();
  qrRefreshInterval = setInterval(doFetch, 3000);
}

function refreshQR() {
  if (activeQrSession) {
    resetQRDisplay();
    pollQR(activeQrSession);
  }
}

async function getPairCode() {
  const phone = document.getElementById('pair-phone').value.trim().replace(/[^0-9]/g, '');
  if (!phone || phone.length < 7) {
    toast('Please enter a valid phone number', 'error');
    return;
  }
  if (!activeQrSession) return;

  const btn = document.getElementById('btn-get-paircode');
  btn.disabled = true;
  btn.textContent = 'Getting code...';

  try {
    const res = await fetch(`${window.BACKEND_URL}/api/sessions/${activeQrSession}/paircode`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json', 'Bypass-Tunnel-Reminder': 'true' },
      body: JSON.stringify({ phone })
    });
    const data = await res.json();
    if (data.success && data.code) {
      document.getElementById('pair-code-result').style.display = 'block';
      document.getElementById('pair-code-text').textContent = data.code;
    } else {
      toast(data.error || 'Failed to get pairing code', 'error');
    }
  } catch (e) {
    toast('Network error', 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Get Pairing Code';
  }
}

// ── Create session ─────────────────────────────────────────────────────────

document.getElementById('btn-add-session').addEventListener('click', () => {
  document.getElementById('input-session-name').value = '';
  document.getElementById('input-owner-number').value = '';
  openModal('modal-add');
});

document.getElementById('btn-create-session').addEventListener('click', () => {
  const name = document.getElementById('input-session-name').value.trim();
  const ownerNumber = document.getElementById('input-owner-number').value.trim().replace(/[^0-9]/g, '');
  socket.emit('session:create', { name: name || undefined, ownerNumber: ownerNumber || undefined });
  closeModal('modal-add');
  toast('Session created!', 'success');
});

// ── Socket events ──────────────────────────────────────────────────────────

socket.on('sessions:list', ({ sessions: list }) => renderSessions(list));
socket.on('sessions:refresh', ({ sessions: list }) => renderSessions(list));

socket.on('session:qr', ({ id, qr }) => {
  if (id === activeQrSession && qr) {
    document.getElementById('qr-loading').style.display = 'none';
    document.getElementById('qr-expired').style.display = 'none';
    const img = document.getElementById('qr-image');
    img.src = qr;
    img.style.display = 'block';
  }
});

socket.on('session:paircode', ({ id, code }) => {
  if (id === activeQrSession) {
    document.getElementById('pair-code-result').style.display = 'block';
    document.getElementById('pair-code-text').textContent = code;
  }
  toast(`Pairing code for session ${id}: ${code}`, 'success');
});

socket.on('session:connected', ({ id, number }) => {
  toast(`✅ Session ${id} connected as ${number}`, 'success');
  if (id === activeQrSession) {
    clearInterval(qrRefreshInterval);
    closeModal('modal-qr');
  }
});

socket.on('session:disconnected', ({ id }) => {
  toast(`Session ${id} disconnected`, 'info');
});

socket.on('session:error', ({ id, error }) => {
  toast(`Session ${id} error: ${error}`, 'error');
});

socket.on('session:ok', ({ id, action }) => {
  toast(`Session ${id}: ${action} done`, 'success');
});

socket.on('disconnect', () => toast('Connection to panel lost, reconnecting...', 'error'));
socket.on('connect', () => {
  if (sessions.length > 0) toast('Reconnected to panel', 'success');
});

// ── Uptime ─────────────────────────────────────────────────────────────────

async function fetchStatus() {
  try {
    const res = await fetch(window.BACKEND_URL + '/api/status', {
      credentials: 'include',
      headers: { 'Bypass-Tunnel-Reminder': 'true' }
    });
    const data = await res.json();
    document.getElementById('uptime').textContent = formatUptime(data.uptime);
  } catch (e) {}
}
fetchStatus();
setInterval(fetchStatus, 10000);

// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => {
    if (e.target === el) closeModal(el.id);
  });
});

// Enter key for create session
document.getElementById('input-owner-number').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('btn-create-session').click();
});
