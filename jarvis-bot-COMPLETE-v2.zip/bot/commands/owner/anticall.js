/**
 * Anti-Call Command — Toggle call rejection on/off
 * Uses a live runtime flag (no restart needed)
 */

module.exports = {
  name: 'anticall',
  category: 'owner',
  ownerOnly: true,
  description: 'Enable or disable anti-call system',
  usage: '.anticall on/off',

  async execute(sock, msg, args, extra) {
    if (!args[0] || !['on', 'off'].includes(args[0].toLowerCase())) {
      return extra.reply('Usage: .anticall on/off');
    }

    const enabled = args[0].toLowerCase() === 'on';

    // Toggle the live flag in handler.js (takes effect immediately, no restart needed)
    try {
      const handler = require('../../handler');
      handler.setAntiCall(enabled);
    } catch (err) {
      console.error('[anticall cmd] setAntiCall error:', err.message);
    }

    // Also persist to config.js so the setting survives a bot restart
    try {
      const fs   = require('fs');
      const path = require('path');
      const configPath = path.join(__dirname, '../../config.js');
      let   configFile = fs.readFileSync(configPath, 'utf8');
      if (enabled) {
        configFile = configFile.replace(/anticall:\s*false/g, 'anticall: true');
      } else {
        configFile = configFile.replace(/anticall:\s*true/g, 'anticall: false');
      }
      fs.writeFileSync(configPath, configFile);
    } catch (_) {}

    await extra.reply(
      enabled
        ? '✅ *Anti-call enabled.*\nAll incoming calls will be auto-rejected.'
        : '❌ *Anti-call disabled.*\nCalls are now allowed.'
    );
  }
};
