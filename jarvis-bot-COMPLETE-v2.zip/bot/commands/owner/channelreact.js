'use strict';

const {
  DEFAULT_EMOJI,
  normalizeJid,
  get,
  set,
  remove,
  list,
} = require('../../utils/channelReact');

const CHANNEL_LINK_RE = /(?:https?:\/\/)?(?:www\.)?whatsapp\.com\/channel\/([A-Za-z0-9_-]+)/i;
const NEWSLETTER_JID_RE = /^\d+@newsletter$/;

function help() {
  return [
    '📣 *Channel Auto-React*',
    '',
    '✅ Enable:',
    '`.channelreact <channel-link> on ❤️`',
    '',
    '❌ Disable:',
    '`.channelreact <channel-link> off`',
    '',
    '📋 Check one channel:',
    '`.channelreact <channel-link> status`',
    '',
    '📋 Check all configured channels:',
    '`.channelreact list`',
    '',
    '_A single WhatsApp account can only place one reaction per post._',
    '_100/200/500 reactions would require multiple accounts, so bulk reactions are not allowed._',
  ].join('\n');
}

function cleanEmoji(value) {
  const emoji = String(value || '').trim();
  if (!emoji || /^\d+$/.test(emoji) || emoji.length > 16 || /https?:\/\//i.test(emoji)) {
    return '';
  }
  return emoji;
}

async function resolveChannel(sock, input) {
  const raw = String(input || '').trim();
  if (NEWSLETTER_JID_RE.test(raw)) {
    return { jid: raw, name: raw };
  }

  const match = raw.match(CHANNEL_LINK_RE);
  if (!match) throw new Error('Please provide a valid WhatsApp Channel link or newsletter JID.');
  if (typeof sock.newsletterMetadata !== 'function') {
    throw new Error('Channel metadata support is not available on this Baileys connection.');
  }

  const metadata = await sock.newsletterMetadata('invite', match[1]);
  const jid = normalizeJid(metadata?.id);
  if (!jid) throw new Error('Could not resolve the channel link, or the channel is unavailable.');
  return { jid, name: metadata?.name || metadata?.subject || jid };
}

module.exports = {
  name: 'channelreact',
  aliases: ['creact', 'newsletterreact'],
  category: 'owner',
  description: 'Enable one safe auto-reaction for a specific WhatsApp Channel',
  usage: '.channelreact <channel-link> on ❤️ | off | status',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      if (!args?.length || ['help', '?'].includes(String(args[0]).toLowerCase())) {
        return extra.reply(help());
      }

      if (String(args[0]).toLowerCase() === 'list') {
        const configured = list(extra.botId || sock.user?.id);
        if (!configured.length) return extra.reply('📋 No channel has auto-react configured.');
        return extra.reply(
          '📋 *Configured Channel Auto-Reacts*\n\n' +
          configured.map((cfg, i) => `${i + 1}. ${cfg.name || cfg.jid} — ${cfg.emoji}`).join('\n')
        );
      }

      const channel = await resolveChannel(sock, args[0]);
      const action = String(args[1] || '').toLowerCase();
      const botId = extra.botId || sock.user?.id;

      if (action === 'status') {
        const cfg = get(botId, channel.jid);
        return extra.reply(
          `📣 *${channel.name}*\n\n` +
          `JID: ${channel.jid}\n` +
          `Auto-react: ${cfg ? 'ON ✅' : 'OFF ❌'}\n` +
          `Emoji: ${cfg?.emoji || 'Not set'}`
        );
      }

      if (['off', 'disable', 'stop'].includes(action)) {
        remove(botId, channel.jid);
        return extra.reply(`❌ Channel auto-react turned OFF:\n*${channel.name}*`);
      }

      if (!['on', 'enable', 'start', 'set'].includes(action)) {
        return extra.reply(help());
      }

      const requestedCount = Number(args[2]);
      if (Number.isFinite(requestedCount) && requestedCount > 1) {
        return extra.reply(
          '⚠️ *Bulk reactions are not allowed.*\n\n' +
          'A single WhatsApp account can only place *one* reaction per channel post. ' +
          'Using multiple accounts for 100/200/500 reactions violates WhatsApp policy and creates an anti-spam risk.\n\n' +
          'Safe command: `.channelreact <link> on ❤️`'
        );
      }

      const emojiArg = Number.isFinite(requestedCount) ? args[3] : args[2];
      const emoji = cleanEmoji(emojiArg) || DEFAULT_EMOJI;
      set(botId, channel.jid, { enabled: true, emoji, name: channel.name });

      return extra.reply(
        `✅ *Channel auto-react ON*\n\n` +
        `📣 Channel: *${channel.name}*\n` +
        `🎭 Reaction: ${emoji}\n` +
        `🛡️ One reaction per post, safe rate-limited mode.\n\n` +
        `To turn it off:\n`.concat(`.channelreact ${args[0]} off`)
      );
    } catch (error) {
      console.error('[channelreact] error:', error.message);
      return extra.reply(`❌ Channel auto-react setup failed: ${error.message}\n\n${help()}`);
    }
  },
};