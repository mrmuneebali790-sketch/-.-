'use strict';

/**
 * .strictguard — Toggle Strict Guard (Full Security Control System) for a group.
 * Only the bot owner (923196615238) may use this command.
 * Must be used inside the target group.
 *
 * Layer 1 (always active when ON):
 *   • Blocks unauthorized admin promote/demote — reversal is instant
 *   • Offenders: demoted on 1st offense, removed on 2nd+
 *
 * Layer 2 (message security, active when ON):
 *   • Anti-spam: max 12 messages / 15 s per user
 *   • Command abuse: max 7 commands / 20 s per user
 *   • Repeat command: same command ≥ 4 times → remove
 *   • Mass URL spam: ≥ 4 links in one message → remove
 *   • Mention flood: ≥ 8 @mentions in one message → remove
 *   Admins and bot owner are ALWAYS bypassed.
 */

const strictGuard = require('../../utils/strictGuard');

module.exports = {
  name       : 'strictguard',
  aliases    : ['sg', 'sgmode', 'guardon'],
  category   : 'owner',
  description: 'Toggle Strict Guard (Full Security Control System) for this group',
  usage      : '.strictguard on | off | status',
  ownerOnly  : true,
  groupOnly  : true,

  async execute(sock, msg, args, extra) {
    try {
      const { from, reply } = extra;
      const mode = (args[0] || '').toLowerCase().trim();

      const cfg   = strictGuard.getGuardConfig(from);
      const gName = extra.groupMetadata?.subject || from.split('@')[0];
      const ownerTag = cfg.owner ? `@${cfg.owner}` : '_(not set — use .setgowner @user)_';

      // ── Status / no args ──────────────────────────────────────────────────
      if (!mode || mode === 'status' || mode === 'info') {
        return reply(
          `🛡️ *Strict Guard — Status*\n\n` +
          `🏠 Group  : ${gName}\n` +
          `👑 Owner  : ${ownerTag}\n` +
          `🔒 Mode   : ${cfg.enabled ? '🟢 *ON* (Full Security Active)' : '🔴 *OFF*'}\n\n` +
          `*Active protection (when ON):*\n` +
          `▸ Admin role changes — instantly reversed\n` +
          `▸ Message flood — warn / delete\n` +
          `▸ Command spam — warn / delete\n` +
          `▸ Repeated command abuse — remove\n` +
          `▸ Mass URL/link spam — remove\n` +
          `▸ Mention flood — remove\n` +
          `▸ Admins & owner — always bypassed\n\n` +
          `*Commands:*\n` +
          `• *.setgowner @user* — assign group owner\n` +
          `• *.strictguard on* — activate\n` +
          `• *.strictguard off* — deactivate\n\n` +
          `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`
        );
      }

      // ── Enable ────────────────────────────────────────────────────────────
      if (mode === 'on' || mode === 'enable' || mode === 'activate') {
        if (!cfg.owner) {
          return reply(
            `❌ *No group owner set!*\n\n` +
            `Assign one first:\n` +
            `*.setgowner @user*\n\n` +
            `Then run *.strictguard on* again.`
          );
        }
        strictGuard.setGuardEnabled(from, true);
        await sock.sendMessage(from, {
          text:
            `🛡️ *Strict Guard ACTIVATED!*\n\n` +
            `🏠 Group  : ${gName}\n` +
            `👑 Owner  : ${ownerTag}\n` +
            `🔒 Mode   : 🟢 *FULL SECURITY — ON*\n\n` +
            `*Now enforcing:*\n` +
            `🔐 Admin role changes — unauthorized ones reversed instantly\n` +
            `🚫 Message flood — blocked & warned\n` +
            `🚫 Command spam — blocked & warned\n` +
            `🚫 Repeated command abuse — user removed\n` +
            `🚫 Mass URL/link spam — user removed\n` +
            `🚫 Mention flood — user removed\n\n` +
            `✅ *Admins and bot owner are always bypassed.*\n\n` +
            `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`,
          mentions: cfg.owner ? [`${cfg.owner}@s.whatsapp.net`] : [],
        }, { quoted: msg });
        return;
      }

      // ── Disable ───────────────────────────────────────────────────────────
      if (mode === 'off' || mode === 'disable' || mode === 'deactivate') {
        strictGuard.setGuardEnabled(from, false);
        return reply(
          `🔓 *Strict Guard DEACTIVATED*\n\n` +
          `🏠 Group : ${gName}\n` +
          `🔒 Mode  : 🔴 *OFF*\n\n` +
          `All Strict Guard protections are now disabled in this group.\n` +
          `Run *.strictguard on* to re-activate.\n\n` +
          `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`
        );
      }

      // ── Unknown arg ───────────────────────────────────────────────────────
      return reply(
        `❓ *Unknown option:* \`${mode}\`\n\n` +
        `Usage: *.strictguard on | off | status*`
      );

    } catch (e) {
      console.error('[strictguard cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
