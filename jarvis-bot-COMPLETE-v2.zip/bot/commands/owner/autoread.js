'use strict';

/**
 * JARVIS — Autoread Command
 * Per-bot isolated toggle: when enabled, every incoming chat message
 * (not WhatsApp Status — that has its own always-on handling) is
 * automatically marked as read (blue ticks).
 * Storage: database.js → botSettings[botId]['autoRead']
 */

const db = require('../../database');

function _getBotId(sock) {
  return String(sock?.user?.id || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '') || null;
}

function isAutoreadEnabled(sockOrBotId) {
  const botId = typeof sockOrBotId === 'string' ? sockOrBotId : _getBotId(sockOrBotId);
  if (!botId) return false;
  return db.getBotSetting(botId, 'autoRead', false) === true;
}

async function handleAutoread(sock, msg) {
  try {
    const botId = _getBotId(sock);
    if (!isAutoreadEnabled(botId)) return;
    if (!msg?.key || msg.key.remoteJid === 'status@broadcast') return;

    await sock.readMessages([{
      remoteJid  : msg.key.remoteJid,
      id         : msg.key.id,
      participant: msg.key.participant,
      fromMe     : msg.key.fromMe || false,
    }]);
  } catch (_) { /* non-fatal */ }
}

function senderIsOwner(extra, msg) {
  if (extra && typeof extra.isOwner === 'boolean') return extra.isOwner;
  return false;
}

module.exports = {
  name: 'autoread',
  aliases: ['auto-read'],
  category: 'owner',
  description: 'Toggle automatic read-receipts for incoming chat messages',
  usage: '.autoread on/off',
  ownerOnly: true,

  isAutoreadEnabled,
  handleAutoread,

  async execute(sock, msg, args, extra) {
    if (!senderIsOwner(extra, msg)) {
      return extra.reply('❌ This command is owner-only.');
    }

    const botId = _getBotId(sock);
    const sub = (args[0] || '').toLowerCase();

    if (!sub) {
      const current = isAutoreadEnabled(botId);
      return extra.reply(`👁️ Autoread is currently *${current ? 'ON' : 'OFF'}*.\n\nUsage: .autoread on/off`);
    }

    if (!['on', 'off'].includes(sub)) {
      return extra.reply('❌ Please specify: .autoread on  OR  .autoread off');
    }

    const enabled = sub === 'on';
    if (!botId) {
      return extra.reply('❌ Could not determine bot session — try again in a moment.');
    }
    db.setBotSetting(botId, 'autoRead', enabled);
    await extra.reply(`✅ Autoread has been turned *${enabled ? 'ON' : 'OFF'}*.`);
  },
};
