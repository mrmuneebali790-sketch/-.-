'use strict';

/**
 * .setgowner — Designate the strict-guard owner for a group.
 * Only the bot owner (923196615238) may use this command.
 * Must be used inside the group you want to protect.
 */

const strictGuard = require('../../utils/strictGuard');

module.exports = {
  name: 'setgowner',
  aliases: ['setgroupowner', 'sgowner'],
  category: 'owner',
  description: 'Set the designated group owner for Strict Guard protection',
  usage: '.setgowner @user',
  ownerOnly: true,
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const { from, reply } = extra;

      // ── Resolve target: mention or quoted sender ──────────────────────────
      const ctx      = msg.message?.extendedTextMessage?.contextInfo ||
                       msg.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo;
      const mentioned = ctx?.mentionedJid || [];
      const quoted    = ctx?.participant || null;

      let targetJid = mentioned[0] || quoted || null;
      if (!targetJid && args[0]) {
        const num = args[0].replace(/[^0-9]/g, '');
        if (num.length >= 7) targetJid = `${num}@s.whatsapp.net`;
      }

      if (!targetJid) {
        return reply(
          `❓ *Usage:* .setgowner @user\n\n` +
          `Reply to a message or mention the person you want to set as this group\'s strict-guard owner.\n\n` +
          `After setting the owner, use *.strictguard on* to activate protection.`
        );
      }

      const targetPhone = targetJid.split(':')[0].split('@')[0].replace(/[^0-9]/g, '');

      // ── Persist ────────────────────────────────────────────────────────────
      strictGuard.setGroupOwner(from, targetJid);

      const cfg = strictGuard.getGuardConfig(from);
      const statusLine = cfg.enabled
        ? `🟢 Strict Guard is currently *ON* — protection is active.`
        : `🔴 Strict Guard is currently *OFF* — activate with *.strictguard on*`;

      await sock.sendMessage(from, {
        text:
          `✅ *Strict Guard Owner Set!*\n\n` +
          `👑 Group Owner : @${targetPhone}\n` +
          `🏠 Group       : ${extra.groupMetadata?.subject || from.split('@')[0]}\n\n` +
          `${statusLine}\n\n` +
          `> Only @${targetPhone} (and the bot owner) may now change\n` +
          `> admin roles in this group when Strict Guard is ON.\n\n` +
          `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`,
        mentions: [targetJid],
      }, { quoted: msg });

    } catch (e) {
      console.error('[setgowner]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
