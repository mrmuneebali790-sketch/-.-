'use strict';
/**
 * Mode Command — Per-session private/public toggle
 * Uses database.js per-bot settings so each session is fully isolated.
 * Does NOT touch the global config.js or config.selfMode.
 */

const database = require('../../database');
const config   = require('../../config');

module.exports = {
  name: 'mode',
  aliases: ['botmode', 'privatemode', 'publicmode'],
  description: 'Toggle bot between private and public mode (per-session)',
  usage: '.mode <private/public>',
  category: 'owner',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const botId = extra.botId || sock.user?.id;
      // Per-session selfMode; fall back to global config default
      const currentMode = database.getBotSetting(botId, 'selfMode', config.selfMode || false);

      if (!args[0]) {
        const label = currentMode ? 'PRIVATE 🔒' : 'PUBLIC 🌐';
        const desc  = currentMode
          ? 'Only owner can use commands on this bot.'
          : 'Everyone can use commands on this bot.';
        return extra.reply(
          `🤖 *Bot Mode — This Session*\n\n` +
          `Current Mode : *${label}*\n` +
          `Status       : ${desc}\n\n` +
          `Change:\n` +
          `  .mode private — Only owner\n` +
          `  .mode public  — Everyone`
        );
      }

      const mode = args[0].toLowerCase();

      if (mode === 'private' || mode === 'priv') {
        if (currentMode) return extra.reply('🔒 This bot is already in *PRIVATE* mode.');
        database.setBotSetting(botId, 'selfMode', true);
        return extra.reply('🔒 Mode → *PRIVATE*\n\nOnly you (the owner) can use commands on this bot now.\n\n_(Other bot sessions are not affected.)_');
      }

      if (mode === 'public' || mode === 'pub') {
        if (!currentMode) return extra.reply('🌐 This bot is already in *PUBLIC* mode.');
        database.setBotSetting(botId, 'selfMode', false);
        return extra.reply('🌐 Mode → *PUBLIC*\n\nEveryone can use commands on this bot now.\n\n_(Other bot sessions are not affected.)_');
      }

      return extra.reply('❌ Invalid option!\nUsage: `.mode private` or `.mode public`');

    } catch (err) {
      console.error('[mode cmd] error:', err.message);
      await extra.reply('❌ Error changing bot mode.');
    }
  }
};
