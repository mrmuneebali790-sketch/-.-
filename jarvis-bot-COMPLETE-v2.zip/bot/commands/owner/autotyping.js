'use strict';

/**
 * JARVIS — Autotyping Command
 * Per-bot isolated: each connected session has its own autotyping toggle.
 * Storage: database.js → botSettings[botId]['autoTyping']
 */

const db   = require('../../database');
const path = require('path');
const fs   = require('fs');

const OWNER_NUMBER = '923196615238';

// ── Legacy global fallback (migration — reads old autotyping.json if no per-bot value) ─
const _legacyPath = path.join(__dirname, '..', '..', 'data', 'autotyping.json');
function _legacyRead() {
  try { return JSON.parse(fs.readFileSync(_legacyPath, 'utf8')).enabled === true; }
  catch { return false; }
}

// ── Per-bot helpers ───────────────────────────────────────────────────────────
function _getBotId(sock) {
  return String(sock?.user?.id || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '') || null;
}

function isAutotypingEnabled(sockOrBotId) {
  const botId = typeof sockOrBotId === 'string'
    ? sockOrBotId
    : _getBotId(sockOrBotId);
  if (botId) {
    const val = db.getBotSetting(botId, 'autoTyping', null);
    if (val !== null) return val === true;
  }
  return _legacyRead();
}

function _saveAutoTyping(botId, enabled) {
  if (botId) db.setBotSetting(botId, 'autoTyping', enabled);
}

// ── Owner check (handler gate fires first — this is just a safety net) ───────
function senderIsOwner(extra, msg) {
  if (extra && typeof extra.isOwner === 'boolean') return extra.isOwner;
  const rawJid = msg?.key?.participant || msg?.key?.remoteJid || '';
  const digits  = rawJid.split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
  if (digits === OWNER_NUMBER) return true;
  try {
    const { normalizeJidWithLid } = require('../../utils/jidHelper');
    const resolved = normalizeJidWithLid(rawJid) || '';
    return resolved.split('@')[0].split(':')[0].replace(/[^0-9]/g, '') === OWNER_NUMBER;
  } catch (_) {}
  return false;
}

// ── Presence helper ───────────────────────────────────────────────────────────
async function sendComposing(sock, chatId, ms) {
  try {
    await sock.presenceSubscribe(chatId);
    await sock.sendPresenceUpdate('available', chatId);
    await sock.sendPresenceUpdate('composing', chatId);
    await new Promise(r => setTimeout(r, ms));
    await sock.sendPresenceUpdate('paused', chatId).catch(() => {});
  } catch (_) {}
}

async function handleAutotypingForMessage(sock, chatId, userMessage) {
  if (!isAutotypingEnabled(sock)) return false;
  const delay = Math.max(2000, Math.min(7000, (userMessage || '').length * 120));
  await sendComposing(sock, chatId, delay);
  return true;
}

async function handleAutotypingForCommand(sock, chatId) {
  if (!isAutotypingEnabled(sock)) return false;
  await sendComposing(sock, chatId, 2500);
  return true;
}

async function showTypingAfterCommand(sock, chatId) {
  if (!isAutotypingEnabled(sock)) return false;
  try {
    await sock.sendPresenceUpdate('composing', chatId);
    await new Promise(r => setTimeout(r, 800));
    await sock.sendPresenceUpdate('paused', chatId).catch(() => {});
  } catch (_) {}
  return true;
}

// ── Execute command ───────────────────────────────────────────────────────────
async function executeAutotyping(sock, msg, args, extra) {
  const chatId = msg.key.remoteJid;
  const botId  = _getBotId(sock);

  if (!senderIsOwner(extra, msg)) {
    return sock.sendMessage(chatId, {
      text: '❌ *Permission Denied!*\n\nThis command is only for the bot owner.',
      quoted: msg,
    });
  }

  const current = isAutotypingEnabled(botId);
  const arg     = (args[0] || '').toLowerCase();

  let enabled;
  if (arg === 'on' || arg === 'enable') {
    enabled = true;
  } else if (arg === 'off' || arg === 'disable') {
    enabled = false;
  } else if (arg === '') {
    enabled = !current;
  } else {
    return sock.sendMessage(chatId, {
      text:
        `❌ *Invalid option:* \`${arg}\`\n\n` +
        `Usage:\n` +
        `• *.autotyping on* — Enable typing indicator\n` +
        `• *.autotyping off* — Disable typing indicator\n` +
        `• *.autotyping* — Toggle current state`,
      quoted: msg,
    });
  }

  _saveAutoTyping(botId, enabled);

  const status = enabled ? '🟢 *ON*' : '🔴 *OFF*';
  return sock.sendMessage(chatId, {
    text:
      `╭━━━❰ ⌨️ *AUTO-TYPING* ❱━━━╮\n` +
      `┃\n` +
      `┃ Status : ${status}\n` +
      `┃\n` +
      `┃ ${enabled
          ? 'Bot will now show typing\n┃ indicator before every reply.'
          : 'Typing indicator disabled.\n┃ Bot replies instantly.'}\n` +
      `┃\n` +
      `╰━━━━━━━━━━━━━━━━━━━━━━━╯\n\n` +
      `> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡*`,
    quoted: msg,
  });
}

module.exports = {
  name     : 'autotyping',
  aliases  : ['autotp', 'typing'],
  category : 'owner',
  ownerOnly: true,
  desc     : 'Toggle auto-typing presence indicator before every bot response',
  usage    : '.autotyping [on|off]',

  execute: (sock, msg, args, extra) => executeAutotyping(sock, msg, args, extra),

  isAutotypingEnabled,
  handleAutotypingForMessage,
  handleAutotypingForCommand,
  showTypingAfterCommand,
};
