'use strict';

const { isAutoStatusEnabled, isStatusReactEnabled, setAutoStatus, setStatusReact } = require('../../utils/autostatusConfig');

module.exports = {
  name       : 'autostatus',
  aliases    : ['statusview', 'autoview'],
  category   : 'owner',
  description: 'Toggle automatic status viewing and reactions (per-bot isolated)',
  usage      : '.autostatus on/off',
  ownerOnly  : true,

  async execute(sock, msg, args, extra) {
    const chatId = msg.key.remoteJid;
    const botId  = String(sock?.user?.id || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '') || null;

    const safeReply = async (text) => {
      if (extra && typeof extra.reply === 'function') return extra.reply(text);
      return sock.sendMessage(chatId, { text }, { quoted: msg });
    };

    try {
      const cmd = (args[0] || '').toLowerCase();
      const sub = (args[1] || '').toLowerCase();

      if (!cmd || !['on', 'off', 'react'].includes(cmd)) {
        const viewStatus  = isAutoStatusEnabled(botId)  ? '✅ ON' : '❌ OFF';
        const reactStatus = isStatusReactEnabled(botId) ? '✅ ON' : '❌ OFF';
        return safeReply(
          `📱 *Auto Status Settings*\n\n` +
          `▸ Auto View  : *${viewStatus}*\n` +
          `▸ Auto React : *${reactStatus}*\n\n` +
          `Commands:\n` +
          `• *.autostatus on*        — Enable auto view\n` +
          `• *.autostatus off*       — Disable auto view\n` +
          `• *.autostatus react on*  — Enable 👀 reactions\n` +
          `• *.autostatus react off* — Disable reactions\n\n` +
          `> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`
        );
      }

      if (cmd === 'on') {
        setAutoStatus(true, botId);
        return safeReply(`✅ *Auto Status View: ENABLED*\n\nBot will now automatically view all contact statuses.\n\n> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`);
      }

      if (cmd === 'off') {
        setAutoStatus(false, botId);
        return safeReply(`❌ *Auto Status View: DISABLED*\n\nBot will no longer view statuses automatically.\n\n> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`);
      }

      if (cmd === 'react') {
        if (!sub || !['on', 'off'].includes(sub)) {
          return safeReply('Usage: .autostatus react on/off');
        }
        setStatusReact(sub === 'on', botId);
        return safeReply(
          sub === 'on'
            ? `✅ *Status Reactions: ENABLED* — Bot will react 👀 to every status.`
            : `❌ *Status Reactions: DISABLED*`
        );
      }

    } catch (err) {
      console.error('[AUTOSTATUS] Error:', err.message);
      await safeReply('❌ Error processing autostatus command. Please try again.');
    }
  },
};
