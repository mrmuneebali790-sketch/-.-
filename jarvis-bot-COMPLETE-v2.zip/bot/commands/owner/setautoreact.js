'use strict';
/**
 * setautoreact — Set a fixed emoji for this session's auto-reactions.
 * Per-session isolated; does not affect any other bot session.
 *
 * Usage:
 *   .setautoreact ❤️        → all auto-reactions will use ❤️
 *   .setautoreact reset     → back to random emojis
 *   .setautoreact           → show current setting
 */

const { load, save } = require('../../utils/autoReact');

module.exports = {
  name: 'setautoreact',
  aliases: ['setreact', 'reactemoji', 'set autoreact'],
  category: 'owner',
  description: 'Set a fixed emoji for auto-reactions (per-session)',
  usage: '.setautoreact ❤️ | .setautoreact reset',
  ownerOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const botId = extra.botId || sock.user?.id;
      const db    = load(botId);

      // No args → show current setting
      if (!args[0]) {
        const current = db.emoji || null;
        return extra.reply(
          `🎭 *Auto React Emoji — This Session*\n\n` +
          `Current : ${current ? `*${current}* (fixed)` : '*Random* (not set)'}\n` +
          `Status  : Auto-react is *${db.enabled ? 'ON ✅' : 'OFF ❌'}*\n\n` +
          `Commands:\n` +
          `  .setautoreact ❤️     — Fix emoji\n` +
          `  .setautoreact reset  — Random emojis\n` +
          `  .autoreact on/off    — Toggle auto-react`
        );
      }

      const input = args[0].trim();

      // Reset → random
      if (['reset', 'off', 'random', 'none', 'clear'].includes(input.toLowerCase())) {
        db.emoji = null;
        save(db, botId);
        return extra.reply('🎲 Auto-react will now use *random emojis* on this bot.\n\n_(Other sessions are not affected.)_');
      }

      // Set fixed emoji
      db.emoji = input;
      save(db, botId);
      return extra.reply(
        `✅ Auto-react emoji set to *${input}* for this bot!\n\n` +
        `Every auto-reaction from this session will now use ${input}.\n\n` +
        `_(Other bot sessions are not affected.)_`
      );

    } catch (err) {
      console.error('[setautoreact cmd] error:', err.message);
      await extra.reply('❌ Error setting auto-react emoji.');
    }
  }
};
