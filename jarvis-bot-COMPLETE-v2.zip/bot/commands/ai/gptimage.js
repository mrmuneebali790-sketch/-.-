/**
 * GPT Image Command
 * Multi-API fallback system for image analysis
 * By 𝐌𝐫.𝐌𝐮𝐧𝐞𝐞𝐛 𝐀𝐥𝐢
 */

const axios = require('axios');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { webp2png } = require('../../utils/webp2mp4');
const sharp = require('sharp');

// ✅ Multiple API Keys - Fallback System
const GEMINI_KEYS = [
  'AQ.Ab8RN6LISF_unqyf4ezrk8rBRSoYkHX2cbHg8OoVr2DiNQNikg',
  'AIzaSyD-9tSrke72WhLkZEnulJ4EG6V5hC8FtTs', // Backup key 2
  'AIzaSyCkDN5jV3CxqbNO6wGBwL5gF7hPmX9eLtI', // Backup key 3
  'AIzaSyBnJmRkQpT8vXwZ2YeKlN4rHo6sUqF1cMd', // Backup key 4
  'AIzaSyA3mPwRtYn7gKjL5vBqXo2sZeHuN9fCdWi', // Backup key 5
];

// ✅ Healthy API call with retry logic
async function callGeminiWithFallback(base64Image, prompt) {
  let lastError = null;

  for (let i = 0; i < GEMINI_KEYS.length; i++) {
    const key = GEMINI_KEYS[i];
    try {
      console.log(`[GptImage] Trying API key ${i + 1}/${GEMINI_KEYS.length}...`);

      const response = await axios.post(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${key}`,
        {
          contents: [
            {
              parts: [
                { text: prompt },
                {
                  inline_data: {
                    mime_type: 'image/jpeg',
                    data: base64Image
                  }
                }
              ]
            }
          ]
        },
        {
          headers: { 'Content-Type': 'application/json' },
          timeout: 30000
        }
      );

      const result = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
      if (result) {
        console.log(`[GptImage] Success with key ${i + 1}`);
        return result;
      }

    } catch (err) {
      lastError = err;
      const status = err.response?.status;
      console.error(`[GptImage] Key ${i + 1} failed - Status: ${status || err.code}`);

      // On 429 or 403, try the next key
      if (status === 429 || status === 403 || status === 404) {
        continue;
      }

      // On other errors, also try the next key
      continue;
    }
  }

  throw lastError || new Error('All API keys failed');
}

module.exports = {
  name: 'gptimage',
  aliases: ['gptimg', 'editimage', 'vision', 'gi'],
  category: 'ai',
  description: 'Analyze image using Gemini Vision AI',
  usage: '.gptimage <prompt> (reply to image/sticker)',

  async execute(sock, msg, args, extra) {
    try {

      // ── 1. Reply check ──
      const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;
      if (!ctxInfo?.quotedMessage) {
        return await extra.reply(
          '📷 *GPT Image Editor*\n\n' +
          'Reply to an *image* or *sticker* with your prompt.\n\n' +
          `Usage: ${extra.prefix || '.'}gptimage <your prompt>\n\n` +
          'Example:\n' +
          `${extra.prefix || '.'}gptimage what is in this image?`
        );
      }

      // ── 2. Prompt check ──
      const prompt = args.join(' ').trim();
      if (!prompt) {
        return await extra.reply(
          '❌ Please provide a prompt!\n\n' +
          `Usage: ${extra.prefix || '.'}gptimage <your prompt>`
        );
      }

      // ── 3. Image or sticker check ──
      const quotedMsg = ctxInfo.quotedMessage;
      const isImage = !!quotedMsg.imageMessage;
      const isSticker = !!quotedMsg.stickerMessage;

      if (!isImage && !isSticker) {
        return await extra.reply('❌ Please reply to an *image* or *sticker* only!');
      }

      // ── 4. Animated sticker check ──
      if (isSticker) {
        const stickerMsg = quotedMsg.stickerMessage;
        const isAnimated = stickerMsg.isAnimated || stickerMsg.mimetype?.includes('animated');
        if (isAnimated) {
          return await extra.reply('❌ Animated stickers are not supported. Please use a static image.');
        }
      }

      // ── 5. Processing message ──
      await extra.reply('⏳ Analyzing image...');

      // ── 6. Target message ──
      const targetMessage = {
        key: {
          remoteJid: extra.from,
          id: ctxInfo.stanzaId,
          participant: ctxInfo.participant,
        },
        message: ctxInfo.quotedMessage,
      };

      // ── 7. Download image ──
      let mediaBuffer = await downloadMediaMessage(
        targetMessage,
        'buffer',
        {},
        { logger: undefined, reuploadRequest: sock.updateMediaMessage }
      );

      if (!mediaBuffer) {
        return await extra.reply('❌ Failed to download the image. Please try again.');
      }

      // ── 8. Sticker to PNG convert ──
      if (isSticker) {
        try {
          mediaBuffer = await webp2png(mediaBuffer);
        } catch (err) {
          console.error('Sticker convert error:', err);
          return await extra.reply('❌ Failed to convert the sticker. Please use a regular image.');
        }
      }

      // ── 9. JPEG convert ──
      let finalBuffer;
      try {
        finalBuffer = await sharp(mediaBuffer)
          .jpeg({ quality: 85 })
          .toBuffer();
      } catch (err) {
        console.error('Sharp error:', err);
        finalBuffer = mediaBuffer;
      }

      // ── 10. Base64 convert ──
      const base64Image = finalBuffer.toString('base64');

      // ── 11. Multi-API call with fallback ──
      const result = await callGeminiWithFallback(base64Image, prompt);

      // ── 12. Send the result (clean, no extra caption) ──
      await sock.sendMessage(
        extra.from,
        {
          text: `✨ *Vision Result*\n\n${result}`
        },
        { quoted: msg }
      );

    } catch (error) {
      console.error('Gptimage command error:', error);

      if (error.response) {
        const status = error.response.status;
        if (status === 403) return await extra.reply('❌ All API keys have expired.');
        if (status === 429) return await extra.reply('❌ Rate limit reached. Please try again in a moment.');
        if (status === 500) return await extra.reply('❌ Server error. Please try again later.');
      }

      if (error.code === 'ECONNABORTED') {
        return await extra.reply('❌ Request timed out! Please try again.');
      }

      return await extra.reply(`❌ Error: ${error.message || 'Unknown error'}`);
    }
  },
};
