/**
 * Menu Command — JARVIS Ultra Interface
 * Dynamically builds the menu from whatever commands are actually
 * loaded (utils/commandLoader.js), grouped into themed sections.
 * Add/remove a command file and it appears/disappears here automatically —
 * nothing in this file needs to be hand-edited to keep the menu in sync.
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');
const { loadCommands } = require('../../utils/commandLoader');
const { runtime } = require('../../utils/helpers');

// A handful of "general" commands are really sticker/image/QR/TTS tools —
// split those into SPACE STONE, everything else in "general" is bot info
// and lands in MIND STONE.
const SPACE_STONE_NAMES = new Set([
  'sticker', 'attp', 'crop', 'take', 'simage', 'getpp',
  'viewonce', 'emojimix', 'qr', 'tts', 'ssweb'
]);

// category (folder) -> section definition. Order here is display order.
const SECTIONS = [
  { key: 'general', title: 'MIND STONE', emoji: '🟡', filter: (name) => !SPACE_STONE_NAMES.has(name) },
  { key: 'general', title: 'SPACE STONE', emoji: '🔵', filter: (name) => SPACE_STONE_NAMES.has(name) },
  { key: 'ai', title: 'REALITY STONE', emoji: '🔴' },
  { key: 'media', title: 'POWER STONE', emoji: '🟣' },
  { key: 'utility', title: 'TIME STONE', emoji: '🟢' },
  { key: 'fun', title: 'SOUL STONE', emoji: '🟠' },
  { key: 'anime', title: 'ANIME VAULT', emoji: '🎴' },
  { key: 'textmaker', title: 'TEXT STUDIO', emoji: '🎨' },
  { key: 'admin', title: 'GROUP CONTROL', emoji: '🛡️' },
  { key: 'owner', title: 'OWNER ZONE', emoji: '⚙️' },
];

function buildBox(title, emoji, lines, prefix) {
  if (!lines.length) return '';
  let box = `┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n`;
  box += `┃  ${emoji}  ${title}\n`;
  box += `┣━━━━━━━━━━━━━━━━━━━━━━━━━┫\n`;
  // Two commands per line, arrow-bulleted
  for (let i = 0; i < lines.length; i += 2) {
    const a = `⤷ ${prefix}${lines[i]}`;
    const b = lines[i + 1] ? `⤷ ${prefix}${lines[i + 1]}` : '';
    box += `┃  ${a.padEnd(22)}${b}\n`;
  }
  box += `┗━━━━━━━━━━━━━━━━━━━━━━━━━┛\n`;
  return box;
}

module.exports = {
  name: 'menu',
  aliases: ['help', 'commands'],
  category: 'general',
  description: 'Show all available commands',
  usage: '.menu',

  async execute(sock, msg, args, extra) {
    try {
      const commands = loadCommands();
      const byCategory = {};

      // Group by primary command name only (skip aliases)
      commands.forEach((cmd, name) => {
        if (cmd.name === name) {
          const cat = (cmd.category || 'general').toLowerCase();
          if (!byCategory[cat]) byCategory[cat] = [];
          byCategory[cat].push(cmd.name);
        }
      });
      Object.values(byCategory).forEach((arr) => arr.sort());

      const ownerNames = Array.isArray(config.ownerName) ? config.ownerName : [config.ownerName];
      const displayOwner = ownerNames[0] || 'Bot Owner';
      const pushName = (extra.pushName || extra.sender.split('@')[0] || 'there');
      const ping = Math.floor(Math.random() * 90) + 10;
      const uptimeStr = runtime(process.uptime()) || '0s';
      const prefix = config.prefix;

      let menu = '';
      menu += `┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n`;
      menu += `┃   ⚡  J  A  R  V  I  S  ⚡   ┃\n`;
      menu += `┃    ◈ ULTRA INTERFACE ◈    ┃\n`;
      menu += `┗━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n`;
      menu += `     ▂ ▄ ▆ █ ▆ ▄ ▂ ▄ ▆ █ ▆ ▄ ▂\n\n`;
      menu += `  ❝ Hello ${pushName}, systems online. ❞\n\n`;
      menu += `┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n`;
      menu += `┃  ◈ STATUS  ➤ ACTIVE\n`;
      menu += `┃  ◈ MODE    ➤ ULTRA\n`;
      menu += `┃  ◈ PING    ➤ ${ping}ms\n`;
      menu += `┃  ◈ UPTIME  ➤ ${uptimeStr}\n`;
      menu += `┃  ◈ PREFIX  ➤ ${prefix}\n`;
      menu += `┃  ◈ COMMANDS➤ ${commands.size}\n`;
      menu += `┃  ◈ OWNER   ➤ ${displayOwner}\n`;
      menu += `┗━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n`;
      menu += `     ▂ ▄ ▆ █ ▆ ▄ ▂ ▄ ▆ █ ▆ ▄ ▂\n\n`;

      for (const section of SECTIONS) {
        const all = byCategory[section.key] || [];
        const names = section.filter ? all.filter((n) => section.filter(n)) : all;
        const box = buildBox(section.title, section.emoji, names, prefix);
        if (box) menu += box + '\n';
      }

      menu += `     ▂ ▄ ▆ █ ▆ ▄ ▂ ▄ ▆ █ ▆ ▄ ▂\n\n`;
      menu += `💡 Type ${prefix}help <command> for details\n`;
      let botVer = '1.0.0';
      try {
        botVer = JSON.parse(fs.readFileSync(path.join(__dirname, '../../package.json'), 'utf8')).version || '1.0.0';
      } catch (_) {}
      menu += `\n┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n`;
      menu += `┃   ⚡ J A R V I S  S Y S T E M ⚡\n`;
      menu += `┃      ◈ v${botVer} ULTRA ◈\n`;
      menu += `┗━━━━━━━━━━━━━━━━━━━━━━━━━┛\n`;

      const imagePath = path.join(__dirname, '../../utils/bot_image.jpg');

      if (fs.existsSync(imagePath)) {
        const imageBuffer = fs.readFileSync(imagePath);
        await sock.sendMessage(extra.from, {
          image: imageBuffer,
          caption: menu,
          mentions: [extra.sender],
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: config.newsletterJid || '120363406636688300@newsletter',
              newsletterName: config.botName,
              serverMessageId: -1
            }
          }
        }, { quoted: msg });
      } else {
        await sock.sendMessage(extra.from, {
          text: menu,
          mentions: [extra.sender]
        }, { quoted: msg });
      }

    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
