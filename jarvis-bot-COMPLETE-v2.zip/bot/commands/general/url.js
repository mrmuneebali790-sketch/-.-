/**
 * URL Command
 * Upload the sent/replied media and return a shareable URL
 */

const { downloadMedia, uploadFile } = require('../../utils/helpers');
const { channelInfo } = require('../lib/messageConfig');

module.exports = {
  name: 'url',
  aliases: ['tourl', 'mediaurl'],
  category: 'general',
  description: 'Upload sent or replied media and get a shareable URL',
  usage: '.url (send or reply to an image/video/audio/document/sticker)',

  async execute(sock, msg, args, extra) {
    try {
      const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;
      let mediaMessage = null;

      // Prefer media in the current message, else fall back to quoted media
      const direct = msg.message || {};
      const directTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'];
      for (const t of directTypes) {
        if (direct[t]) { mediaMessage = { [t]: direct[t] }; break; }
      }

      if (!mediaMessage && ctxInfo?.quotedMessage) {
        const quoted = ctxInfo.quotedMessage;
        for (const t of directTypes) {
          if (quoted[t]) { mediaMessage = { [t]: quoted[t] }; break; }
        }
      }

      if (!mediaMessage) {
        return extra.reply('📎 Send or reply to a media file (image, video, audio, document, or sticker) with `.url` to get a shareable link.');
      }

      await extra.reply('⏳ Uploading media, please wait...');

      const buffer = await downloadMedia(mediaMessage);
      const link = await uploadFile(buffer);

      await sock.sendMessage(extra.from, {
        text: `🔗 *Media URL:*\n${link}\n\n_Note: this link may expire after a period of time._`,
        ...channelInfo,
      }, { quoted: msg });

    } catch (error) {
      console.error('URL command error:', error);
      await extra.reply('❌ Failed to upload media. Please try again later.');
    }
  },
};
