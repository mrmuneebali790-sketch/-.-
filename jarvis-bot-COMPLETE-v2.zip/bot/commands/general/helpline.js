/**
 * Helpline Command - Verified Pakistan harassment / cybercrime helplines
 * Purely informational — lists official numbers, does not collect or send anyone's data.
 */

const MESSAGE_TEXT =
`╔═══━━━─── • ───━━━═══╗
🆘 𝐇𝐄𝐋𝐏𝐋𝐈𝐍𝐄𝐒 & 𝐒𝐔𝐏𝐏𝐎𝐑𝐓 (𝐏𝐀𝐊𝐈𝐒𝐓𝐀𝐍)
╚═══━━━─── • ───━━━═══╝

If someone is harassing you via calls/messages, blackmailing you, or harassing you online — these are official, free helplines that can take real legal action:

📞 𝐍𝐂𝐂𝐈𝐀 (𝐂𝐲𝐛𝐞𝐫𝐜𝐫𝐢𝐦𝐞 𝐖𝐢𝐧𝐠, 𝐟𝐨𝐫𝐦𝐞𝐫𝐥𝐲 𝐅𝐈𝐀)
Helpline: 051-9106691
Email: helpdesk@nr3c.gov.pk
Website: nr3c.gov.pk

📞 𝐏𝐂𝐒𝐖 𝐖𝐨𝐦𝐞𝐧'𝐬 𝐇𝐞𝐥𝐩𝐥𝐢𝐧𝐞 (𝐏𝐮𝐧𝐣𝐚𝐛)
1043 — free, 24/7

╭───────────────⭓
│ 📌 What to do:
│ 1. Save a screenshot of the harassing messages/calls
│ 2. Don't block the number right away — preserve the evidence first
│ 3. File a complaint with the helplines listed above
╰───────────────⭓

⚠️ This bot cannot retrieve any number's private details (name, address, CNIC) — that data is only held by official authorities. Only they can legally help you.

💖 You are not alone — asking for help is the right step.`;

module.exports = {
  name: 'helpline',
  aliases: ['helpme', 'harassment', 'cybercrime'],
  category: 'general',
  description: 'Get verified Pakistan harassment/cybercrime helpline numbers',
  usage: '.helpline',
  ownerOnly: false,
  groupOnly: false,
  privateOnly: false,

  async execute(sock, msg, args, extra) {
    try {
      await sock.sendMessage(extra.from, { text: MESSAGE_TEXT }, { quoted: msg });
    } catch (e) {
      console.error('[helpline] ERROR:', e.message);
      await extra.reply('❌ Something went wrong, please try again.');
    }
  }
};
