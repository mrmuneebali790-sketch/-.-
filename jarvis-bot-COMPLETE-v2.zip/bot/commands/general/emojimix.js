'use strict';

const fetch = require('node-fetch');
const fs    = require('fs');
const path  = require('path');
const { exec } = require('child_process');

// Converts an emoji string into its hex codepoint form, e.g. "😎" -> "1f60e"
// Strips the FE0F variation selector which breaks lookups on some APIs.
function emojiToCodepoint(emoji) {
  return Array.from(emoji)
    .map(char => char.codePointAt(0).toString(16))
    .filter(cp => cp !== 'fe0f')
    .join('-');
}

// Pre-rendered watermark image (the decorative "JARVIS" block).
// Pre-rendering it once as a PNG means we just overlay it with ffmpeg at
// runtime — no font installation or Unicode/emoji rendering support needed
// on the server, since the text is already "burnt in" as pixels.
const WATERMARK_PATH = path.join(__dirname, 'assets', 'watermark.png');
const WATERMARK_WIDTH  = 460; // must match the actual watermark.png dimensions
const WATERMARK_HEIGHT = 205;
const EMOJI_AREA_HEIGHT = 512 - WATERMARK_HEIGHT; // top region reserved for the mixed emoji

async function fetchWithTimeout(url, ms) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), ms);
  try {
    return await fetch(url, { signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

// Primary source: Tenor's Emoji Kitchen collection (can silently fail if the
// shared public API key is rate-limited / revoked — that's the #1 real-world
// cause of "cannot be mixed" errors on every single input).
async function getImageFromTenor(emoji1, emoji2) {
  const url = `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`;

  const response = await fetchWithTimeout(url, 12000);
  const data = await response.json();

  // Log the raw response whenever there are no results — this is what tells
  // you WHY it's failing (quota exceeded / API key invalid / truly no combo).
  if (!data.results || data.results.length === 0) {
    console.error('[EMOJIMIX] Tenor returned no results. Raw response:', JSON.stringify(data));
    return null;
  }

  return data.results[0].url;
}

// Fallback source: no API key needed, works off Unicode codepoints directly.
async function getImageFromEmojik(emoji1, emoji2) {
  const cp1 = emojiToCodepoint(emoji1);
  const cp2 = emojiToCodepoint(emoji2);
  const url = `https://emojik.vercel.app/s/${cp1}_${cp2}?size=512`;

  const response = await fetchWithTimeout(url, 12000);
  if (!response.ok) {
    console.error('[EMOJIMIX] emojik fallback failed with status:', response.status);
    return null;
  }
  return url; // this endpoint returns the image directly, so the URL IS the image
}

async function doEmojiMix(sock, msg, args, extra) {
  const chatId = msg.key.remoteJid;

  const query = args.join(' ').trim();

  if (!query) {
    return sock.sendMessage(chatId, {
      text: '🎴 Usage: *.emojimix 😎+🥰*\n\nSeparate two emojis with a *+* sign to mix them into a sticker!'
    }, { quoted: msg });
  }

  if (!query.includes('+')) {
    return sock.sendMessage(chatId, {
      text: '✳️ Separate the two emojis with a *+* sign\n\n📌 Example:\n*.emojimix* 😎+🥰'
    }, { quoted: msg });
  }

  const [emoji1, emoji2] = query.split('+').map(e => e.trim());

  if (!emoji1 || !emoji2) {
    return sock.sendMessage(chatId, {
      text: '❌ Please provide two emojis separated by *+*\n\nExample: .emojimix 😎+🥰'
    }, { quoted: msg });
  }

  try {
    // Try Tenor first, fall back to emojik if it gives nothing.
    let imageUrl = null;
    try {
      imageUrl = await getImageFromTenor(emoji1, emoji2);
    } catch (tenorErr) {
      console.error('[EMOJIMIX] Tenor request threw an error:', tenorErr.message);
    }

    if (!imageUrl) {
      imageUrl = await getImageFromEmojik(emoji1, emoji2);
    }

    if (!imageUrl) {
      return sock.sendMessage(chatId, {
        text: '❌ These emojis cannot be mixed! Try different ones.\n\nExample: .emojimix 😎+🥰'
      }, { quoted: msg });
    }

    const tmpDir = path.join(process.cwd(), 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

    const tempFile   = path.join(tmpDir, `emix_${Date.now()}.png`);
    const outputFile = path.join(tmpDir, `emix_${Date.now()}_out.webp`);

    const imgResp = await fetchWithTimeout(imageUrl, 15000);
    if (!imgResp.ok) throw new Error(`Image download failed with status ${imgResp.status}`);
    const buffer = await imgResp.buffer();
    fs.writeFileSync(tempFile, buffer);

    // Layout: emoji scaled/centered into the top region, watermark image
    // overlaid centered in the bottom region — both composited onto a
    // transparent 512x512 canvas.
    const hasWatermark = fs.existsSync(WATERMARK_PATH);

    await new Promise((resolve, reject) => {
      let cmd;
      if (hasWatermark) {
        const wmX = Math.round((512 - WATERMARK_WIDTH) / 2);
        const filter =
          `[0:v]scale=512:${EMOJI_AREA_HEIGHT}:force_original_aspect_ratio=decrease,format=rgba,` +
          `pad=512:${EMOJI_AREA_HEIGHT}:(ow-iw)/2:(oh-ih)/2:color=#00000000[emoji];` +
          `color=c=#00000000:s=512x512[canvas];` +
          `[canvas][emoji]overlay=0:0[tmp1];` +
          `[tmp1][1:v]overlay=${wmX}:${EMOJI_AREA_HEIGHT}[out]`;
        cmd = `ffmpeg -i "${tempFile}" -i "${WATERMARK_PATH}" -filter_complex "${filter}" -map "[out]" -update 1 -frames:v 1 "${outputFile}" -y`;
      } else {
        // Watermark asset missing — still deliver the plain sticker instead of failing outright.
        console.error('[EMOJIMIX] watermark.png not found at', WATERMARK_PATH, '— sending without watermark.');
        const vf = `scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000`;
        cmd = `ffmpeg -i "${tempFile}" -vf "${vf}" "${outputFile}" -y`;
      }
      exec(cmd, { timeout: 20000 }, (err, _stdout, stderr) => {
        if (err) {
          console.error('[EMOJIMIX] ffmpeg composite failed:', stderr);
          reject(err);
        } else {
          resolve();
        }
      });
    });

    if (!fs.existsSync(outputFile)) throw new Error('Sticker conversion failed');

    const stickerBuffer = fs.readFileSync(outputFile);
    await sock.sendMessage(chatId, { sticker: stickerBuffer }, { quoted: msg });

    try { fs.unlinkSync(tempFile);   } catch (_) {}
    try { fs.unlinkSync(outputFile); } catch (_) {}

  } catch (err) {
    console.error('[EMOJIMIX] Error:', err.message);
    await sock.sendMessage(chatId, {
      text: '❌ Failed to mix emojis! Make sure you\'re using valid emojis.\n\nExample: .emojimix 😎+🥰'
    }, { quoted: msg });
  }
}

module.exports = {
  name    : 'emojimix',
  aliases : ['emix', 'mixemoji'],
  category: 'general',
  desc    : 'Mix two emojis together to create a unique sticker',
  usage   : '.emojimix 😎+🥰',
  execute : (sock, msg, args, extra) => doEmojiMix(sock, msg, args, extra),
};
