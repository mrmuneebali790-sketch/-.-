'use strict';

const gTTS = require('gtts');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

module.exports = {
  name    : 'tts',
  aliases : ['texttospeech', 'speak'],
  category: 'general',
  desc    : 'Convert text to speech audio',
  usage   : '.tts <text>  or reply to a message',

  async execute(sock, msg, args, extra) {
    const chatId = msg.key.remoteJid;

    let text = args.join(' ').trim();

    if (!text) {
      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      text = quoted?.conversation
          || quoted?.extendedTextMessage?.text
          || quoted?.imageMessage?.caption
          || quoted?.videoMessage?.caption
          || '';
    }

    if (!text) {
      return sock.sendMessage(chatId, {
        text: '🗣️ Usage: *.tts <text>*\nExample: .tts Hello World\n\nOr reply to any message with *.tts*'
      }, { quoted: msg });
    }

    const filePath = path.join(os.tmpdir(), `tts-${Date.now()}.mp3`);

    try {
      await new Promise((resolve, reject) => {
        const gtts = new gTTS(text, 'en');
        gtts.save(filePath, (err) => err ? reject(err) : resolve());
      });

      const audioBuffer = fs.readFileSync(filePath);

      await sock.sendMessage(chatId, {
        audio    : audioBuffer,
        mimetype : 'audio/mpeg',
        ptt      : false,
      }, { quoted: msg });

    } catch (err) {
      console.error('[TTS] Error:', err.message);
      await sock.sendMessage(chatId, {
        text: '❌ Error generating TTS audio. Please try again.'
      }, { quoted: msg });
    } finally {
      try { fs.unlinkSync(filePath); } catch (_) {}
    }
  },
};
