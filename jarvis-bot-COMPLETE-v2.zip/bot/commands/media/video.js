/**
 * YouTube Video Downloader — v7
 *
 * FORMAT STRATEGY:
 *   Format 18 = pre-merged 360p MP4 (video+audio in one stream, no ffmpeg needed)
 *   Avoids adaptive streams (720p=429MB + audio=101MB = 530MB crash risk)
 *
 * SIZE RULES:
 *   < 50 MB   → WhatsApp video message (plays inline)
 *   50–400 MB → WhatsApp document (downloadable)
 *   > 400 MB  → Send direct stream URL as a link (no download attempt)
 *
 * FALLBACK CHAIN:
 *   Tier 1 — YouTube yt-dlp android_vr (default)
 *   Tier 2 — YouTube yt-dlp android client
 *   Tier 3 — YouTube yt-dlp tv_embedded client
 *   Tier 4 — YouTube yt-dlp any format
 *   Tier 5 — Dailymotion: API search → yt-dlp --get-url → ffmpeg download
 *
 * WHY DAILYMOTION:
 *   YouTube blocks popular South Asian music videos from Replit IPs ("Sign in
 *   to confirm you're not a bot"). Dailymotion has the same content and
 *   yt-dlp can extract the m3u8 URL; ffmpeg downloads it cleanly.
 */

'use strict';

const yts        = require('yt-search');
const fs         = require('fs');
const https      = require('https');
const os         = require('os');
const path       = require('path');
const { execFile, spawn } = require('child_process');
const config     = require('../../config');
const ytdlp      = require('../../utils/ytdlp');
const { deleteTempFile } = require('../../utils/mediaDownloader');

// ── Size limits ───────────────────────────────────────────────────────────────
const VIDEO_MSG_MAX_MB = 50;    // inline video
const DOC_MAX_MB       = 400;   // document limit; above this → send stream URL

// ── Download strategies — tried in order until one succeeds ───────────────────
const DOWNLOAD_STRATEGIES = [
  {
    name         : 'android_vr (default)',
    format       : 'bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=360]+bestaudio/18/best',
    extractorArgs: null,
  },
  {
    name         : 'android client',
    format       : 'bestvideo[height<=360][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=360]+bestaudio/18/best',
    extractorArgs: 'youtube:player_client=android',
  },
  {
    name         : 'tv_embedded client',
    format       : 'bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=480]+bestaudio/best[height<=480]/best',
    extractorArgs: 'youtube:player_client=tv_embedded',
  },
  {
    name         : 'any format (last resort)',
    format       : 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/bestvideo[height<=720]+bestaudio/best[height<=720]/best',
    extractorArgs: 'youtube:player_client=tv_embedded',
  },
];

// ── Dailymotion fallback helpers ──────────────────────────────────────────────

/** Search Dailymotion API, return array of {id, title, url}. */
function dmSearch(query) {
  return new Promise(resolve => {
    const q = encodeURIComponent(String(query || '').trim());
    if (!q) return resolve([]);
    https.get({
      hostname: 'api.dailymotion.com',
      path    : `/videos?search=${q}&limit=10&fields=id,title,url&sort=relevance`,
      timeout : 12_000,
      headers : { 'User-Agent': 'Mozilla/5.0' },
    }, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try {
          const body = JSON.parse(d);
          resolve(Array.isArray(body.list) ? body.list.filter(v => v?.id) : []);
        }
        catch { resolve([]); }
      });
    })
    .on('error', () => resolve([]))
    .on('timeout', function () { this.destroy(); resolve([]); });
  });
}

/**
 * YouTube titles often contain search-hostile decorations such as emoji,
 * "[Official Video]", "(4K Remaster)", artist separators, and long metadata.
 * Dailymotion search is more reliable with short meaningful variants.
 */
function dailymotionQueries(title) {
  const raw = String(title || '').replace(/\s+/g, ' ').trim();
  if (!raw) return [];

  const withoutDecorations = raw
    .replace(/\[[^\]]*\]|\([^)]*\)/g, ' ')
    .replace(/\b(official|officially|music|video|audio|lyrics?|visualizer|4k|8k|hd|full|remaster(?:ed)?)\b/gi, ' ')
    .replace(/[|•·]/g, ' ')
    .replace(/[^\p{L}\p{N}\s'&-]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  const beforeSeparator = raw.split(/\s+[|:]\s+|\s+-\s+/)[0].trim();
  const words = withoutDecorations.split(/\s+/).filter(Boolean);

  return [...new Set([
    raw.slice(0, 140),
    withoutDecorations.slice(0, 120),
    beforeSeparator.slice(0, 120),
    words.slice(0, 9).join(' '),
    words.slice(0, 6).join(' '),
  ].filter(q => q.length >= 2))];
}

function titleTokens(value) {
  return String(value || '').toLowerCase().match(/[\p{L}\p{N}]+/gu) || [];
}

function minimumTitleScore(tokenCount) {
  if (tokenCount <= 2) return tokenCount;
  return Math.max(2, Math.ceil(tokenCount * 0.35));
}

/** Search normalized variants and rank results by token overlap. */
async function searchDailymotion(title) {
  const queries = dailymotionQueries(title);
  let best = [];
  let bestQuery = '';

  for (const query of queries) {
    const results = await dmSearch(query);
    if (!results.length) continue;

    const wanted = new Set(titleTokens(query).filter(token => token.length > 1));
    const minimumScore = minimumTitleScore(wanted.size);
    const ranked = results
      .map(video => {
        const candidate = new Set(titleTokens(video.title));
        const score = [...wanted].reduce((n, token) => n + (candidate.has(token) ? 1 : 0), 0);
        return {
          video,
          score,
          ratio: wanted.size ? score / wanted.size : 0,
        };
      })
      .filter(item => item.score >= minimumScore)
      .sort((a, b) => b.score - a.score || b.ratio - a.ratio)
      .map(item => item.video);

    if (ranked.length > best.length) {
      best = ranked;
      bestQuery = query;
    }

    if (ranked.length) {
      return { results: ranked, query };
    }
  }

  return { results: best, query: bestQuery };
}

/** Resolve a YouTube title without using the blocked media extractor. */
function youtubeOembedTitle(url) {
  return new Promise(resolve => {
    let parsed;
    try { parsed = new URL(url); } catch (_) { return resolve(''); }
    const endpoints = [
      {
        hostname: 'www.youtube.com',
        path: `/oembed?url=${encodeURIComponent(parsed.toString())}&format=json`,
      },
      {
        hostname: 'noembed.com',
        path: `/embed?url=${encodeURIComponent(parsed.toString())}`,
      },
    ];

    const next = (index) => {
      if (index >= endpoints.length) return resolve('');
      const req = https.get({
        ...endpoints[index],
        timeout: 12_000,
        headers: { 'User-Agent': 'Mozilla/5.0' },
      }, res => {
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => {
          try {
            const title = JSON.parse(body).title || '';
            if (title) return resolve(title);
          } catch (_) {}
          next(index + 1);
        });
      });
      req.on('error', () => next(index + 1));
      req.on('timeout', () => { req.destroy(); next(index + 1); });
    };

    next(0);
  });
}

/** Get direct video/audio m3u8 URLs from Dailymotion via yt-dlp --get-url. */
function dmGetUrl(dmUrl) {
  return new Promise((resolve, reject) => {
    const args = [
      '--no-playlist', '--no-check-certificates', '--geo-bypass',
      '--no-warnings', '--get-url',
      '-f', 'bestvideo[height<=480]+bestaudio/best[height<=480]/best',
      '--', dmUrl,
    ];
    execFile(ytdlp.YTDLP_PATH, args, { timeout: 30_000 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(`DM url-extract: ${stderr?.trim().slice(0, 120) || err.message}`));
      const urls = stdout.trim().split(/\r?\n/).filter(l => l.startsWith('http'));
      if (!urls.length) return reject(new Error('DM: no URL returned'));
      resolve(urls);
    });
  });
}

/** Download one or separate video/audio URLs to destPath using ffmpeg. */
function ffmpegDownload(streamUrl, destPath) {
  return new Promise((resolve, reject) => {
    if (!ytdlp.FFMPEG_PATH) return reject(new Error('ffmpeg not found'));
    const urls = Array.isArray(streamUrl) ? streamUrl : [streamUrl];
    const args = ['-y'];
    for (const url of urls) args.push('-i', url);
    if (urls.length >= 2) {
      args.push(
        '-map', '0:v:0?', '-map', '1:a:0?',
        '-c:v', 'copy', '-c:a', 'copy',
      );
    } else {
      args.push('-c', 'copy');
    }
    args.push('-movflags', '+faststart', destPath);
    const proc  = spawn(ytdlp.FFMPEG_PATH, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    let stderr  = '';
    let resolved = false;

    const timer = setTimeout(() => {
      if (!resolved) { proc.kill('SIGKILL'); resolved = true; reject(new Error('ffmpeg timed out')); }
    }, 240_000);

    proc.stderr.on('data', d => { stderr += d.toString(); });
    proc.on('close', code => {
      clearTimeout(timer);
      if (resolved) return;
      resolved = true;
      if (code === 0 && fs.existsSync(destPath)) resolve();
      else reject(new Error(`ffmpeg exit ${code}: ${stderr.slice(-300)}`));
    });
    proc.on('error', e => { clearTimeout(timer); if (!resolved) { resolved = true; reject(e); } });
  });
}

/** Full Dailymotion search → download → send pipeline */
async function downloadAndSendViaDailymotion(sock, chatId, searchTitle, statusKey, quotedMsg) {
  const botName = config.botName || 'Bot';
  console.log(`[VIDEO] [DM] Searching Dailymotion for: "${searchTitle}"`);

  const search = await searchDailymotion(searchTitle);
  const results = search.results;
  if (!results.length) {
    throw new Error(
      `Dailymotion: no matching copy found after ${dailymotionQueries(searchTitle).length || 1} search variants`
    );
  }

  // Pick first result
  const dmVideo = results[0];
  const title   = dmVideo.title || searchTitle;
  const dmUrl   = dmVideo.url || `https://www.dailymotion.com/video/${dmVideo.id}`;
  console.log(`[VIDEO] [DM] Found via "${search.query}": "${title}" → ${dmUrl}`);

  await editStatus(sock, chatId, statusKey,
    `📺 *Found on Dailymotion:* _${title}_\n⬇️ Downloading...`
  );

  // Extract stream URL
  const streamUrl = await dmGetUrl(dmUrl);
  console.log(`[VIDEO] [DM] Stream URL extracted, downloading via ffmpeg...`);

  const tmpFile = path.join(os.tmpdir(), `dm_${Date.now()}.mp4`);
  try {
    await ffmpegDownload(streamUrl, tmpFile);

    const sizeMB = fs.existsSync(tmpFile)
      ? +(fs.statSync(tmpFile).size / 1024 / 1024).toFixed(1)
      : 0;
    console.log(`[VIDEO] [DM] Downloaded: ${sizeMB} MB`);

    if (sizeMB === 0) throw new Error('Dailymotion: download produced empty file');
    if (sizeMB > DOC_MAX_MB) throw new Error(`Dailymotion: file too large (${sizeMB.toFixed(0)} MB)`);

    const safeFile = title.replace(/[^\w\s\-]/g, '').trim().slice(0, 80) || 'video';
    const caption  = `*${title}*\n\n> *_Downloaded by JARVIS_*`;

    await editStatus(sock, chatId, statusKey, '📤 *Uploading to WhatsApp...*');

    const buf = fs.readFileSync(tmpFile);
    if (sizeMB > VIDEO_MSG_MAX_MB) {
      await sock.sendMessage(chatId, {
        document : buf, mimetype: 'video/mp4',
        fileName : `${safeFile}.mp4`,
        caption  : `${caption}\n\n📁 *Sent as file* (${sizeMB.toFixed(0)} MB)\n_Tap to download / play_`,
      }, { quoted: quotedMsg });
    } else {
      await sock.sendMessage(chatId, {
        video: buf, mimetype: 'video/mp4', fileName: `${safeFile}.mp4`, caption,
      }, { quoted: quotedMsg });
    }
    await sock.sendMessage(chatId, { react: { text: '✅', key: quotedMsg.key } }).catch(() => {});
    console.log(`[VIDEO] [DM] ✅ Sent: "${title}"`);
  } finally {
    deleteTempFile(tmpFile);
  }
}

// ── Progress bar helper ───────────────────────────────────────────────────────
function bar(pct) {
  const n = Math.max(0, Math.min(10, Math.round(pct / 10)));
  return '█'.repeat(n) + '░'.repeat(10 - n) + ` ${Math.round(pct)}%`;
}

// Edit the status message (silently fails if edit not supported)
async function editStatus(sock, chatId, key, text) {
  if (!key) return;
  try { await sock.sendMessage(chatId, { text, edit: key }); } catch (_) {}
}

// ── Get best stream URL (for link fallback on very large videos) ──────────────
async function getStreamUrl(ytUrl) {
  try {
    const urls = await ytdlp.getUrl(ytUrl, '18/best[height<=360][ext=mp4]/best[height<=480][ext=mp4]/best[ext=mp4]/best');
    return urls?.[0] || null;
  } catch { return null; }
}

// ── Core download + send (one strategy attempt) ───────────────────────────────
async function downloadAndSend(sock, chatId, ytUrl, knownTitle, statusMsgKey, quotedMsg, strategy) {
  const botName = config.botName || 'Bot';

  const tmpOut = ytdlp.tmpPath('ytv', '.mp4');
  let outFile  = null;
  let lastPct  = -1;
  let lastEdit = 0;

  const onProgress = async (pct) => {
    if (pct - lastPct < 5 || Date.now() - lastEdit < 4000) return;
    lastPct  = pct;
    lastEdit = Date.now();
    await editStatus(sock, chatId, statusMsgKey,
      `⬇️ *Downloading...*\n\n${bar(pct)}\n💬 Bot stays responsive while downloading!`
    );
  };

  try {
    console.log(`[VIDEO] [${strategy.name}] yt-dlp → ${ytUrl}`);

    const result = await ytdlp.download(ytUrl, tmpOut, {
      format       : strategy.format,
      extractorArgs: strategy.extractorArgs,
      onProgress,
      timeout      : 300_000,
    });

    outFile = result.outputPath;
    const title  = result.title || knownTitle || 'YouTube Video';
    const sizeMB = result.sizeMB;
    console.log(`[VIDEO] [${strategy.name}] Done: ${sizeMB} MB → "${title}"`);

    // ── Extremely large: send stream link instead of file ────────────────────
    if (sizeMB > DOC_MAX_MB) {
      const streamUrl = await getStreamUrl(ytUrl);
      const linkLine  = streamUrl
        ? `\n\n🔗 *Direct stream link:*\n${streamUrl}`
        : '';
      await editStatus(sock, chatId, statusMsgKey,
        `⚠️ *File too large to send (${sizeMB.toFixed(0)} MB)*\n\n` +
        `WhatsApp limit is ${DOC_MAX_MB} MB. Try a shorter clip.${linkLine}`
      );
      return;
    }

    const safeFile = title.replace(/[^\w\s\-]/g, '').trim().slice(0, 80) || 'video';
    const caption  = `*${title}*\n\n> *_Downloaded by JARVIS_*`;

    await editStatus(sock, chatId, statusMsgKey, '📤 *Uploading to WhatsApp...*');

    const buf = fs.readFileSync(outFile);

    if (sizeMB > VIDEO_MSG_MAX_MB) {
      await sock.sendMessage(chatId, {
        document : buf,
        mimetype : 'video/mp4',
        fileName : `${safeFile}.mp4`,
        caption  : `${caption}\n\n📁 *Sent as file* (${sizeMB.toFixed(0)} MB)\n_Tap to download / play_`,
      }, { quoted: quotedMsg });
    } else {
      await sock.sendMessage(chatId, {
        video   : buf,
        mimetype: 'video/mp4',
        fileName: `${safeFile}.mp4`,
        caption,
      }, { quoted: quotedMsg });
    }

    await sock.sendMessage(chatId, { react: { text: '✅', key: quotedMsg.key } }).catch(() => {});

  } finally {
    if (outFile) deleteTempFile(outFile);
    const base = tmpOut.replace(/\.\w+$/, '');
    for (const x of ['mp4', 'mkv', 'webm', 'm4v', 'part', 'ytdl']) {
      deleteTempFile(`${base}.${x}`);
    }
  }
}

// ── Multi-strategy cascading downloader ──────────────────────────────────────
// Tier 1-4: YouTube yt-dlp with different clients
// Tier 5:   Dailymotion (API search → yt-dlp --get-url → ffmpeg)
async function downloadWithFallback(sock, chatId, ytUrl, title, statusKey, quotedMsg) {
  const TOTAL = DOWNLOAD_STRATEGIES.length + 1; // +1 for Dailymotion
  let lastErr;

  // ── Tiers 1–4: YouTube yt-dlp strategies ─────────────────────────────────
  for (let i = 0; i < DOWNLOAD_STRATEGIES.length; i++) {
    const strategy  = DOWNLOAD_STRATEGIES[i];
    const stratLabel = `Tier ${i + 1}/${TOTAL}: ${strategy.name}`;

    try {
      console.log(`[VIDEO] Trying ${stratLabel}`);
      return await downloadAndSend(sock, chatId, ytUrl, title, statusKey, quotedMsg, strategy);
    } catch (err) {
      lastErr = err;
      console.warn(`[VIDEO] ${stratLabel} failed: ${err.message}`);

      await editStatus(sock, chatId, statusKey,
        `🔄 *YouTube method ${i + 1} failed — trying ${i + 2 <= DOWNLOAD_STRATEGIES.length ? `backup method ${i + 2}` : 'Dailymotion'}...*\n_${err.message.slice(0, 100)}_`
      );
      await new Promise(r => setTimeout(r, 1500));
    }
  }

  // ── Tier 5: Dailymotion fallback ──────────────────────────────────────────
  // Only useful when we have a search title (not a raw YouTube URL with no title)
  const searchTitle = title || '';
  if (searchTitle.trim()) {
    try {
      console.log(`[VIDEO] Trying Tier ${TOTAL}/${TOTAL}: Dailymotion`);
      await editStatus(sock, chatId, statusKey,
        `📺 *YouTube blocked — switching to Dailymotion...*\n_Searching for: ${searchTitle}_`
      );
      return await downloadAndSendViaDailymotion(sock, chatId, searchTitle, statusKey, quotedMsg);
    } catch (dmErr) {
      lastErr = dmErr;
      console.warn(`[VIDEO] Tier ${TOTAL} Dailymotion failed: ${dmErr.message}`);
    }
  }

  // All tiers exhausted
  throw new Error(
    `All ${TOTAL} download methods failed.\n` +
    `• YouTube: bot detection / video blocked\n` +
    `• Dailymotion: ${lastErr?.message?.slice(0, 120) || 'not found'}\n\n` +
    `_Try another title/link. Direct YouTube downloads may also need a valid cookies file._`
  );
}

// ── Command definition ────────────────────────────────────────────────────────
module.exports = {
  name    : 'ytvideo',
  aliases : ['ytv', 'ytmp4', 'ytvid', 'video'],
  category: 'media',
  description: 'Download video from YouTube (search or direct URL)',
  usage   : '.video <song/movie name or YouTube URL>',

  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;
    try {
      const text = (args || []).join(' ').trim();

      if (!text) {
        return await sock.sendMessage(chatId, {
          text: [
            '📹 *YouTube Video Downloader*',
            '',
            '*Usage:* .video <name or URL>',
            '',
            '*Examples:*',
            '• .video Despacito',
            '• .video Rowdy Rathore full movie',
            '• .video https://youtu.be/abc123',
            '',
            '_Small clips (< 50 MB) → sent as video_',
            '_Movies / dramas (50–400 MB) → sent as document file_',
            '_Very large → direct stream link provided_',
          ].join('\n'),
        }, { quoted: msg });
      }

      await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

      const isUrl = /^https?:\/\//i.test(text);

      // ── Search flow ─────────────────────────────────────────────────────────
      if (!isUrl) {
        const statusMsg = await sock.sendMessage(chatId, {
          text: `🔍 *Searching YouTube...*\n_${text}_\n\n💬 Bot stays responsive!`,
        }, { quoted: msg });

        setImmediate(async () => {
          try {
            const { videos } = await yts(text);
            if (!videos?.length) {
              return await sock.sendMessage(chatId, {
                text: `❌ No results found for: *${text}*\n\nTry a more specific search term.`,
              }, { quoted: msg });
            }
            const v = videos[0];

            // Send thumbnail preview immediately
            try {
              await sock.sendMessage(chatId, {
                image  : { url: v.thumbnail },
                caption: `*${v.title}*\n⬇️ Downloading...`,
              }, { quoted: msg });
            } catch (_) {}

            await editStatus(sock, chatId, statusMsg.key,
              `⬇️ *Downloading:* _${v.title}_`
            );

            await downloadWithFallback(sock, chatId, v.url, v.title, statusMsg.key, msg);

          } catch (err) {
            console.error('[VIDEO] search+dl error:', err.message);
            await editStatus(sock, chatId, statusMsg.key,
              `❌ *Download failed*\n${err.message}`
            );
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } }).catch(() => {});
          }
        });

        return;

      // ── Direct URL flow ─────────────────────────────────────────────────────
      } else {
        const ytMatch = text.match(
          /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/|v\/))([a-zA-Z0-9_-]{11})/i
        );
        if (!ytMatch) {
          return await sock.sendMessage(chatId, {
            text: '❌ Not a valid YouTube link!\n\nExample: https://youtu.be/dQw4w9WgXcQ\n\nFor searches, just type the title without a URL.',
          }, { quoted: msg });
        }
        const ytId = ytMatch[1];

        let statusMsg = null;
        try {
          statusMsg = await sock.sendMessage(chatId, {
            image  : { url: `https://i.ytimg.com/vi/${ytId}/sddefault.jpg` },
            caption: `⬇️ *Starting download...*\n💬 Keep chatting — bot stays responsive!`,
          }, { quoted: msg });
        } catch (_) {
          statusMsg = await sock.sendMessage(chatId, {
            text: '⬇️ *Starting download...*\n💬 Keep chatting!',
          }, { quoted: msg });
        }

        setImmediate(async () => {
          try {
            // oEmbed remains available even when yt-dlp is challenged. The
            // title lets the Dailymotion fallback search for an equivalent
            // public copy instead of silently skipping that tier.
            const directTitle = await youtubeOembedTitle(text.trim());
            await downloadWithFallback(sock, chatId, text.trim(), directTitle, statusMsg?.key, msg);
          } catch (err) {
            console.error('[VIDEO] dl error:', err.message);
            await editStatus(sock, chatId, statusMsg?.key,
              `❌ *Download failed*\n${err.message}`
            );
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } }).catch(() => {});
          }
        });
      }

    } catch (err) {
      console.error('[VIDEO] Unexpected:', err.message);
      await sock.sendMessage(chatId, {
        text: `❌ Unexpected error: ${err.message}`,
      }, { quoted: msg });
    }
  },
};
