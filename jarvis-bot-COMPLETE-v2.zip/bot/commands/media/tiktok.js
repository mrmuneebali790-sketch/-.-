/**
 * TikTok Downloader — v3 (yt-dlp primary)
 *
 * ✔ yt-dlp primary — no watermark, handles all TikTok URL formats
 * ✔ API fallback — 7 sources raced in parallel if yt-dlp fails
 * ✔ Non-blocking — instant reply
 * ✔ Smart send — <50 MB → video | >50 MB → document
 * ✔ Progress via reactions
 */

'use strict';

const fs     = require('fs');
const config = require('../../config');
const APIs   = require('../../utils/api');
const ytdlp  = require('../../utils/ytdlp');
const { withRace, downloadBuffer, getFileSizeMB, deleteTempFile } = require('../../utils/mediaDownloader');

const MAX_VIDEO_MB = 50;
const processed    = new Set();

// ── Download via yt-dlp ───────────────────────────────────────────────────────
async function downloadWithYtdlp(url) {
  const tmpOut = ytdlp.tmpPath('tt', '.mp4');
  const result = await ytdlp.download(url, tmpOut, {
    // TikTok normally exposes a single muxed MP4; keep an adaptive fallback
    // for newer responses where video and audio are separate.
    format : 'best[ext=mp4]/bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best',
    timeout: 120_000,
  });
  return result; // { title, sizeMB, outputPath }
}

// ── Download via fallback APIs ────────────────────────────────────────────────
async function downloadWithApis(url) {
  const result   = await withRace(APIs.getTikTokSources(url), 'TikTok');
  const videoUrl = result.videoUrl;
  if (!videoUrl) throw new Error('No video URL from API sources');

  const sizeMB  = await getFileSizeMB(videoUrl);
  const isLarge = sizeMB > MAX_VIDEO_MB;

  return { videoUrl, title: result.title || 'TikTok Video', sizeMB, isLarge };
}

// ── Command ───────────────────────────────────────────────────────────────────
module.exports = {
  name    : 'tiktok',
  aliases : ['tt', 'ttdl', 'tiktokdl'],
  category: 'media',
  description: 'Download TikTok videos (no watermark)',
  usage   : '.tiktok <TikTok URL>',

  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;
    try {
      if (processed.has(msg.key.id)) return;
      processed.add(msg.key.id);
      setTimeout(() => processed.delete(msg.key.id), 5 * 60 * 1000);

      const url = args.join(' ').trim();

      if (!url) {
        return await sock.sendMessage(chatId, {
          text: '🎵 *TikTok Downloader*\n\nUsage: *.tiktok <TikTok URL>*\n\nExample:\n• .tt https://vm.tiktok.com/xxxxx',
        }, { quoted: msg });
      }

      if (!/tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(url)) {
        return await sock.sendMessage(chatId, {
          text: '❌ Please provide a valid TikTok link.',
        }, { quoted: msg });
      }

      // Instant reply
      await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });
      await sock.sendMessage(chatId, {
        text: '📥 *TikTok Download Started*\n\n⏱ Usually 5–20 seconds.\n💬 You can keep chatting!',
      }, { quoted: msg });

      // Non-blocking download
      setImmediate(async () => {
        const botName = config.botName || 'Bot';
        let   tmpFile = null;

        try {
          await sock.sendMessage(chatId, { react: { text: '📤', key: msg.key } }).catch(() => {});

          // ── Primary: yt-dlp ────────────────────────────────────────────
          try {
            const result = await downloadWithYtdlp(url);
            tmpFile = result.outputPath;
            const title   = result.title || 'TikTok Video';
            const sizeMB  = result.sizeMB;
            const caption = `*${title}*\n\n> _Downloaded by ${botName}_`;
            const buf     = fs.readFileSync(tmpFile);

            if (sizeMB > MAX_VIDEO_MB) {
              await sock.sendMessage(chatId, {
                document: buf, mimetype: 'video/mp4', fileName: 'tiktok.mp4',
                caption : `${caption}\n📁 Sent as file (${sizeMB} MB)`,
              }, { quoted: msg });
            } else {
              await sock.sendMessage(chatId, {
                video: buf, mimetype: 'video/mp4', caption,
              }, { quoted: msg });
            }

            await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } }).catch(() => {});
            return;

          } catch (ytdlpErr) {
            console.warn('[TIKTOK] yt-dlp failed:', ytdlpErr.message, '— trying APIs');
          } finally {
            if (tmpFile) { deleteTempFile(tmpFile); tmpFile = null; }
          }

          // ── Fallback: API sources ──────────────────────────────────────
          const apiResult = await downloadWithApis(url);
          const caption   = `*${apiResult.title}*\n\n> _Downloaded by ${botName}_`;

          if (apiResult.isLarge) {
            await sock.sendMessage(chatId, {
              document: { url: apiResult.videoUrl }, mimetype: 'video/mp4', fileName: 'tiktok.mp4',
              caption : `${caption}\n📁 Sent as file (${apiResult.sizeMB.toFixed(0)} MB)`,
            }, { quoted: msg });
          } else {
            const buf = await downloadBuffer(apiResult.videoUrl, {
              headers: { Referer: 'https://www.tiktok.com/' }, timeout: 90_000,
            });
            await sock.sendMessage(chatId, {
              video: buf, mimetype: 'video/mp4', caption,
            }, { quoted: msg });
          }

          await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } }).catch(() => {});

        } catch (err) {
          console.error('[TIKTOK] All sources failed:', err.message);
          await sock.sendMessage(chatId, {
            text: `❌ *TikTok download failed.*\n${err.message}`,
          }, { quoted: msg }).catch(() => {});
          await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } }).catch(() => {});
        }
      });

    } catch (err) {
      console.error('[TIKTOK] Unexpected error:', err.message);
      await sock.sendMessage(chatId, { text: `❌ Unexpected error: ${err.message}` }, { quoted: msg });
    }
  },
};
