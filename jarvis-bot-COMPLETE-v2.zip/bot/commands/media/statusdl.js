'use strict';
/**
 * Status Download — .sd / .statusdl
 * Reply to any status (text, image, video, audio) to download and save it.
 * Works from both DM and group chat.
 */

const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const config = require('../../config');

module.exports = {
  name: 'statusdl',
  aliases: ['sd', 'savedl', 'svdl', 'statusdownload'],
  category: 'media',
  description: "Reply to someone's status to download it",
  usage: '.sd (reply to a status)',
  groupOnly: false,
  privateOnly: false,

  async execute(sock, msg, args, extra) {
    const { from, reply } = extra;

    // ── Get quoted message ────────────────────────────────────────────────────
    const ctxInfo = msg.message?.extendedTextMessage?.contextInfo
                 || msg.message?.imageMessage?.contextInfo
                 || msg.message?.videoMessage?.contextInfo
                 || msg.message?.audioMessage?.contextInfo;

    const quoted    = ctxInfo?.quotedMessage;
    const quotedKey = ctxInfo?.stanzaId
      ? {
          remoteJid  : ctxInfo.remoteJid || 'status@broadcast',
          id         : ctxInfo.stanzaId,
          participant: ctxInfo.participant || undefined,
          fromMe     : false
        }
      : null;

    if (!quoted) {
      return reply(
        `❌ *No status selected!*\n\n` +
        `📌 *How to use:*\n` +
        `1️⃣ Open a contact's status\n` +
        `2️⃣ *Reply* to the status you want to save\n` +
        `3️⃣ Send *.sd* as your reply\n\n` +
        `> Powered by ${config.botName}`
      );
    }

    // ── Detect media type ─────────────────────────────────────────────────────
    const mediaTypes = ['imageMessage', 'videoMessage', 'audioMessage', 'stickerMessage', 'documentMessage'];
    const mediaType  = mediaTypes.find(t => quoted[t]);

    // ── Text-only status ──────────────────────────────────────────────────────
    if (!mediaType) {
      const text = quoted.conversation
                || quoted.extendedTextMessage?.text
                || quoted.ephemeralMessage?.message?.conversation
                || quoted.viewOnceMessage?.message?.extendedTextMessage?.text;

      if (text) {
        return sock.sendMessage(from, {
          text: `📋 *Status Text Saved!*\n\n${text}\n\n> Powered by ${config.botName}`
        }, { quoted: msg });
      }
      return reply(`❌ There is nothing downloadable in this status.`);
    }

    await reply('⏳ *Downloading status...*');

    try {
      // Build proper msg structure for downloadMediaMessage
      const fakeMsg = {
        key    : quotedKey || { remoteJid: from, id: Date.now().toString(), fromMe: false },
        message: quoted
      };

      const buffer = await downloadMediaMessage(
        fakeMsg,
        'buffer',
        {},
        { reuploadRequest: sock.updateMediaMessage }
      );

      if (!buffer || buffer.length < 100) {
        return reply(`❌ Media download failed.\n\nNote: The status may have expired — save it quickly next time!`);
      }

      const mediaInfo = quoted[mediaType];
      const mimetype  = mediaInfo?.mimetype || 'application/octet-stream';
      const caption   = `✅ *Status Saved!*\n\n> Powered by ${config.botName}`;

      if (mediaType === 'imageMessage') {
        await sock.sendMessage(from, {
          image  : buffer,
          caption: mediaInfo.caption ? `${mediaInfo.caption}\n\n> Powered by ${config.botName}` : caption,
          mimetype
        }, { quoted: msg });

      } else if (mediaType === 'videoMessage') {
        await sock.sendMessage(from, {
          video  : buffer,
          caption: mediaInfo.caption ? `${mediaInfo.caption}\n\n> Powered by ${config.botName}` : caption,
          mimetype
        }, { quoted: msg });

      } else if (mediaType === 'audioMessage') {
        await sock.sendMessage(from, {
          audio  : buffer,
          mimetype,
          ptt    : mediaInfo.ptt || false
        }, { quoted: msg });
        await sock.sendMessage(from, { text: caption }, { quoted: msg });

      } else if (mediaType === 'stickerMessage') {
        await sock.sendMessage(from, {
          sticker: buffer,
          mimetype: 'image/webp'
        }, { quoted: msg });
        await sock.sendMessage(from, { text: caption }, { quoted: msg });

      } else {
        await sock.sendMessage(from, {
          document: buffer,
          mimetype,
          fileName: mediaInfo?.fileName || 'status_download'
        }, { quoted: msg });
      }

    } catch (e) {
      console.error('[statusdl]', e.message);
      return reply(
        `❌ *Download failed:*\n${e.message}\n\n` +
        `💡 *Tips:*\n` +
        `• The status may be too old — save it quickly\n` +
        `• View the status manually first, then reply to it`
      );
    }
  }
};
