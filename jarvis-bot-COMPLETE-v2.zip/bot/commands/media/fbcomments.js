'use strict';

/**
 * Facebook Comments Fetcher — .fbcom
 *
 * Fetches top comments from a public Facebook post/video.
 * Uses mbasic.facebook.com HTML scraping — no login, no API key needed.
 * Only works on truly PUBLIC posts. Private/friends-only → clean error message.
 */

const APIs  = require('../../utils/api');
const config = require('../../config');

const FB_PATTERNS = [
  /https?:\/\/(?:www\.|m\.|web\.)?facebook\.com\//i,
  /https?:\/\/(?:www\.|m\.)?fb\.com\//i,
  /https?:\/\/fb\.watch\//i,
];

module.exports = {
  name       : 'fbcomments',
  aliases    : ['fbcom', 'fbcmt', 'facebookcomments'],
  category   : 'media',
  description: 'Fetch top comments from a public Facebook post or video',
  usage      : '.fbcom <Facebook post/video URL>',

  async execute(sock, msg, args, extra) {
    const chatId = (extra && extra.from) || msg.key.remoteJid;

    const reply = async (text) => {
      if (extra && typeof extra.reply === 'function') return extra.reply(text);
      return sock.sendMessage(chatId, { text }, { quoted: msg });
    };

    try {
      const url = (args || []).join(' ').trim();

      if (!url) {
        return reply(
          `💬 *Facebook Comments Fetcher*\n\n` +
          `*Usage:* .fbcom <Facebook post/video URL>\n\n` +
          `*Example:*\n` +
          `• .fbcom https://www.facebook.com/watch?v=123456\n` +
          `• .fbcom https://www.facebook.com/username/posts/123456\n\n` +
          `_Only works on PUBLIC posts & videos._`
        );
      }

      if (!FB_PATTERNS.some((p) => p.test(url))) {
        return reply(`❌ That doesn't look like a Facebook URL.\n\nMust start with facebook.com, fb.com, or fb.watch`);
      }

      try { await sock.sendMessage(chatId, { react: { text: '🔍', key: msg.key } }); } catch {}

      await reply(`⏳ *Fetching comments...*\n_Scraping public post — please wait_`);

      // ── Fetch comments with a 2-attempt retry ────────────────────────────────
      let result;
      for (let attempt = 1; attempt <= 2; attempt++) {
        try {
          result = await APIs.getFacebookComments(url);
          break;
        } catch (e) {
          if (attempt === 2) throw e;
          await new Promise(r => setTimeout(r, 1500));
        }
      }

      // ── Handle private / redirect-to-login ───────────────────────────────────
      if (result.private) {
        try { await sock.sendMessage(chatId, { react: { text: '🔒', key: msg.key } }); } catch {}
        return reply(
          `🔒 *Post is Private or Unavailable*\n\n` +
          `This post requires a Facebook login to view.\n\n` +
          `_Only public posts & videos are supported._`
        );
      }

      // ── No comments found ────────────────────────────────────────────────────
      if (!result.comments || result.comments.length === 0) {
        try { await sock.sendMessage(chatId, { react: { text: '📭', key: msg.key } }); } catch {}
        return reply(
          `📭 *No Comments Found*\n\n` +
          `${result.postTitle ? `*Post:* ${result.postTitle}\n\n` : ''}` +
          `The post may have comments disabled, be region-restricted, or Facebook is blocking the scrape.\n\n` +
          `_Tip: Try the direct post URL instead of a share link._`
        );
      }

      // ── Format output ─────────────────────────────────────────────────────────
      const titleLine = result.postTitle ? `📌 *${result.postTitle.slice(0, 80)}*\n\n` : '';
      const count = result.comments.length;
      let out = `💬 *Facebook Comments* (${count} found)\n${titleLine}`;
      out += `━━━━━━━━━━━━━━━━━━━━\n\n`;

      result.comments.forEach((c, i) => {
        out += `*${i + 1}. ${c.author}*\n`;
        out += `${c.text}\n`;
        if (c.likes !== null) out += `👍 ${c.likes} likes\n`;
        out += `\n`;
      });

      out += `━━━━━━━━━━━━━━━━━━━━\n`;
      out += `> _Fetched by ${config.botName || 'Bot'}_`;

      try { await sock.sendMessage(chatId, { react: { text: '✅', key: msg.key } }); } catch {}
      return sock.sendMessage(chatId, { text: out }, { quoted: msg });

    } catch (err) {
      console.error('[FBCOM] error:', err?.message || err);
      try { await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } }); } catch {}
      return reply(
        `❌ *Failed to fetch comments*\n\n` +
        `${err?.message || 'Unknown error'}\n\n` +
        `_Possible reasons: post is private, URL is invalid, or Facebook blocked the request._`
      );
    }
  },
};
