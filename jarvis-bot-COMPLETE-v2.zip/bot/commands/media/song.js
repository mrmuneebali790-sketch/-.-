/**
 * Song Downloader — v3 (5-tier fallback system)
 *
 * FALLBACK CHAIN:
 *   Tier 1 — YouTube yt-dlp (android_vr client — default)
 *   Tier 2 — YouTube yt-dlp (android client)
 *   Tier 3 — YouTube yt-dlp (tv_embedded client — bypasses bot check on many videos)
 *   Tier 4 — SoundCloud search via yt-dlp  (scsearch1:<title>)
 *   Tier 5 — SoundCloud broader search    (scsearch1:<simplified title>)
 *
 * WHY 5 TIERS:
 *   YouTube blocks audio-only streams (bestaudio) for popular/viral songs
 *   with "Sign in to confirm you're not a bot" even with all clients.
 *   SoundCloud has millions of tracks and yt-dlp SoundCloud extractor
 *   is NOT blocked from Replit — confirmed working.
 *
 * SIZE RULES:
 *   ≤ 200 MB → send as audio message
 *   > 200 MB → reject (WhatsApp audio limit)
 */

'use strict';

const yts    = require('yt-search');
const fs     = require('fs');
const https  = require('https');
const config = require('../../config');
const ytdlp  = require('../../utils/ytdlp');
const { deleteTempFile } = require('../../utils/mediaDownloader');

const AUDIO_MAX_MB = 200;

// ── Edit status message ────────────────────────────────────────────────────────
async function editStatus(sock, chatId, key, text) {
  if (!key) return;
  try { await sock.sendMessage(chatId, { text, edit: key }); } catch (_) {}
}

// ── Build SoundCloud search URL from a song title ────────────────────────────
function scSearch(title, simplified = false) {
  if (simplified) {
    // Strip featured artists, remix tags, year — keep core title + main artist
    const clean = title
      .replace(/\(.*?\)/g, '')
      .replace(/\[.*?\]/g, '')
      .replace(/feat\.?.*/i, '')
      .replace(/ft\.?.*/i, '')
      .trim()
      .split(' ').slice(0, 5).join(' ');
    return `scsearch1:${clean}`;
  }
  return `scsearch1:${title}`;
}

// YouTube's oEmbed endpoint still returns the title when yt-dlp is blocked by
// an IP challenge. That title enables the SoundCloud fallback for direct URLs.
function youtubeOembedTitle(url) {
  return new Promise(resolve => {
    let parsed;
    try { parsed = new URL(url); } catch (_) { return resolve(''); }
    const req = https.get({
      hostname: 'www.youtube.com',
      path: `/oembed?url=${encodeURIComponent(parsed.toString())}&format=json`,
      timeout: 12_000,
      headers: { 'User-Agent': 'Mozilla/5.0' },
    }, res => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => {
        try { resolve(JSON.parse(body).title || ''); } catch (_) { resolve(''); }
      });
    });
    req.on('error', () => resolve(''));
    req.on('timeout', () => { req.destroy(); resolve(''); });
  });
}

// ── Download + send audio ─────────────────────────────────────────────────────
async function sendAudio(sock, chatId, outFile, title, quotedMsg) {
  const botName  = config.botName || 'Bot';
  const sizeMB   = fs.existsSync(outFile)
    ? +(fs.statSync(outFile).size / 1024 / 1024).toFixed(1)
    : 0;

  if (sizeMB === 0) throw new Error('Download produced empty file');
  if (sizeMB > AUDIO_MAX_MB) throw new Error(`File too large (${sizeMB.toFixed(0)} MB)`);

  const ext      = outFile.split('.').pop().toLowerCase();
  const mimeMap  = { mp3: 'audio/mpeg', m4a: 'audio/mp4', webm: 'audio/webm', ogg: 'audio/ogg', opus: 'audio/ogg; codecs=opus', aac: 'audio/aac' };
  const mimetype = mimeMap[ext] || 'audio/mpeg';
  const safeTitle = title.replace(/[^\w\s\-]/g, '').trim().slice(0, 60) || 'song';
  const fileName  = `${safeTitle}.${ext}`;

  const buf = fs.readFileSync(outFile);
  await sock.sendMessage(chatId, {
    audio   : buf,
    mimetype,
    fileName,
    ptt     : false,
  }, { quoted: quotedMsg });

  await sock.sendMessage(chatId, { react: { text: '✅', key: quotedMsg.key } }).catch(() => {});
  console.log(`[SONG] ✅ Sent: ${title} (${sizeMB} MB, ${ext})`);
}

// ── Tier definitions ──────────────────────────────────────────────────────────
function getTiers(ytUrl, searchTitle) {
  return [
    // ── YouTube tiers ────────────────────────────────────────────────────────
    {
      name         : 'YouTube (android_vr)',
      url          : ytUrl,
      format       : 'bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio/best',
      extractorArgs: null,
    },
    {
      name         : 'YouTube (android)',
      url          : ytUrl,
      format       : 'bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio/best',
      extractorArgs: 'youtube:player_client=android',
    },
    {
      name         : 'YouTube (tv_embedded)',
      url          : ytUrl,
      format       : 'bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio/best',
      extractorArgs: 'youtube:player_client=tv_embedded',
    },
    {
      name         : 'YouTube (web_safari)',
      url          : ytUrl,
      format       : 'bestaudio[ext=m4a]/bestaudio[ext=webm]/bestaudio/best',
      extractorArgs: 'youtube:player_client=web_safari',
    },
    // ── SoundCloud tiers (only when we have a title to search) ────────────────
    ...(searchTitle ? [
      {
        name         : 'SoundCloud (exact search)',
        url          : scSearch(searchTitle),
        format       : 'bestaudio/best',
        extractorArgs: null,
      },
      {
        name         : 'SoundCloud (simplified search)',
        url          : scSearch(searchTitle, true),
        format       : 'bestaudio/best',
        extractorArgs: null,
      },
    ] : []),
  ];
}

// ── Core cascading downloader ─────────────────────────────────────────────────
async function downloadAudioWithFallback(sock, chatId, ytUrl, searchTitle, statusKey, quotedMsg) {
  const tiers  = getTiers(ytUrl, searchTitle);
  let   lastErr = null;

  for (let i = 0; i < tiers.length; i++) {
    const tier = tiers[i];
    const label = `Tier ${i + 1}/${tiers.length}: ${tier.name}`;
    const tmpOut = ytdlp.tmpPath('song', '.m4a');

    console.log(`[SONG] Trying ${label}`);

    try {
      const result = await ytdlp.download(tier.url, tmpOut, {
        format       : tier.format,
        extractorArgs: tier.extractorArgs,
        audioOnly    : true,
        timeout      : 180_000,
      });

      const outFile    = result.outputPath;
      const finalTitle = result.title || searchTitle || 'Audio';
      console.log(`[SONG] ${label} → ${result.sizeMB} MB`);

      try {
        await editStatus(sock, chatId, statusKey, '📤 *Uploading audio...*');
        await sendAudio(sock, chatId, outFile, finalTitle, quotedMsg);
        return; // ✅ success
      } finally {
        deleteTempFile(outFile);
        // clean up temp base variations
        const base = tmpOut.replace(/\.\w+$/, '');
        for (const ext of ['mp3', 'm4a', 'webm', 'opus', 'ogg', 'aac', 'part', 'ytdl']) {
          deleteTempFile(`${base}.${ext}`);
        }
      }

    } catch (err) {
      lastErr = err;
      console.warn(`[SONG] ${label} failed: ${err.message}`);

      // Show intermediate status (not on last tier)
      if (i < tiers.length - 1) {
        const next = tiers[i + 1];
        const isYt  = next.url === ytUrl;
        await editStatus(sock, chatId, statusKey,
          `🔄 *Method ${i + 1} failed — trying ${isYt ? 'backup YouTube method' : 'SoundCloud'} (${i + 2}/${tiers.length})...*\n` +
          `_${err.message.slice(0, 100)}_`
        );
        await new Promise(r => setTimeout(r, 1500));
      }

      // Clean up any partial temp files
      const base = tmpOut.replace(/\.\w+$/, '');
      for (const ext of ['mp3', 'm4a', 'webm', 'opus', 'ogg', 'aac', 'part', 'ytdl']) {
        deleteTempFile(`${base}.${ext}`);
      }
    }
  }

  // All tiers exhausted
  throw new Error(
    `All ${tiers.length} download methods failed.\n` +
    `Last error: ${lastErr?.message?.slice(0, 200) || 'unknown'}\n\n` +
    `_Try a different song title or run .update to refresh the bot._`
  );
}

// ── Command ───────────────────────────────────────────────────────────────────
module.exports = {
  name    : 'song',
  aliases : ['play', 'music', 'yta', 'mp3'],
  category: 'media',
  description: 'Download audio from YouTube (5-tier fallback: YouTube → SoundCloud)',
  usage   : '.song <song name or YouTube link>',

  async execute(sock, msg, args) {
    const chatId = msg.key.remoteJid;
    try {
      const text = args.join(' ').trim();
      if (!text) {
        return await sock.sendMessage(chatId, {
          text: [
            '🎵 *Song Downloader*',
            '',
            'Usage: *.song <song name or YouTube URL>*',
            '',
            'Examples:',
            '• .song Pasoori Ali Sethi',
            '• .song Tere Bin Waris Baig',
            '• .song Shape of You Ed Sheeran',
            '• .song https://youtu.be/abc123',
            '',
            '_Searches YouTube first, falls back to SoundCloud automatically_',
          ].join('\n'),
        }, { quoted: msg });
      }

      await sock.sendMessage(chatId, { react: { text: '⏳', key: msg.key } });

      const isUrl = text.includes('youtube.com') || text.includes('youtu.be');

      if (!isUrl) {
        // ── Search flow ───────────────────────────────────────────────────────
        const statusMsg = await sock.sendMessage(chatId, {
          text: `🔍 *Searching:* _${text}_`,
        }, { quoted: msg });

        setImmediate(async () => {
          try {
            const search = await yts(text);
            const video  = search?.videos?.[0];
            if (!video) {
              return await editStatus(sock, chatId, statusMsg.key,
                `❌ *No results found for:* _${text}_\n\nTry a more specific search.`
              );
            }

            try {
              await sock.sendMessage(chatId, {
                image  : { url: video.thumbnail },
                caption: `🎵 *${video.title}*\n⬇️ Downloading audio...`,
              }, { quoted: msg });
            } catch (_) {}

            await editStatus(sock, chatId, statusMsg.key,
              `🎵 *Downloading:* _${video.title}_\n_YouTube first, then SoundCloud if needed_`
            );

            await downloadAudioWithFallback(
              sock, chatId, video.url, video.title, statusMsg.key, msg
            );

          } catch (err) {
            console.error('[SONG] search+dl error:', err.message);
            await editStatus(sock, chatId, statusMsg.key,
              `❌ *Download failed*\n\n${err.message}`
            );
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } }).catch(() => {});
          }
        });

      } else {
        // ── Direct URL flow ───────────────────────────────────────────────────
        const statusMsg = await sock.sendMessage(chatId, {
          text: '🎵 *Downloading audio...*\n_YouTube first, then SoundCloud if needed_',
        }, { quoted: msg });

        setImmediate(async () => {
          try {
            const directTitle = await youtubeOembedTitle(text.trim());
            await downloadAudioWithFallback(
              sock, chatId, text.trim(), directTitle, statusMsg.key, msg
            );
          } catch (err) {
            console.error('[SONG] url dl error:', err.message);
            await editStatus(sock, chatId, statusMsg.key,
              `❌ *Download failed*\n\n${err.message}`
            );
            await sock.sendMessage(chatId, { react: { text: '❌', key: msg.key } }).catch(() => {});
          }
        });
      }

    } catch (err) {
      console.error('[SONG] Unexpected error:', err.message);
      await sock.sendMessage(chatId, { text: `❌ Unexpected error: ${err.message}` }, { quoted: msg });
    }
  },
};
