'use strict';

/**
 * .save @user — Doctor night action (DM only, sent to bot privately)
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'save',
  aliases: ['protect'],
  category: 'fun',
  description: 'Doctor: protect a player during the night phase (send via DM)',
  usage: '.save @user  or  .save 1',

  async execute(sock, msg, args, extra) {
    try {
      // Silently ignore if sent in a group (security: don't reveal role)
      if (extra.isGroup) return;

      const { sender, reply } = extra;
      const res = await mafia.nightSave(sock, sender, args, msg);
      if (!res.ok) return reply(`❌ ${res.error}`);

    } catch (e) {
      console.error('[save cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
