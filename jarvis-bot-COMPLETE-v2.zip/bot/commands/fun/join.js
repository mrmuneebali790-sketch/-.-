'use strict';

/**
 * .join — Join a running Mafia game (group only)
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'join',
  aliases: ['joingame'],
  category: 'fun',
  description: 'Join the active Mafia game in this group',
  usage: '.join',
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const { from, sender, reply } = extra;
      const game = mafia.getGame(from);

      if (!game) return reply(`❌ No Mafia game is running here.\nStart one with *.mafia start*`);

      const res = await mafia.joinGame(sock, from, sender);
      if (!res.ok) return reply(`❌ ${res.error}`);

    } catch (e) {
      console.error('[join cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
