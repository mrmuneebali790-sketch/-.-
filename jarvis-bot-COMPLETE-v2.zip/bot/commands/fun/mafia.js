'use strict';

/**
 * .mafia start — Start a Mafia game (group only)
 * .mafia stop  — Force-stop a running game (admins only)
 * Developed by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'mafia',
  aliases: ['mafiya'],
  category: 'fun',
  description: 'Start or stop a Mafia game in this group',
  usage: '.mafia start | .mafia stop',
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const { from, sender, reply } = extra;
      const sub = (args[0] || '').toLowerCase().trim();

      // ── .mafia (no args) → show usage ────────────────────────────────────
      if (!sub) {
        const game = mafia.getGame(from);
        if (game) {
          return reply(
            `🎮 *Mafia Game — ${game.phase}*\n\n` +
            `Round: ${game.round} | Players: ${game.players.size}\n\n` +
            `Use *.mafia stop* to force-stop (admins only).`
          );
        }
        return reply(
          `🎮 *Mafia Game — Fast Mode*\n\n` +
          `Commands:\n` +
          `• *.mafia start* — start a game\n` +
          `• *.join* — join the game\n` +
          `• *.leave* — leave before game starts\n` +
          `• *.vote @user* — vote to eliminate\n` +
          `• *.mafia stop* — force stop (admin)\n\n` +
          `👥 Need 5–8 players | ⏱️ ~10 minutes\n` +
          `> *Developed by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡*`
        );
      }

      // ── .mafia start ──────────────────────────────────────────────────────
      if (sub === 'start') {
        const res = await mafia.startGame(sock, from, sender);
        if (!res.ok) return reply(`❌ ${res.error}`);
        return;
      }

      // ── .mafia stop ───────────────────────────────────────────────────────
      if (sub === 'stop') {
        // Only admins or bot owner can stop
        if (!extra.isAdmin && !extra.isOwner) {
          return reply(`❌ Only group admins can force-stop the game.`);
        }
        const res = await mafia.forceStop(sock, from);
        if (!res.ok) return reply(`❌ ${res.error}`);
        return;
      }

      return reply(`❓ Unknown option. Use *.mafia start* or *.mafia stop*`);

    } catch (e) {
      console.error('[mafia cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
