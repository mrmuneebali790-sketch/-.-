/**
 * Wasted Command
 * Overlay a GTA-style "WASTED" effect on a mentioned/replied user's profile photo
 */

const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

module.exports = {
  name: 'wasted',
  aliases: [],
  category: 'fun',
  description: "Apply a GTA-style WASTED overlay to a user's profile photo",
  usage: '.wasted @user',

  async execute(sock, msg, args, extra) {
    try {
      const ctx = msg.message?.extendedTextMessage?.contextInfo;
      let userToWaste = ctx?.mentionedJid?.[0] || ctx?.participant || null;

      if (!userToWaste) {
        return extra.reply('Please mention someone or reply to their message to waste them!');
      }

      let profilePic;
      try {
        profilePic = await sock.profilePictureUrl(userToWaste, 'image');
      } catch (_) {
        profilePic = 'https://i.imgur.com/2wzGhpF.jpeg';
      }

      const res = await axios.get(
        `https://some-random-api.com/canvas/overlay/wasted?avatar=${encodeURIComponent(profilePic)}`,
        { responseType: 'arraybuffer', timeout: 15000 }
      );

      await sock.sendMessage(extra.from, {
        image: Buffer.from(res.data),
        caption: `⚰️ *Wasted:* ${userToWaste.split('@')[0]} 💀\n\nRest in pieces!`,
        mentions: [userToWaste],
        ...channelInfo,
      }, { quoted: msg });

    } catch (error) {
      console.error('[wasted cmd]', error.message);
      await extra.reply('❌ Failed to create wasted image. Please try again later.');
    }
  },
};
