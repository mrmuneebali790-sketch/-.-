'use strict';

/**
 * .check @user — Police night action (DM only, sent to bot privately)
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'check',
  aliases: ['investigate'],
  category: 'fun',
  description: 'Police: investigate a player during the night phase (send via DM)',
  usage: '.check @user  or  .check 1',

  async execute(sock, msg, args, extra) {
    try {
      // Silently ignore if sent in a group (security: don't reveal role)
      if (extra.isGroup) return;

      const { sender, reply } = extra;
      const res = await mafia.nightCheck(sock, sender, args, msg);
      if (!res.ok) return reply(`❌ ${res.error}`);

    } catch (e) {
      console.error('[check cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
