'use strict';

/**
 * .leave — Leave a Mafia game during the join phase (group only)
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'leave',
  aliases: ['leavegame'],
  category: 'fun',
  description: 'Leave the Mafia game (only before it starts)',
  usage: '.leave',
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const { from, sender, reply } = extra;
      const game = mafia.getGame(from);

      if (!game) return reply(`❌ No Mafia game is running here.`);

      const res = await mafia.leaveGame(sock, from, sender);
      if (!res.ok) return reply(`❌ ${res.error}`);

    } catch (e) {
      console.error('[leave cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
