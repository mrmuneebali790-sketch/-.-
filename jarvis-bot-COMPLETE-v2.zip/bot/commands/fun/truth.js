'use strict';

/**
 * Truth - Random truth question (local list)
 * NOTE: @bochilteam/scraper does NOT export a `truth` function
 * (it exports tsunami, gempa, facebookdl, etc.) — using local list instead.
 */

const TRUTHS = [
  "What's the most embarrassing thing you've ever done?",
  "Have you ever lied to get out of trouble? What was the lie?",
  "What is the biggest mistake you've ever made?",
  "Have you ever cheated on a test or exam?",
  "What is one thing you've done that you hope your parents never find out about?",
  "Have you ever blamed someone else for something you did?",
  "What is the most childish thing you still do?",
  "Have you ever said 'I love you' but didn't mean it?",
  "What is the most embarrassing thing in your phone right now?",
  "Have you ever cried at a movie or TV show? Which one?",
  "What is the worst gift you've ever received?",
  "Who do you have a crush on?",
  "What's the most embarrassing thing you've done on social media?",
  "Have you ever ghosted someone? Why?",
  "What is the most money you've ever spent on something you regret?",
  "Have you ever pretended to be sick to avoid going somewhere?",
  "What is your biggest fear?",
  "What is the most embarrassing nickname you've ever had?",
  "Have you ever snooped through someone else's phone or belongings?",
  "What is the worst thing you've ever said to someone?",
  "Have you ever stolen anything?",
  "What is the most embarrassing photo of you?",
  "Have you ever spread a rumor? What was it?",
  "What is the most embarrassing thing you've said to your crush?",
  "Have you ever pretended to like a gift you hated?",
  "What is your biggest regret in life?",
  "Have you ever lied about your age?",
  "What is the weirdest dream you've ever had?",
  "Have you ever done something illegal? What was it?",
  "What is the most embarrassing thing that happened to you in public?",
  "Have you ever stood someone up? Why?",
  "What is something you've never told your best friend?",
  "Have you ever fallen asleep in class or at work?",
  "What is the last thing you searched on Google?",
  "Have you ever eaten food off the floor?",
  "What is the worst date you've ever been on?",
  "Have you ever walked into a glass door?",
  "What is the most embarrassing song on your playlist?",
  "Have you ever laughed at a really inappropriate time?",
  "What is the rudest thing you've ever done to a stranger?",
];

module.exports = {
  name    : 'truth',
  aliases : [],
  category: 'fun',
  desc    : 'Get a random truth question',
  usage   : '.truth',

  async execute(sock, msg, args, extra) {
    try {
      const question = TRUTHS[Math.floor(Math.random() * TRUTHS.length)];
      await sock.sendMessage(msg.key.remoteJid, {
        text: `🎯 *TRUTH*\n\n${question}`
      }, { quoted: msg });
    } catch (err) {
      console.error('[truth cmd]', err.message);
      if (extra && typeof extra.reply === 'function') {
        await extra.reply('❌ Error getting truth question. Please try again.');
      }
    }
  },
};
