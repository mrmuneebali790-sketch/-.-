/**
 * Kiss Command - Anime kiss reaction GIF with mention support
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');
const os = require('os');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegPath = require('ffmpeg-static');
ffmpeg.setFfmpegPath(ffmpegPath);

// Multiple independent sources tried in order — if one domain isn't
// reachable from this host's network, the next one is used automatically.
const SOURCES = [
  {
    name: 'nekos.best',
    url: 'https://nekos.best/api/v2/kiss',
    extract: (data) => data?.results?.[0]?.url
  },
  {
    name: 'otakugifs',
    url: 'https://api.otakugifs.xyz/gif?reaction=kiss',
    extract: (data) => data?.url
  },
  {
    name: 'waifu.pics',
    url: 'https://api.waifu.pics/sfw/kiss',
    extract: (data) => data?.url
  }
];

async function fetchKissGif() {
  let lastErr;
  for (const src of SOURCES) {
    try {
      const response = await axios.get(src.url, {
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' },
        timeout: 15000
      });
      const gifUrl = src.extract(response.data);
      if (gifUrl && typeof gifUrl === 'string') return gifUrl;
      throw new Error(`Invalid response from ${src.name}`);
    } catch (e) {
      lastErr = e;
      console.log(`[kiss] Source ${src.name} failed: ${e.message}`);
    }
  }
  throw new Error(`All sources failed. Last: ${lastErr?.message}`);
}

// ── Convert a GIF Buffer → MP4 Buffer via FFmpeg temp files (WhatsApp needs real video) ──
function gifToMp4(gifBuffer) {
  return new Promise((resolve, reject) => {
    const id     = `kiss_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const tmpGif = path.join(os.tmpdir(), `${id}.gif`);
    const tmpMp4 = path.join(os.tmpdir(), `${id}.mp4`);

    const cleanup = () => {
      try { if (fs.existsSync(tmpGif)) fs.unlinkSync(tmpGif); } catch (_) {}
      try { if (fs.existsSync(tmpMp4)) fs.unlinkSync(tmpMp4); } catch (_) {}
    };

    try {
      fs.writeFileSync(tmpGif, gifBuffer);
    } catch (e) {
      return reject(new Error(`Failed to write temp GIF: ${e.message}`));
    }

    ffmpeg(tmpGif)
      .videoCodec('libx264')
      .outputOptions([
        '-movflags', 'faststart',
        '-pix_fmt', 'yuv420p',
        '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2'
      ])
      .format('mp4')
      .on('error', (e) => { cleanup(); reject(new Error(`FFmpeg error: ${e.message}`)); })
      .on('end', () => {
        try {
          const buf = fs.readFileSync(tmpMp4);
          cleanup();
          if (!buf || buf.length === 0) throw new Error('Converted MP4 is empty');
          resolve(buf);
        } catch (e) {
          cleanup();
          reject(e);
        }
      })
      .save(tmpMp4);
  });
}

const CAPTIONS = [
  '{a} kisses {b} 💋',
  '{a} plants a sweet kiss on {b} 😘',
  '{a} steals a kiss from {b} 💞'
];

module.exports = {
  name: 'kiss',
  aliases: ['smooch'],
  category: 'fun',
  description: 'Kiss a mentioned/replied user, or a random group member.',
  usage: '.kiss @user OR reply with .kiss',
  groupOnly: false,

  async execute(sock, msg, args, extra) {
    try {
      const ctx = msg.message?.extendedTextMessage?.contextInfo || {};
      const mentioned = ctx.mentionedJid || [];

      let a = extra.sender;
      let b = null;

      if (mentioned.length >= 1) {
        b = mentioned[0];
      } else if (ctx.participant) {
        b = ctx.participant;
      } else if (extra.isGroup && extra.groupMetadata?.participants) {
        const participants = extra.groupMetadata.participants
          .map(p => p.id)
          .filter(id => id !== extra.sender && id !== sock.user.id);
        if (participants.length > 0) {
          b = participants[Math.floor(Math.random() * participants.length)];
        }
      }

      if (!b) {
        return extra.reply('❌ Mention someone, reply to their message, or use this in a group with other members.');
      }

      if (b === extra.sender) {
        return extra.reply('❌ You cannot kiss yourself 😅');
      }

      // Fetch a random kiss GIF URL (tries multiple sources)
      const gifUrl = await fetchKissGif();

      // Download the GIF
      const gifResponse = await axios.get(gifUrl, {
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'image/*' },
        timeout: 30000
      });

      const gifBuffer = Buffer.from(gifResponse.data);
      if (!gifBuffer || gifBuffer.length === 0) {
        throw new Error('Empty GIF response');
      }

      // Convert to MP4 — WhatsApp needs a real video container for gifPlayback,
      // sending raw GIF bytes as "video" results in broken/unplayable media.
      const mp4Buffer = await gifToMp4(gifBuffer);

      const nameOf = id => `@${id.split('@')[0]}`;
      const template = CAPTIONS[Math.floor(Math.random() * CAPTIONS.length)];
      const caption = template.replace('{a}', nameOf(a)).replace('{b}', nameOf(b));

      await sock.sendMessage(extra.from, {
        video: mp4Buffer,
        gifPlayback: true,
        caption,
        mentions: [a, b]
      }, { quoted: msg });

    } catch (error) {
      console.error('[kiss] ERROR:', error);

      if (error.response?.status === 404) {
        await extra.reply('❌ GIF not found. Please try again.');
      } else if (error.response?.status === 429) {
        await extra.reply('❌ Rate limit exceeded. Please try again later.');
      } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
        await extra.reply('❌ Request timed out. Please try again.');
      } else {
        await extra.reply(`❌ Failed to send kiss: ${error.message}`);
      }
    }
  }
};
