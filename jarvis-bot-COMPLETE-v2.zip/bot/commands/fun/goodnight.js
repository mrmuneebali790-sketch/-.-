/**
 * Goodnight Command
 * Sends a random goodnight message
 */

const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

// Local fallback list — used if the external API is unavailable, so the
// command always works instead of depending entirely on a third-party service.
const FALLBACK_MESSAGES = [
  'Good night! May your dreams be as sweet as you are. 🌙',
  'The stars are shining just for you tonight. Sleep well! ✨',
  'Rest well, tomorrow is a brand new day full of possibilities. 🌌',
  'Close your eyes, relax, and let the night carry your worries away. 😴',
  'Wishing you a peaceful night and a bright morning ahead. 🌠',
];

module.exports = {
  name: 'goodnight',
  aliases: ['gn'],
  category: 'fun',
  description: 'Get a random goodnight message',
  usage: '.goodnight',

  async execute(sock, msg, args, extra) {
    try {
      let text;
      try {
        const res = await axios.get('https://shizoapi.onrender.com/api/texts/lovenight?apikey=shizo', { timeout: 5000 });
        text = res.data?.result;
      } catch (_) {
        // API unavailable — fall through to local list below
      }

      if (!text) {
        text = FALLBACK_MESSAGES[Math.floor(Math.random() * FALLBACK_MESSAGES.length)];
      }

      await sock.sendMessage(extra.from, { text, ...channelInfo }, { quoted: msg });

    } catch (error) {
      await extra.reply('❌ Failed to get a goodnight message. Please try again later.');
    }
  },
};
