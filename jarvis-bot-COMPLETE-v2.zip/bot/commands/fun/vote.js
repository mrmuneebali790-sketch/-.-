'use strict';

/**
 * .vote @user — Vote to eliminate someone during voting phase (group only)
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'vote',
  aliases: ['mvote'],
  category: 'fun',
  description: 'Vote to eliminate a player during Mafia voting phase',
  usage: '.vote @user  or  .vote 1',
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      const { from, sender, reply } = extra;
      const game = mafia.getGame(from);

      if (!game) return reply(`❌ No Mafia game running here.`);
      if (game.phase !== 'VOTING') return reply(`❌ It's not voting time right now! (Phase: ${game.phase})`);

      const res = await mafia.castVote(sock, from, sender, args, msg);
      if (!res.ok) return reply(`❌ ${res.error}`);

    } catch (e) {
      console.error('[vote cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
