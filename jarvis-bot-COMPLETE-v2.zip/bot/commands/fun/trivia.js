/**
 * Trivia Command
 * .trivia            → start a new question (or show the active one)
 * .trivia <answer>   → submit an answer to the active question
 */

const axios = require('axios');

const games = {}; // chatId -> { question, correctAnswer, options, startedAt }

const ENTITY_MAP = {
  '&quot;': '"', '&#039;': "'", '&amp;': '&', '&lt;': '<', '&gt;': '>',
  '&rsquo;': '’', '&lsquo;': '‘', '&rdquo;': '”', '&ldquo;': '“',
  '&eacute;': 'é', '&uuml;': 'ü', '&ouml;': 'ö', '&auml;': 'ä', '&ndash;': '–',
};
function decodeEntities(str) {
  return String(str || '').replace(/&[a-z#0-9]+;/gi, (m) => ENTITY_MAP[m] || m);
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

module.exports = {
  name: 'trivia',
  aliases: ['quiz'],
  category: 'fun',
  description: 'Play a trivia question — .trivia to start, .trivia <answer> to answer',
  usage: '.trivia [answer]',
  groupOnly: false,
  games,

  async execute(sock, msg, args, extra) {
    try {
      const chatId = extra.from;
      const answerText = args.join(' ').trim();
      const active = games[chatId];

      // ── Submitting an answer ────────────────────────────────────────────
      if (answerText) {
        if (!active) {
          return extra.reply('❌ No trivia game is in progress. Start one with .trivia');
        }
        const isCorrect = answerText.toLowerCase() === active.correctAnswer.toLowerCase();
        delete games[chatId];
        return extra.reply(
          isCorrect
            ? `✅ Correct! The answer was: *${active.correctAnswer}*`
            : `❌ Wrong! The correct answer was: *${active.correctAnswer}*`
        );
      }

      // ── Already an active question — show it again ──────────────────────
      if (active) {
        return extra.reply(
          `🧠 *Trivia Time!*\n\n${active.question}\n\nOptions:\n${active.options.join('\n')}\n\nReply with: .trivia <your answer>`
        );
      }

      // ── Start a new question ─────────────────────────────────────────────
      const res = await axios.get('https://opentdb.com/api.php?amount=1&type=multiple', { timeout: 10000 });
      const q = res.data?.results?.[0];

      if (!q) {
        return extra.reply('❌ Could not fetch a trivia question. Please try again later.');
      }

      const question = decodeEntities(q.question);
      const correctAnswer = decodeEntities(q.correct_answer);
      const options = shuffle([...q.incorrect_answers.map(decodeEntities), correctAnswer]);

      games[chatId] = { question, correctAnswer, options, startedAt: Date.now() };

      await extra.reply(
        `🧠 *Trivia Time!*\n\n${question}\n\nOptions:\n${options.join('\n')}\n\nReply with: .trivia <your answer>`
      );

    } catch (error) {
      console.error('[trivia cmd]', error.message);
      await extra.reply('❌ Error fetching trivia question. Please try again later.');
    }
  },
};
