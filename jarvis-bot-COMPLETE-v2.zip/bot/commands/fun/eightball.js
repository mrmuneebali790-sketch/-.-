/**
 * 8Ball Command
 * Ask the magic 8-ball a yes/no question
 */

const { channelInfo } = require('../lib/messageConfig');

const RESPONSES = [
  'Yes, definitely!',
  'No way!',
  'Ask again later.',
  'It is certain.',
  'Very doubtful.',
  'Without a doubt.',
  'My reply is no.',
  'Signs point to yes.',
  'Cannot predict now.',
  'Most likely.',
  'Outlook not so good.',
  'You may rely on it.',
];

module.exports = {
  name: 'eightball',
  aliases: ['8ball', '8b'],
  category: 'fun',
  description: 'Ask the magic 8-ball a yes/no question',
  usage: '.8ball <question>',

  async execute(sock, msg, args, extra) {
    try {
      const question = args.join(' ').trim();

      if (!question) {
        return extra.reply('🎱 Please ask a question!\n\nExample: .8ball Will I win the lottery?');
      }

      const answer = RESPONSES[Math.floor(Math.random() * RESPONSES.length)];

      await sock.sendMessage(extra.from, {
        text: `🎱 *${answer}*`,
        ...channelInfo,
      }, { quoted: msg });

    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  },
};
