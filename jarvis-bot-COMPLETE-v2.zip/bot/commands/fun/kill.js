'use strict';

/**
 * .kill @user — Mafia night action (DM only, sent to bot privately)
 */

const mafia = require('../../utils/mafiaGame');

module.exports = {
  name: 'kill',
  aliases: ['eliminate'],
  category: 'fun',
  description: 'Mafia: eliminate a player during the night phase (send via DM)',
  usage: '.kill @user  or  .kill 1',

  async execute(sock, msg, args, extra) {
    try {
      // Silently ignore if sent in a group (security: don't reveal role)
      if (extra.isGroup) return;

      const { sender, reply } = extra;
      const res = await mafia.nightKill(sock, sender, args, msg);
      if (!res.ok) return reply(`❌ ${res.error}`);

    } catch (e) {
      console.error('[kill cmd]', e);
      extra.reply(`❌ Error: ${e.message}`);
    }
  },
};
