/**
 * Kick Command
 * Remove mentioned or replied users from the group
 * Includes robust self-kick prevention for PN/LID IDs
 */

const config = require('../../config');
const axios = require('axios');

module.exports = {
  name: 'kick',
  aliases: ['remove'],
  category: 'admin',
  description: 'Kick mentioned/replied members from the group',
  usage: '.kick @user',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,
  
  async execute(sock, msg, args, extra) {
    try {
      const chatId = extra.from;
      const ctx = msg.message?.extendedTextMessage?.contextInfo;
      const mentioned = ctx?.mentionedJid || [];
      let usersToKick = [];
      
      if (mentioned && mentioned.length > 0) {
        usersToKick = mentioned;
      } else if (ctx?.participant && ctx.stanzaId && ctx.quotedMessage) {
        usersToKick = [ctx.participant];
      }
      
      if (usersToKick.length === 0) {
        return extra.reply('👤 Mention or reply to the user you want to kick.');
      }

      // ============================================================
      // 👑 OWNER PROTECTION — Same deep logic used for the bot itself
      // ============================================================
      const OWNER_NUMBER = '923196615238';

      const metadata = await sock.groupMetadata(chatId);
      const participants = metadata.participants || [];

      // Collect every possible JID format for the owner from group participants
      const ownerParticipant = participants.find((p) => {
        const pId = (p.id || '').replace('@s.whatsapp.net', '').replace('@lid', '').replace('@c.us', '').split(':')[0];
        const pPhoneNumber = (p.phoneNumber || '').replace('@s.whatsapp.net', '').split(':')[0];
        return pId === OWNER_NUMBER || pPhoneNumber === OWNER_NUMBER || (p.id || '').includes(OWNER_NUMBER);
      });

      const isTryingToKickOwner = usersToKick.some((userId) => {
        const userNum = userId.replace('@s.whatsapp.net', '').replace('@lid', '').replace('@c.us', '').split(':')[0];
        const userLidNumeric = userId.includes('@lid') ? userId.split('@')[0].split(':')[0] : '';

        // Direct phone number match
        if (userNum === OWNER_NUMBER || userId.includes(OWNER_NUMBER)) return true;

        // Participant-based cross match (LID <-> PN)
        if (ownerParticipant) {
          const pFullId = ownerParticipant.id || '';
          const pFullLid = ownerParticipant.lid || '';
          const pId = pFullId.split('@')[0].split(':')[0];
          const pLid = pFullLid.split('@')[0].split(':')[0];

          if (
            userId === pFullId ||
            userId === pFullLid ||
            userNum === pId ||
            userNum === pLid ||
            (userLidNumeric && pLid && userLidNumeric === pLid)
          ) return true;
        }

        return false;
      });

      if (isTryingToKickOwner) {
        await extra.reply(
          `⚠️ *𝖯𝖾𝗋𝗆𝗂𝗌𝗌𝗂𝗈𝗇 𝖣𝖾𝗇𝗂𝖾𝖽 ⚠️*\n\n` +
          `👑 *𝖧𝖾 𝗂𝗌 𝗆𝗒 𝖮𝗐𝗇𝖾𝗋!* 𝖨 𝖼𝖺𝗇𝗇𝗈𝗍 𝗄𝗂𝖼𝗄 𝗆𝗒 𝗈𝗐𝗇𝖾𝗋. 😎✨\n\n` +
          `*Nice try, but respect the Boss!* 🫡`
        );
        // Remove the owner from the list, kick the rest
        usersToKick = usersToKick.filter((userId) => {
          const userNum = userId.replace('@s.whatsapp.net', '').replace('@lid', '').replace('@c.us', '').split(':')[0];
          const userLidNumeric = userId.includes('@lid') ? userId.split('@')[0].split(':')[0] : '';
          if (userNum === OWNER_NUMBER || userId.includes(OWNER_NUMBER)) return false;
          if (ownerParticipant) {
            const pFullId = ownerParticipant.id || '';
            const pFullLid = ownerParticipant.lid || '';
            const pId = pFullId.split('@')[0].split(':')[0];
            const pLid = pFullLid.split('@')[0].split(':')[0];
            if (
              userId === pFullId ||
              userId === pFullLid ||
              userNum === pId ||
              userNum === pLid ||
              (userLidNumeric && pLid && userLidNumeric === pLid)
            ) return false;
          }
          return true;
        });
        if (usersToKick.length === 0) return;
      }
      // ============================================================

      // ============================================================
      // 🤖 BOT SELF PROTECTION (tera original code)
      // ============================================================
      const botId = sock.user?.id || '';
      const botLid = sock.user?.lid || '';
      const botPhoneNumber = botId.includes(':') ? botId.split(':')[0] : (botId.includes('@') ? botId.split('@')[0] : botId);
      const botIdFormatted = botPhoneNumber + '@s.whatsapp.net';
      const botLidNumeric = botLid.includes(':') ? botLid.split(':')[0] : (botLid.includes('@') ? botLid.split('@')[0] : botLid);
      const botLidWithoutSuffix = botLid.includes('@') ? botLid.split('@')[0] : botLid;
      
      const isTryingToKickBot = usersToKick.some((userId) => {
        const userPhoneNumber = userId.includes(':') ? userId.split(':')[0] : (userId.includes('@') ? userId.split('@')[0] : userId);
        const userLidNumeric = userId.includes('@lid') ? userId.split('@')[0].split(':')[0] : '';
        
        const directMatch = (
          userId === botId ||
          userId === botLid ||
          userId === botIdFormatted ||
          userPhoneNumber === botPhoneNumber ||
          (userLidNumeric && botLidNumeric && userLidNumeric === botLidNumeric)
        );
        
        if (directMatch) return true;
        
        const participantMatch = participants.some((p) => {
          const pPhoneNumber = p.phoneNumber ? p.phoneNumber.split('@')[0] : '';
          const pId = p.id ? p.id.split('@')[0] : '';
          const pLid = p.lid ? p.lid.split('@')[0] : '';
          const pFullId = p.id || '';
          const pFullLid = p.lid || '';
          const pLidNumeric = pLid.includes(':') ? pLid.split(':')[0] : pLid;
          
          const isThisParticipantBot = (
            pFullId === botId ||
            pFullLid === botLid ||
            pLidNumeric === botLidNumeric ||
            pPhoneNumber === botPhoneNumber ||
            pId === botPhoneNumber ||
            p.phoneNumber === botIdFormatted ||
            (botLid && pLid && botLidWithoutSuffix === pLid)
          );
          
          if (!isThisParticipantBot) return false;
          
          return (
            userId === pFullId ||
            userId === pFullLid ||
            userPhoneNumber === pPhoneNumber ||
            userPhoneNumber === pId ||
            userId === p.phoneNumber ||
            (pLid && userLidNumeric && userLidNumeric === pLidNumeric) ||
            (userLidNumeric && pLidNumeric && userLidNumeric === pLidNumeric)
          );
        });
        
        return participantMatch;
      });
      
      if (isTryingToKickBot) {
        await extra.reply('❌ Cannot kick myself!');
        return;
      }
      // ============================================================
      
      await sock.groupParticipantsUpdate(chatId, usersToKick, 'remove');
      
      // 📝 Updated Caption Text
      const text = `this user remove successfully 😎`;

      // 🎬 Kick video URL updated
      const videoUrl = 'https://github.com/mrmuneebali907-byte/Muneeb-Bot-videos-/raw/refs/heads/main/VID-20260611-WA0103.mp4';
      try {
        const response = await axios.get(videoUrl, { responseType: 'arraybuffer' });
        await sock.sendMessage(extra.from, {
          video: Buffer.from(response.data, 'binary'),
          caption: text,
          mentions: usersToKick,
        }, { quoted: msg });
      } catch (e) {
        await sock.sendMessage(extra.from, { text, mentions: usersToKick }, { quoted: msg });
      }

    } catch (error) {
      console.error('Kick command error:', error);
      await extra.reply('❌ Failed to kick user(s). Make sure I am admin.');
    }
  },
};
