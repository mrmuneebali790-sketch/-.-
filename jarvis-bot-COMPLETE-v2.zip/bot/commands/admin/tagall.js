/**
 * Tag All Command - Mention all group members with Video & Emoji
 */

module.exports = {
    name: 'tagall',
    aliases: ['mentionall', 'everyone'],
    category: 'admin',
    description: 'Tag all group members with a video announcement',
    usage: '.tagall <message>',
    groupOnly: true,
    adminOnly: true,
    botAdminNeeded: true,
    
    async execute(sock, msg, args, extra) {
      try {
        const message = args.join(' ') || 'Everyone!';
        
        if (!extra.groupMetadata) return extra.reply('❌ Could not fetch group data. Please try again.');
        const participants = extra.groupMetadata.participants.map(p => p.id);
        
        // Header Format
        let text = `📢 *GROUP ANNOUNCEMENT*\n\n`;
        text += `💬 *Message:* ${message}\n\n`;
        text += `👥 *Tagged Members:*\n`;
        
        // Members list with 😎 Emoji and Tags
        participants.forEach((participant) => {
          text += `😎 @${participant.split('@')[0]}\n`;
        });
        
        // Video link provided
        const videoUrl = 'https://github.com/mrmuneebali907-byte/Muneeb-Bot-videos-/raw/refs/heads/main/VID-20260614-WA0012.mp4';
        
        // Sending Video with Caption and Mentions
        await sock.sendMessage(extra.from, {
          video: { url: videoUrl },
          caption: text,
          mentions: participants
        }, { quoted: msg });
        
      } catch (error) {
        await extra.reply(`❌ Error: ${error.message}`);
      }
    }
  };
  