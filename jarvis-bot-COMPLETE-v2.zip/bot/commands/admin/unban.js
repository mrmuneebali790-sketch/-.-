'use strict';

const { channelInfo }           = require('../lib/messageConfig');
const isAdminLib                 = require('../lib/isAdmin');
const { isSudo }                 = require('../lib/index');
const { unbanUser, isBanned }    = require('../../database');
const { normalizeJidWithLid }    = require('../../utils/jidHelper');
const isOwner                    = require('../lib/isOwner');   // exports fn directly

// Normalize any JID / LID to digits-only phone number
function normalizeNumber(jid) {
  let resolved = jid;
  try { resolved = normalizeJidWithLid(jid) || jid; } catch (_) {}
  return String(resolved || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

async function unbanCommand(sock, chatId, message, extra) {
  const isGroup       = chatId.endsWith('@g.us');
  const senderId      = message.key.participant || message.key.remoteJid;
  const senderIsOwner = isOwner(senderId);

  if (isGroup) {
    let senderIsAdmin;

    if (extra && typeof extra.isAdmin === 'boolean') {
      senderIsAdmin = extra.isAdmin ?? senderIsOwner;
    } else {
      const res = await isAdminLib(sock, chatId, senderId).catch(() => ({ isSenderAdmin: false }));
      senderIsAdmin = res.isSenderAdmin;
    }

    if (!senderIsAdmin && !senderIsOwner) {
      await sock.sendMessage(chatId, {
        text: '🔒 *Permission Denied!*\n\nOnly a *group admin* or the *bot owner* can use .unban.',
        ...channelInfo,
      }, { quoted: message });
      return;
    }

  } else {
    const senderIsSudo = await isSudo(senderId).catch(() => false);
    if (!senderIsOwner && !senderIsSudo) {
      await sock.sendMessage(chatId, {
        text: '🔒 *Permission Denied!*\n\nOnly the owner/sudo can use .unban in a private chat.',
        ...channelInfo,
      }, { quoted: message });
      return;
    }
  }

  // ── Resolve target user ────────────────────────────────────────────────────
  let userToUnban = null;

  const mentionedJids = (
    message.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
    message.message?.imageMessage?.contextInfo?.mentionedJid        ||
    []
  );
  if (mentionedJids.length > 0) userToUnban = mentionedJids[0];

  if (!userToUnban) {
    const ctxPart = (
      message.message?.extendedTextMessage?.contextInfo?.participant ||
      message.message?.imageMessage?.contextInfo?.participant
    );
    if (ctxPart) userToUnban = ctxPart;
  }

  if (!userToUnban) {
    await sock.sendMessage(chatId, {
      text: '❌ *Mention a user or reply to their message!*\n\nUsage: *.unban @user*  or quote their message and send *.unban*',
      ...channelInfo,
    }, { quoted: message });
    return;
  }

  const userNum = normalizeNumber(userToUnban);
  if (!userNum) {
    await sock.sendMessage(chatId, { text: '❌ Invalid user JID.', ...channelInfo }, { quoted: message });
    return;
  }

  if (!isBanned(userNum)) {
    await sock.sendMessage(chatId, {
      text: `ℹ️ @${userNum} is not banned — this user can already use the bot.`,
      mentions: [userToUnban],
      ...channelInfo,
    }, { quoted: message });
    return;
  }

  // ── Perform unban ──────────────────────────────────────────────────────────
  unbanUser(userNum);

  await sock.sendMessage(chatId, {
    text: `╭━━━❰ ✅ 𝙐𝙉𝘽𝘼𝙉 𝘼𝘾𝙏𝙄𝙊𝙉 ❱━━━╮\n┃\n┃ 🔓 Unbanned: @${userNum}\n┃ ✅ Bot use allowed again\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯`,
    mentions: [userToUnban],
    ...channelInfo,
  }, { quoted: message });
}

module.exports = {
  name     : 'unban',
  aliases  : ['botunban'],
  category : 'admin',
  desc     : 'Unban a previously banned user',
  usage    : '.unban @user  or reply to their message',
  ownerOnly: true,
  execute  : async (sock, msg, args, extra) => unbanCommand(sock, msg.key.remoteJid, msg, extra),
};
