/**
 * Warnings Command
 * View how many warnings a user currently has in this group
 */

const database = require('../../database');
const config = require('../../config');

module.exports = {
  name: 'warnings',
  aliases: ['checkwarn', 'warnlist'],
  category: 'admin',
  description: "Check a user's current warning count",
  usage: '.warnings @user',
  groupOnly: true,

  async execute(sock, msg, args, extra) {
    try {
      let target;
      const ctx = msg.message?.extendedTextMessage?.contextInfo;
      const mentioned = ctx?.mentionedJid || [];

      if (mentioned.length > 0) {
        target = mentioned[0];
      } else if (ctx?.participant && ctx.stanzaId && ctx.quotedMessage) {
        target = ctx.participant;
      } else {
        return extra.reply('❌ Please mention or reply to the user whose warnings you want to check.\n\nExample: .warnings @user');
      }

      const warning = database.getWarnings(extra.from, target);

      await sock.sendMessage(extra.from, {
        text: `⚠️ *Warning Status*\n\n👤 User: @${target.split('@')[0]}\n📊 Warnings: ${warning.count}/${config.maxWarnings}` +
          (warning.reasons?.length ? `\n\n📝 Reasons:\n${warning.reasons.map((r, i) => `${i + 1}. ${r}`).join('\n')}` : ''),
        mentions: [target],
      }, { quoted: msg });

    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  },
};
