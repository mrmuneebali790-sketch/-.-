'use strict';

/**
 * .kickall — safely remove removable members from the current group.
 *
 * Safety rules:
 *  - Never removes the bot, the configured owner, or any group admin.
 *  - Removes one member per WhatsApp request with a delay instead of a
 *    burst, reducing rate-limit/anti-abuse risk.
 *  - Sends text progress only; it deliberately never plays the single-kick
 *    video, especially during a bulk operation.
 */

const OWNER_NUMBER = '923196615238';
const KICK_DELAY_MS = 1800;

const digits = value => String(value || '')
  .split(':')[0]
  .split('@')[0]
  .replace(/[^0-9]/g, '');

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function participantIds(participant) {
  return [
    participant?.id,
    participant?.lid,
    participant?.phoneNumber,
  ].filter(Boolean);
}

function isBotParticipant(participant, sock) {
  const botPhone = digits(sock.user?.id);
  const botLid = digits(sock.user?.lid);
  return participantIds(participant).some(id => {
    const n = digits(id);
    return n && (n === botPhone || n === botLid);
  });
}

function isOwnerParticipant(participant) {
  return participantIds(participant).some(id => digits(id) === OWNER_NUMBER);
}

module.exports = {
  name: 'kickall',
  aliases: ['removeall', 'clearall'],
  category: 'admin',
  description: 'Safely remove all removable non-admin members',
  usage: '.kickall',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    const chatId = extra.from;
    let progressKey = null;

    try {
      const metadata = await sock.groupMetadata(chatId);
      const participants = metadata?.participants || [];
      const targets = participants
        .filter(p => p?.id)
        .filter(p => !p.admin) // do not demote/remove admins
        .filter(p => !isBotParticipant(p, sock))
        .filter(p => !isOwnerParticipant(p))
        .map(p => p.id);

      if (!targets.length) {
        return extra.reply(
          'ℹ️ No removable members found. Bot, owner, and group admins are protected.'
        );
      }

      const start = await sock.sendMessage(chatId, {
        text:
          `⚠️ *Safe Kick-All Started*\n\n` +
          `👥 Removable members: *${targets.length}*\n` +
          `🛡️ Admins, owner, and the bot are protected.\n` +
          `🐢 Slow mode active — to avoid WhatsApp rate limits.\n` +
          `🎬 No video will be sent during this bulk operation.`,
      }, { quoted: msg });
      progressKey = start?.key || null;

      let removed = 0;
      let failed = 0;
      for (const jid of targets) {
        try {
          await sock.groupParticipantsUpdate(chatId, [jid], 'remove');
          removed++;
        } catch (error) {
          failed++;
          console.warn(`[kickall] Could not remove ${jid}: ${error.message}`);
        }

        // Keep progress edits infrequent; never send one message per member.
        if ((removed + failed) % 10 === 0 && progressKey) {
          try {
            await sock.sendMessage(chatId, {
              text: `⏳ *Kick-all progress:* ${removed + failed}/${targets.length}\n✅ Removed: ${removed} | ⚠️ Failed: ${failed}`,
              edit: progressKey,
            });
          } catch (_) {}
        }
        if (removed + failed < targets.length) await sleep(KICK_DELAY_MS);
      }

      const summary =
        `✅ *Safe Kick-All Complete*\n\n` +
        `✅ Removed: *${removed}*\n` +
        `⚠️ Failed/protected: *${failed}*\n` +
        `🛡️ Admins, owner, and the bot were not removed.\n` +
        `🎬 No bulk-kick video was sent.`;
      if (progressKey) {
        try {
          await sock.sendMessage(chatId, { text: summary, edit: progressKey });
          return;
        } catch (_) {}
      }
      await extra.reply(summary);
    } catch (error) {
      console.error('[kickall] error:', error.message);
      await extra.reply(`❌ Kick-all fail hua: ${error.message}`);
    }
  },
};