/**
 * TagNotAdmin Command
 * Mention every non-admin member of the group
 */

const { channelInfo } = require('../lib/messageConfig');

module.exports = {
  name: 'tagnotadmin',
  aliases: ['tna'],
  category: 'admin',
  description: 'Mention every non-admin member of the group',
  usage: '.tagnotadmin',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    try {
      const participants = extra.groupMetadata?.participants || [];
      const nonAdmins = participants.filter(p => !p.admin).map(p => p.id);

      if (nonAdmins.length === 0) {
        return extra.reply('ℹ️ There are no non-admin members to tag.');
      }

      let text = '🔊 *Hello Everyone:*\n\n';
      nonAdmins.forEach(jid => { text += `@${jid.split('@')[0]}\n`; });

      await sock.sendMessage(extra.from, {
        text,
        mentions: nonAdmins,
        ...channelInfo,
      }, { quoted: msg });

    } catch (error) {
      await extra.reply(`❌ Failed to tag non-admin members: ${error.message}`);
    }
  },
};
