'use strict';

/**
 * .mute — Per-user mute
 * Any messages the muted user sends are auto-deleted.
 * The group itself is not locked — only that user's messages are removed.
 */

const { channelInfo }  = require('../lib/messageConfig');
const isAdminLib        = require('../lib/isAdmin');
const isOwner           = require('../lib/isOwner');
const { muteUser, isMuted } = require('../../database');
const { normalizeJidWithLid } = require('../../utils/jidHelper');

function normalizeNum(jid) {
  let r = jid;
  try { r = normalizeJidWithLid(jid) || jid; } catch (_) {}
  return String(r || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

async function execute(sock, msg, args, extra) {
  const chatId        = extra.from;
  const senderId      = msg.key.participant || msg.key.remoteJid;
  const senderIsOwner = isOwner(senderId);

  // ── Admin / owner check ──────────────────────────────────────────────────
  let senderIsAdmin = extra.isAdmin ?? false;
  let botIsAdmin    = extra.isBotAdmin ?? false;

  if (!senderIsAdmin && !senderIsOwner) {
    return sock.sendMessage(chatId, {
      text: '🔒 *Permission Denied!*\n\nOnly a group admin or the bot owner can use .mute.',
      ...channelInfo,
    }, { quoted: msg });
  }

  if (!botIsAdmin) {
    return sock.sendMessage(chatId, {
      text: '⚠️ *Please make the bot an admin!*\n\nThe bot must be a group admin to delete messages.',
      ...channelInfo,
    }, { quoted: msg });
  }

  // ── Resolve target ───────────────────────────────────────────────────────
  let targetJid = null;

  const mentioned = (
    msg.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
    msg.message?.imageMessage?.contextInfo?.mentionedJid ||
    []
  );
  if (mentioned.length > 0) targetJid = mentioned[0];

  if (!targetJid) {
    const ctxPart = (
      msg.message?.extendedTextMessage?.contextInfo?.participant ||
      msg.message?.imageMessage?.contextInfo?.participant
    );
    if (ctxPart) targetJid = ctxPart;
  }

  if (!targetJid) {
    return sock.sendMessage(chatId, {
      text: '❌ *Mention a user or reply to their message to use .mute!*',
      ...channelInfo,
    }, { quoted: msg });
  }

  // The bot itself cannot be muted
  const botNum    = normalizeNum(sock.user?.id || '');
  const targetNum = normalizeNum(targetJid);
  if (targetNum === botNum) {
    return sock.sendMessage(chatId, { text: '❌ You cannot mute the bot!', ...channelInfo }, { quoted: msg });
  }

  if (isMuted(chatId, targetNum)) {
    return sock.sendMessage(chatId, {
      text: `ℹ️ @${targetNum} is already muted — their messages are already being deleted.`,
      mentions: [targetJid],
      ...channelInfo,
    }, { quoted: msg });
  }

  muteUser(chatId, targetNum);

  await sock.sendMessage(chatId, {
    text: `╭━━━❰ 🔇 𝙈𝙐𝙏𝙀 𝘼𝘾𝙏𝙄𝙊𝙉 ❱━━━╮\n┃\n┃ 🔇 Muted: @${targetNum}\n┃ 🗑️ Their messages will be deleted\n┃ ✅ They can still stay in the group\n┃ 📢 Use .unmute to restore them\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯`,
    mentions: [targetJid],
    ...channelInfo,
  }, { quoted: msg });
}

module.exports = {
  name          : 'mute',
  aliases       : ['muteusr', 'silenceuser'],
  category      : 'admin',
  desc          : 'Mute a user — their messages will be auto-deleted',
  usage         : '.mute @user  or reply to their message',
  groupOnly     : true,
  adminOnly     : false,   // checked internally
  botAdminNeeded: false,   // checked internally
  execute,
};
