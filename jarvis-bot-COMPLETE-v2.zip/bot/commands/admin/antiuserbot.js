'use strict';
/**
 * .antiuserbot on | off
 * ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡ — Ultra-Smart Anti-UserBot System
 *
 * Detection methods (multi-layer, instant):
 *  1. JID pattern   — bot accounts have numeric/repeating JID patterns
 *  2. Name pattern  — "bot", "auto", "ai", "gpt", "helper", "assistant" etc.
 *  3. Payload type  — interactive buttons / list messages = bot signature
 *  4. Foreign cmd   — messages starting with !, /, #, $, %, ^ = other bots
 *  5. Flood burst   — 4+ messages in 5 seconds from same user
 *  6. Repeat clone  — exact same message 3 times = automated account
 *  7. Mention spam  — tagging 5+ members in one go = bot behaviour
 *  8. URL flood     — 3+ links in one message = spam bot
 *  9. Empty account — no profile picture + no about = ghost/bot account
 * 10. Score system  — soft signals accumulate; if score ≥ threshold → remove
 */

const fs       = require('fs');
const path     = require('path');
const database = require('../../database');
const ANTIUSERBOT_VIDEO_PATH = path.join(__dirname, '../../data/antiuserbot-alert.mp4');

/* ─────────────────────────── in-memory tracking ─────────────────────────── */
// { groupJid: { userJid: { msgs:[], lastMsgTime, msgTimestamps:[], score } } }
const groupTracker = new Map();

/* ──────────────────────────── tuneable constants ─────────────────────────── */
const FLOOD_WINDOW_MS   = 5000;  // 5-second window for flood detection
const FLOOD_LIMIT       = 4;     // messages in window to trigger flood flag
const REPEAT_LIMIT      = 3;     // identical messages before flagging repeat
const MENTION_LIMIT     = 5;     // @mentions in one message = suspicious
const URL_LIMIT         = 3;     // links in one message = suspicious
const SCORE_THRESHOLD   = 3;     // accumulated soft-signal score to remove
const TRACKER_TTL_MS    = 60000; // clean tracker entries older than 1 min

/* soft-signal scores */
const SCORES = {
  FOREIGN_PREFIX : 2,
  MENTION_SPAM   : 2,
  URL_FLOOD      : 2,
  FLOOD          : 3,
  REPEAT         : 3,
  BOT_NAME       : 2,
  INTERACTIVE_MSG: 4, // immediate remove
  JID_PATTERN    : 2,
};

/* ───────────────────────── helper: bot-name regex ───────────────────────── */
const BOT_NAME_REGEX = /\b(bot|auto|autobot|ai|gpt|chatgpt|gemini|helper|assistant|robot|robo|spam|flood|sender|botter|userbott?|userbot)\b/i;

/* ───────────────────────── helper: foreign prefix ───────────────────────── */
const FOREIGN_PREFIX_REGEX = /^[!/\#$%^&*~|\\]{1}/;

/* ───────────────────────── helper: URL detection ────────────────────────── */
const URL_REGEX = /https?:\/\/[^\s]+/gi;

/* ───────────────────────── helper: JID pattern ──────────────────────────── */
// Real users rarely have JIDs like 12345678901234567890@s.whatsapp.net
// Many bot frameworks generate sequential / all-zero / repeated digit JIDs
function isSuspiciousJid(jid) {
  const number = jid.split('@')[0];
  if (!number || number.length < 10) return false;
  // All same digit repeated (e.g. 00000000000)
  if (/^(\d)\1{9,}$/.test(number)) return true;
  // Sequential digits like 12345678901
  if (/^(01234|12345|23456|34567|45678|56789|98765|87654)/.test(number)) return true;
  // Extremely long numbers (>15 digits) can be fake
  if (number.length > 15) return true;
  return false;
}

/* ─────────────────── get/init tracker for user in group ─────────────────── */
function getUserTracker(groupJid, userJid) {
  if (!groupTracker.has(groupJid)) groupTracker.set(groupJid, new Map());
  const gMap = groupTracker.get(groupJid);
  if (!gMap.has(userJid)) {
    gMap.set(userJid, {
      msgTimestamps : [],  // for flood detection
      lastMsgs      : [],  // for repeat detection (last 5 messages)
      score         : 0,
      flagReason    : [],
    });
  }
  return gMap.get(userJid);
}

/* ─────────────────── cleanup old tracker data ────────────────────────────── */
function cleanTracker(groupJid, userJid) {
  const tracker = getUserTracker(groupJid, userJid);
  const now = Date.now();
  tracker.msgTimestamps = tracker.msgTimestamps.filter(t => now - t < TRACKER_TTL_MS);
}

/* ══════════════════════════════════════════════════════════════════════════
   MAIN DETECTION ENGINE  — call this from your index.js message handler
   ══════════════════════════════════════════════════════════════════════════ */
async function detectAndRemoveBot(sock, msg, groupMetadata) {
  try {
    const groupJid  = msg.key.remoteJid;
    const senderJid = msg.key.participant || msg.participant || '';
    const msgBody   = (
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      msg.message?.videoMessage?.caption || ''
    ).trim();

    // Only process group messages from non-owners / non-admins
    if (!groupJid?.endsWith('@g.us')) return;
    if (!senderJid) return;

    /* ── load group settings ── */
    const gs = database.getGroupSettings(groupJid);
    if (!gs?.antiuserbot) return; // feature off

    /* ── exempt: group admins and bot owner ── */
    const ownerNumber = '923196615238';
    const senderNumber = senderJid.split('@')[0];
    if (senderNumber === ownerNumber) return;

    const adminList = (groupMetadata?.participants || [])
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .map(p => p.id);
    if (adminList.includes(senderJid)) return;

    /* ── get tracker ── */
    cleanTracker(groupJid, senderJid);
    const tracker = getUserTracker(groupJid, senderJid);
    const now     = Date.now();
    let score     = 0;
    const reasons = [];

    /* ══════════ INSTANT REMOVE CHECKS (score doesn't matter) ══════════ */

    /* 1. Interactive / button / list message → immediate bot signature */
    const msgType = Object.keys(msg.message || {})[0];
    if (
      msgType === 'buttonsMessage'        ||
      msgType === 'templateMessage'       ||
      msgType === 'listMessage'           ||
      msgType === 'interactiveMessage'    ||
      msgType === 'buttonsResponseMessage'||
      msgType === 'listResponseMessage'
    ) {
      return await removeBot(sock, groupJid, senderJid, msg,
        '🤖 Sent interactive/button message — instant bot signature detected');
    }

    /* ══════════ SCORED CHECKS ══════════ */

    /* 2. JID pattern */
    if (isSuspiciousJid(senderJid)) {
      score += SCORES.JID_PATTERN;
      reasons.push('Suspicious JID pattern');
    }

    /* 3. Bot name in display name */
    const senderName = groupMetadata?.participants?.find(p => p.id === senderJid)?.name || '';
    if (BOT_NAME_REGEX.test(senderName)) {
      score += SCORES.BOT_NAME;
      reasons.push(`Bot-like display name: "${senderName}"`);
    }

    /* 4. Foreign command prefix */
    if (msgBody && FOREIGN_PREFIX_REGEX.test(msgBody) && msgBody.length > 1) {
      // Make sure it's not our own prefix '.'
      if (!msgBody.startsWith('.')) {
        score += SCORES.FOREIGN_PREFIX;
        reasons.push(`Foreign bot command prefix: "${msgBody.slice(0, 10)}"`);
      }
    }

    /* 5. Mention spam */
    const mentionCount = (msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []).length;
    if (mentionCount >= MENTION_LIMIT) {
      score += SCORES.MENTION_SPAM;
      reasons.push(`Mass mention spam: ${mentionCount} users tagged`);
    }

    /* 6. URL flood */
    const urlMatches = msgBody.match(URL_REGEX) || [];
    if (urlMatches.length >= URL_LIMIT) {
      score += SCORES.URL_FLOOD;
      reasons.push(`URL flood: ${urlMatches.length} links in one message`);
    }

    /* 7. Flood burst detection */
    tracker.msgTimestamps.push(now);
    const recentMsgs = tracker.msgTimestamps.filter(t => now - t < FLOOD_WINDOW_MS);
    if (recentMsgs.length >= FLOOD_LIMIT) {
      score += SCORES.FLOOD;
      reasons.push(`Flood burst: ${recentMsgs.length} messages in 5 seconds`);
    }

    /* 8. Repeat / identical message detection */
    if (msgBody) {
      tracker.lastMsgs.push(msgBody);
      if (tracker.lastMsgs.length > 10) tracker.lastMsgs.shift(); // keep last 10
      const repeatCount = tracker.lastMsgs.filter(m => m === msgBody).length;
      if (repeatCount >= REPEAT_LIMIT) {
        score += SCORES.REPEAT;
        reasons.push(`Repeated identical message: ${repeatCount}× same text`);
        tracker.lastMsgs = []; // reset to avoid double-flag
      }
    }

    /* ══════════ DECISION ══════════ */
    tracker.score += score;

    if (tracker.score >= SCORE_THRESHOLD) {
      tracker.score = 0; // reset so we don't spam-remove
      const fullReason = reasons.join(' | ') || 'Accumulated suspicious behaviour';
      await removeBot(sock, groupJid, senderJid, msg, fullReason);
    }

  } catch (err) {
    console.error('[AntiUserbot Engine]', err?.message || err);
  }
}

/* ─────────────────── actual remove + alert function ─────────────────────── */
async function removeBot(sock, groupJid, botJid, msg, reason) {
  try {
    // 1. Remove from group
    await sock.groupParticipantsUpdate(groupJid, [botJid], 'remove');

    // 2. Alert in group using the fixed legacy alert video.
    const number = botJid.split('@')[0];
    const alertText =
        `*[ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡ ]*\n\n` +
        `🚫 *Bot / Suspicious Account Removed!*\n\n` +
        `👤 Number: @${number}\n` +
        `📋 Reason: ${reason}\n\n` +
        `🛡️ _Anti-UserBot Protection is Active_\n` +
        `> Powered by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`;
    if (fs.existsSync(ANTIUSERBOT_VIDEO_PATH)) {
      await sock.sendMessage(groupJid, {
        video: fs.readFileSync(ANTIUSERBOT_VIDEO_PATH),
        mimetype: 'video/mp4',
        fileName: 'antiuserbot-alert.mp4',
        caption: alertText,
        mentions: [botJid],
      }, { quoted: msg });
    } else {
      await sock.sendMessage(groupJid, {
        text: alertText,
        mentions: [botJid],
      }, { quoted: msg });
    }

  } catch (err) {
    console.error('[AntiUserbot Remove]', err?.message || err);
  }
}

/* ══════════════════════════════════════════════════════════════════════════
   COMMAND HANDLER — .antiuserbot on / off
   ══════════════════════════════════════════════════════════════════════════ */
module.exports = {
  name          : 'antiuserbot',
  aliases       : ['antibots', 'antibot2'],
  category      : 'admin',
  description   : 'Toggle ultra-smart anti-userbot / bot detection system',
  usage         : '.antiuserbot on | .antiuserbot off',
  groupOnly     : true,
  adminOnly     : true,
  botAdminNeeded: true,

  /* expose engine so index.js can import and call it */
  detectAndRemoveBot,

  async execute(sock, msg, args, extra) {
    try {
      const { from, reply } = extra;
      const gs  = database.getGroupSettings(from);
      const opt = (args[0] || '').toLowerCase();

      /* ── status display ── */
      if (!opt) {
        const state = gs.antiuserbot ? '✅ ON' : '❌ OFF';
        return reply(
          `*[ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡ ]*\n\n` +
          `🛡️ *Ultra-Smart Anti-UserBot*\n\n` +
          `Status: *${state}*\n\n` +
          `🔍 *Detection Layers:*\n` +
          `  • ⚡ Interactive/button message → instant remove\n` +
          `  • 🤖 Bot-like display name detection\n` +
          `  • 🔢 Suspicious JID pattern check\n` +
          `  • 💥 Flood burst (4 msgs / 5 sec)\n` +
          `  • 🔁 Identical message repeat (×3)\n` +
          `  • 📢 Mass mention spam (5+ users)\n` +
          `  • 🔗 URL flood (3+ links)\n` +
          `  • 🚩 Foreign bot prefix (!,/,#,$)\n\n` +
          `Commands:\n` +
          `  *.antiuserbot on*  — Enable protection\n` +
          `  *.antiuserbot off* — Disable protection`
        );
      }

      /* ── enable ── */
      if (opt === 'on') {
        if (gs.antiuserbot) return reply('🛡️ Anti-UserBot is already *ON*.');
        database.updateGroupSettings(from, { antiuserbot: true });
        return await sock.sendMessage(from, {
          text:
            `*[ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡ ]*\n\n` +
            `✅ *Ultra-Smart Anti-UserBot ENABLED!*\n\n` +
            `🔥 Any bot or suspicious automated account will be\n` +
            `detected *instantly* and removed — no delay!\n\n` +
            `Detection is multi-layered:\n` +
            `Flood • Repeat • Name • JID • Prefix • Mentions • URLs\n\n` +
            `> Admins and owner are always exempt.\n` +
            `> Powered by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`
        }, { quoted: msg });
      }

      /* ── disable ── */
      if (opt === 'off') {
        if (!gs.antiuserbot) return reply('🛡️ Anti-UserBot is already *OFF*.');
        database.updateGroupSettings(from, { antiuserbot: false });
        return await sock.sendMessage(from, {
          text:
            `*[ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡ ]*\n\n` +
            `❌ *Anti-UserBot Protection Disabled*\n\n` +
            `Bot detection is now OFF for this group.\n` +
            `> Powered by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`
        }, { quoted: msg });
      }

      return reply(`❌ Unknown option "*${opt}*". Use *.antiuserbot on* or *.antiuserbot off*`);

    } catch (err) {
      console.error('[AntiUserbot Cmd]', err?.message || err);
      await extra.reply(`❌ Error: ${err.message}`);
    }
  }
};
