'use strict';

/**
 * .chatbot on / .chatbot off
 * Enables or disables the smart chatbot for a group/DM.
 * The engine lives in commands/admin/chatbot.js
 */

const { handleChatbotCommand } = require('./chatbot');

module.exports = {
  name:          'chatbot',
  aliases:       ['cb', 'chatbotmode'],
  category:      'admin',
  desc:          'Enable or disable the smart AI chatbot for this chat',
  usage:         'chatbot on | chatbot off',
  groupOnly:     false,
  adminOnly:     false,
  ownerOnly:     true,
  botAdminNeeded: false,

  execute: async (sock, msg, args, ctx) => {
    const chatId = msg.key.remoteJid;
    // Join all args so "dm on", "dm off", "dm" are passed together
    const match  = args.length ? args.join(' ').toLowerCase() : null;
    await handleChatbotCommand(sock, chatId, msg, match, ctx);
  },
};
