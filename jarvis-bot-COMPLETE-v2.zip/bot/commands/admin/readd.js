/**
 * .readd on/off — Toggle Auto Re-Add system per group
 *
 * When ON:  If any user leaves/is removed, the bot instantly re-adds them.
 *           SUCCESS → sends fun Hinglish message mentioning the user.
 *           FAIL    → sends a different message explaining privacy restrictions.
 * When OFF: Normal behaviour (goodbye message if enabled, nothing otherwise).
 *
 * Requires: Bot must be GROUP ADMIN to re-add users.
 * Anti-spam: Each user is only processed once per 60 seconds per group.
 */

module.exports = {
  name      : 'readd',
  category  : 'admin',
  adminOnly : true,
  description: 'Auto re-add users who leave/are removed from the group',
  usage     : '.readd on/off',

  async execute(sock, msg, args, extra) {
    const from = msg.key.remoteJid;

    if (!from?.endsWith('@g.us')) {
      return extra.reply('❌ This command can only be used in groups.');
    }

    if (!args[0] || !['on', 'off'].includes(args[0].toLowerCase())) {
      const database = require('../../database');
      const gs       = database.getGroupSettings(from);
      const status   = gs.readd ? '✅ ON' : '❌ OFF';
      return extra.reply(
        `🔄 *Auto Re-Add System*\n\n` +
        `Current Status: *${status}*\n\n` +
        `Usage:\n` +
        `▸ *.readd on*  — Enable auto re-add\n` +
        `▸ *.readd off* — Disable auto re-add\n\n` +
        `⚠️ Bot must be group *admin* to re-add users.`
      );
    }

    const enabled  = args[0].toLowerCase() === 'on';
    const database = require('../../database');
    database.updateGroupSettings(from, { readd: enabled });

    if (enabled) {
      await extra.reply(
        `✅ *Auto Re-Add: ENABLED*\n\n` +
        `Anyone who leaves or is removed will be automatically re-added.\n\n` +
        `• Bot must be admin for this to work\n` +
        `• Anti-spam: each user has a 60-second cooldown\n` +
        `• If user's privacy blocks re-add, a message will be sent in group\n\n` +
        `> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`
      );
    } else {
      await extra.reply(
        `❌ *Auto Re-Add: DISABLED*\n\n` +
        `Users can now leave/be removed normally.\n\n` +
        `> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`
      );
    }
  }
};
