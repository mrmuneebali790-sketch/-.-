'use strict';

const { channelInfo }         = require('../lib/messageConfig');
const isAdminLib               = require('../lib/isAdmin');
const { isSudo }               = require('../lib/index');
const { banUser, isBanned }    = require('../../database');
const { normalizeJidWithLid }  = require('../../utils/jidHelper');
const isOwner                  = require('../lib/isOwner');   // exports fn directly

// Normalize any JID / LID to digits-only phone number
function normalizeNumber(jid) {
  let resolved = jid;
  try { resolved = normalizeJidWithLid(jid) || jid; } catch (_) {}
  return String(resolved || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

async function banCommand(sock, chatId, message, extra) {
  const isGroup       = chatId.endsWith('@g.us');
  const senderId      = message.key.participant || message.key.remoteJid;
  const senderIsOwner = isOwner(senderId);

  if (isGroup) {
    // ── Use handler's pre-computed isBotAdmin when available (most accurate) ──
    // extra.isBotAdmin comes from handler.js's sophisticated multi-format check.
    // Fall back to our own lib only when called outside the command pipeline.
    let botIsAdmin;
    let senderIsAdmin;

    if (extra && typeof extra.isBotAdmin === 'boolean') {
      // Handler already resolved these — use directly, no extra API call
      botIsAdmin    = extra.isBotAdmin;
      senderIsAdmin = extra.isAdmin ?? senderIsOwner;
    } else {
      const res = await isAdminLib(sock, chatId, senderId).catch(() => ({ isBotAdmin: false, isSenderAdmin: false }));
      botIsAdmin    = res.isBotAdmin;
      senderIsAdmin = res.isSenderAdmin;
    }

    if (!botIsAdmin) {
      await sock.sendMessage(chatId, {
        text: '⚠️ *Please make the bot a group admin first!*\n\nThe bot must be an admin to use .ban.',
        ...channelInfo,
      }, { quoted: message });
      return;
    }

    if (!senderIsAdmin && !senderIsOwner) {
      await sock.sendMessage(chatId, {
        text: '🔒 *Permission Denied!*\n\nOnly a *group admin* or the *bot owner* can use .ban.',
        ...channelInfo,
      }, { quoted: message });
      return;
    }

  } else {
    // Private chat — only owner / sudo
    const senderIsSudo = await isSudo(senderId).catch(() => false);
    if (!senderIsOwner && !senderIsSudo) {
      await sock.sendMessage(chatId, {
        text: '🔒 *Permission Denied!*\n\nOnly the owner/sudo can use .ban in a private chat.',
        ...channelInfo,
      }, { quoted: message });
      return;
    }
  }

  // ── Resolve target user ────────────────────────────────────────────────────
  let userToBan = null;

  // Priority 1: @mention
  const mentionedJids = (
    message.message?.extendedTextMessage?.contextInfo?.mentionedJid ||
    message.message?.imageMessage?.contextInfo?.mentionedJid        ||
    []
  );
  if (mentionedJids.length > 0) userToBan = mentionedJids[0];

  // Priority 2: reply-to participant
  if (!userToBan) {
    const ctxPart = (
      message.message?.extendedTextMessage?.contextInfo?.participant ||
      message.message?.imageMessage?.contextInfo?.participant
    );
    if (ctxPart) userToBan = ctxPart;
  }

  if (!userToBan) {
    await sock.sendMessage(chatId, {
      text: '❌ *Mention a user or reply to their message!*\n\nUsage: *.ban @user*  or quote their message and send *.ban*',
      ...channelInfo,
    }, { quoted: message });
    return;
  }

  // Prevent banning the bot itself
  try {
    const botNum    = normalizeNumber(sock.user.id);
    const targetNum = normalizeNumber(userToBan);
    if (targetNum === botNum) {
      await sock.sendMessage(chatId, { text: '❌ You cannot ban the bot!', ...channelInfo }, { quoted: message });
      return;
    }
  } catch (_) {}

  const userNum = normalizeNumber(userToBan);
  if (!userNum) {
    await sock.sendMessage(chatId, { text: '❌ Invalid user JID.', ...channelInfo }, { quoted: message });
    return;
  }

  // ── Perform ban (commands blocked only — NOT removed from group) ──────────
  banUser(userNum);

  await sock.sendMessage(chatId, {
    text: `╭━━━❰ ⚠️ 𝘽𝘼𝙉 𝘼𝘾𝙏𝙄𝙊𝙉 ❱━━━╮\n┃\n┃ 🔒 Banned: @${userNum}\n┃ ✅ Bot commands blocked\n┃ ℹ️ Still allowed to remain in the group\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯`,
    mentions: [userToBan],
    ...channelInfo,
  }, { quoted: message });
}

module.exports = {
  name     : 'ban',
  aliases  : ['botban'],
  category : 'owner',
  desc     : 'Ban a user from using the bot (Owner only)',
  usage    : '.ban @user  or reply to their message',
  ownerOnly: true,
  execute  : async (sock, msg, args, extra) => banCommand(sock, msg.key.remoteJid, msg, extra),
};
