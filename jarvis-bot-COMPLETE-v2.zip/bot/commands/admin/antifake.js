'use strict';

/**
 * Anti-Fake Account / Voice Verification System
 * .antifake on  — enable voice verification for new members
 * .antifake off — disable
 * Aliases: .antigay
 *
 * adminOnly: true  → handler.js does the owner/admin check with full LID support.
 *                    Owner (923329838699) is always allowed even without group admin role.
 */

const database = require('../../database');
const config   = require('../../config');
const { getPending } = require('../../utils/antifakeState');

module.exports = {
  name: 'antifake',
  aliases: ['antigay', 'antifakeaccount', 'fakeverify'],
  category: 'admin',
  description: 'Enable/disable voice verification system for new group members',
  usage: '.antifake on | .antifake off | .antifake status',
  groupOnly: true,
  adminOnly: true,   // handler.js checks this — owner bypass built in, LID-aware

  async execute(sock, msg, args, extra) {
    const { from, isBotAdmin, reply } = extra;

    const action = (args[0] || '').toLowerCase();

    // ── Status / no arg ────────────────────────────────────────────────────
    if (!action || action === 'status') {
      const gs      = database.getGroupSettings(from);
      const pending = getPending(from);
      const pendingList = pending.size > 0
        ? [...pending.entries()].map(([jid, d]) =>
            `• @${jid.split('@')[0].split(':')[0]}${d.voiceReceived ? ' ✅ voice note sent' : ' ⏳ awaiting voice'}`
          ).join('\n')
        : '• None';

      return await sock.sendMessage(from, {
        text:
`🛡️ *Anti-Fake Account System*
━━━━━━━━━━━━━━━━━━━━
Status: ${gs.antifake ? '✅ *ON* — Verification Active' : '❌ *OFF* — Disabled'}

📋 *Pending Verifications (${pending.size}):*
${pendingList}

📌 *Commands:*
• \`.antifake on\` — Enable
• \`.antifake off\` — Disable
• \`.ok @user\` — Verify & accept user
• \`.kick @user\` — Remove fake account

> Powered by ${config.botName}`,
        mentions: [...pending.keys()]
      });
    }

    // ── on / off ───────────────────────────────────────────────────────────
    if (!['on', 'off'].includes(action)) {
      return reply(`❓ Invalid option. Use: .antifake on | .antifake off | .antifake status`);
    }

    const enable = action === 'on';
    database.updateGroupSettings(from, { antifake: enable });

    if (enable) {
      const botAdminWarn = isBotAdmin
        ? ''
        : '\n\n⚠️ *Warning:* The bot is not an admin of this group yet! Anti-fake will not work properly until the bot is made an admin.';

      return await sock.sendMessage(from, {
        text:
`✅ *Anti-Fake Account System — ENABLED!*
━━━━━━━━━━━━━━━━━━━━
🔐 This group is now fully protected!

🔄 *Flow:*
1️⃣ A new member joins
2️⃣ The bot sends them a verification prompt
3️⃣ The member sends a 5-second voice note saying: *"I am real"*
4️⃣ An admin or the owner reviews it

✅ *Accept:* \`.ok @user\`
❌ *Reject:* \`.kick @user\`${botAdminWarn}

> Powered by ${config.botName} 🛡️`
      });
    } else {
      return await sock.sendMessage(from, {
        text:
`❌ *Anti-Fake Account System — DISABLED!*
━━━━━━━━━━━━━━━━━━━━
The verification system has been turned off.
New members can now join without verification.

> Powered by ${config.botName}`
      });
    }
  }
};
