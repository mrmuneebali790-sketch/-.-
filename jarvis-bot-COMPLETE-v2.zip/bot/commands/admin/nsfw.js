const database = require('../../database');

module.exports = {
  name       : 'nsfw',
  aliases    : ['nsfwshield', 'nsfwfilter'],
  category   : 'admin',
  description: 'Toggle NSFW content detection & auto-removal per group',
  usage      : '.nsfw on/off',
  groupOnly  : true,
  adminOnly  : true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    const from = msg.key.remoteJid;
    const gs   = database.getGroupSettings(from);

    if (!args[0] || !['on', 'off'].includes(args[0].toLowerCase())) {
      const status = gs.nsfw ? '✅ ON' : '❌ OFF';
      return extra.reply(
        `🔞 *NSFW Shield — Status: ${status}*\n\n` +
        `▸ *.nsfw on*  — Enable auto NSFW detection\n` +
        `▸ *.nsfw off* — Disable NSFW detection\n\n` +
        `When *ON*:\n` +
        `• Scans images, videos, stickers & text\n` +
        `• Deletes NSFW content automatically\n` +
        `• Removes the user (bot must be admin)\n\n` +
        `> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`
      );
    }

    const enable = args[0].toLowerCase() === 'on';
    database.updateGroupSettings(from, { nsfw: enable });

    if (enable) {
      return extra.reply(
        `✅ *NSFW Shield: ENABLED*\n\n` +
        `🛡️ Adult content detection is now *active* in this group.\n` +
        `• Images, videos, stickers & links are scanned\n` +
        `• Violators are warned and removed automatically\n\n` +
        `> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`
      );
    } else {
      return extra.reply(
        `❌ *NSFW Shield: DISABLED*\n\n` +
        `NSFW content detection has been turned off for this group.\n\n` +
        `> *Powered by 🥀 𝐉𝐀𝐑𝐕𝐈𝐒 🌴*`
      );
    }
  }
};
