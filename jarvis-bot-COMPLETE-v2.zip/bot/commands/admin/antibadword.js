/**
 * AntiBadword Command
 * Enable/disable a bad-word filter for the group and manage the word list.
 * Detection itself runs in handler.js (handleAntibadword), same pattern as antilink.
 */

const database = require('../../database');

const DEFAULT_BADWORDS = ['fuck', 'bitch', 'asshole', 'bastard', 'slut', 'whore', 'dick', 'nigger'];

module.exports = {
  name: 'antibadword',
  aliases: ['badword'],
  description: 'Configure the bad-word filter for this group',
  usage: '.antibadword <on/off/set/add/remove/list>',
  category: 'admin',
  groupOnly: true,
  adminOnly: true,
  botAdminNeeded: true,

  async execute(sock, msg, args, extra) {
    try {
      const settings = database.getGroupSettings(extra.from);
      const words = settings.badwords || DEFAULT_BADWORDS;

      if (!args[0]) {
        const status = settings.antibadword ? 'ON' : 'OFF';
        const action = settings.antibadwordAction || 'delete';
        return extra.reply(
          `🤬 Anti-badword is *${status}* (action: *${action}*).\n` +
          'Usage:\n' +
          '  .antibadword on\n' +
          '  .antibadword off\n' +
          '  .antibadword set delete | kick\n' +
          '  .antibadword add <word>\n' +
          '  .antibadword remove <word>\n' +
          '  .antibadword list'
        );
      }

      const opt = args[0].toLowerCase();

      if (opt === 'on') {
        if (settings.antibadword) return extra.reply('*Anti-badword is already on*');
        database.updateGroupSettings(extra.from, { antibadword: true, badwords: words });
        return extra.reply('*Anti-badword has been turned ON*');
      }

      if (opt === 'off') {
        database.updateGroupSettings(extra.from, { antibadword: false });
        return extra.reply('*Anti-badword has been turned OFF*');
      }

      if (opt === 'set') {
        const action = (args[1] || '').toLowerCase();
        if (!['delete', 'kick'].includes(action)) {
          return extra.reply('*Please specify an action: .antibadword set delete | kick*');
        }
        database.updateGroupSettings(extra.from, { antibadwordAction: action, antibadword: true });
        return extra.reply(`*Anti-badword action set to ${action}*`);
      }

      if (opt === 'add') {
        const word = (args[1] || '').toLowerCase().trim();
        if (!word) return extra.reply('*Please specify a word to add: .antibadword add <word>*');
        if (words.includes(word)) return extra.reply('*That word is already in the list*');
        const updated = [...words, word];
        database.updateGroupSettings(extra.from, { badwords: updated });
        return extra.reply(`*Added "${word}" to the bad-word list*`);
      }

      if (opt === 'remove') {
        const word = (args[1] || '').toLowerCase().trim();
        if (!word) return extra.reply('*Please specify a word to remove: .antibadword remove <word>*');
        const updated = words.filter(w => w !== word);
        database.updateGroupSettings(extra.from, { badwords: updated });
        return extra.reply(`*Removed "${word}" from the bad-word list*`);
      }

      if (opt === 'list') {
        return extra.reply(`🤬 *Bad-word list* (${words.length}):\n${words.join(', ')}`);
      }

      return extra.reply('*Use .antibadword for usage.*');

    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  },
};
