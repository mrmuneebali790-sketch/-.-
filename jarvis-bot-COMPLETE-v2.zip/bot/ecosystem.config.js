/**
 * PM2 Ecosystem Config — JARVIS
 *
 * USAGE:
 *   npm install -g pm2          # install PM2 globally (once)
 *   pm2 start ecosystem.config.js   # start the bot
 *   pm2 save                    # save process list
 *   pm2 startup                 # generate OS boot script
 *   pm2 logs mr-muneeb-ali-bot  # view logs
 *   pm2 monit                   # real-time dashboard
 *   pm2 restart mr-muneeb-ali-bot   # restart
 *   pm2 stop mr-muneeb-ali-bot      # stop
 *   pm2 delete mr-muneeb-ali-bot    # remove from PM2
 *
 * NOTE: startup.js IS the watchdog. PM2 manages startup.js,
 *       and startup.js manages index.js internally.
 *       This gives you a two-layer recovery system.
 */

'use strict';

const path = require('path');
const fs   = require('fs');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });

module.exports = {
  apps: [
    {
      // ── Identity ──────────────────────────────────────────────────────────
      name        : 'mr-muneeb-ali-bot',
      script      : './startup.js',
      cwd         : __dirname,
      interpreter : 'node',

      // ── Restart policy ────────────────────────────────────────────────────
      autorestart       : true,
      watch             : false,      // file-watch causes restart loops
      max_restarts      : 0,          // 0 = unlimited restarts (was 50 — PM2 would give up)
      min_uptime        : '5s',       // must stay up 5s to count as "stable" (was 15s)
      restart_delay     : 3000,       // 3s between PM2-level restarts (was 5s)
      exp_backoff_restart_delay: 100, // faster exponential back-off (was 200)

      // ── Memory guard ──────────────────────────────────────────────────────
      max_memory_restart: '1800M',    // PM2 restarts if RSS > 1.8 GB (was 1.6 GB)

      // ── Node.js flags (startup.js passes these to index.js too) ──────────
      node_args: '--max-old-space-size=512 --optimize-for-size',
      // Note: startup.js already passes --max-old-space-size=1536 to index.js
      // These flags above apply to startup.js (watchdog) itself

      // ── Environment ───────────────────────────────────────────────────────
      env: {
        NODE_ENV: 'production',
      },
      env_development: {
        NODE_ENV: 'development',
      },

      // ── Logging ───────────────────────────────────────────────────────────
      log_date_format : 'YYYY-MM-DD HH:mm:ss Z',
      out_file        : './logs/pm2-out.log',
      error_file      : './logs/pm2-error.log',
      merge_logs      : true,

      // ── Graceful shutdown ─────────────────────────────────────────────────
      kill_timeout        : 10000,   // 10s for graceful shutdown before SIGKILL
      listen_timeout      : 20000,   // 20s wait for app to be "online"
      shutdown_with_message: true,

      // ── Instance mode: single process (not cluster) ───────────────────────
      instances  : 1,
      exec_mode  : 'fork',
    }
  ]
};
