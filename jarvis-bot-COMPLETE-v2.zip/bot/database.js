/**
 * database.js - JSON-based flat-file database for group settings, users, warnings
 *
 * Write-lock: all file writes are serialised through a per-file async queue
 * so that 12 concurrent sessions can never corrupt a JSON file by writing
 * at the same time.
 *
 * Per-bot isolation: getBotSetting / setBotSetting / updateBotSettings store
 * per-session config (autoReact, prefix, botName, etc.) keyed by bot phone number.
 */

const fs = require('fs');
const path = require('path');
const config = require('./config');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const FILES = {
  groupSettings: path.join(DATA_DIR, 'groupSettings.json'),
  warnings:      path.join(DATA_DIR, 'warnings.json'),
  banned:        path.join(DATA_DIR, 'banned.json'),
  moderators:    path.join(DATA_DIR, 'moderators.json'),
  mutedUsers:    path.join(DATA_DIR, 'mutedUsers.json'),
  botSettings:   path.join(DATA_DIR, 'botSettings.json'),   // ← per-bot isolated settings
};

const _writeQueues  = new Map();
const _writeBusy    = new Map();

async function _runWriteQueue(file) {
  if (_writeBusy.get(file)) return;
  _writeBusy.set(file, true);
  const queue = _writeQueues.get(file) || [];
  while (queue.length > 0) {
    const task = queue.shift();
    try { await task(); } catch (_) {}
  }
  _writeBusy.set(file, false);
}

function _enqueueWrite(file, task) {
  if (!_writeQueues.has(file)) _writeQueues.set(file, []);
  return new Promise((resolve, reject) => {
    _writeQueues.get(file).push(async () => {
      try { resolve(await task()); }
      catch (e) { reject(e); }
    });
    _runWriteQueue(file);
  });
}

function readJSON(file, defaultVal) {
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf8'));
    }
  } catch (_) {}
  return defaultVal;
}

function _writeJSONSync(file, data) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

function writeJSON(file, data) {
  return _enqueueWrite(file, () => _writeJSONSync(file, data));
}

function getGroupSettings(groupId) {
  const all = readJSON(FILES.groupSettings, {});
  return { ...config.defaultGroupSettings, ...(all[groupId] || {}) };
}

function updateGroupSettings(groupId, updates) {
  const all = readJSON(FILES.groupSettings, {});
  all[groupId] = { ...(all[groupId] || {}), ...updates };
  writeJSON(FILES.groupSettings, all);
  return all[groupId];
}

function getWarnings(groupId, userId) {
  const all = readJSON(FILES.warnings, {});
  const key = `${groupId}:${userId}`;
  return all[key] || { count: 0, reasons: [] };
}

function addWarning(groupId, userId, reason) {
  const all = readJSON(FILES.warnings, {});
  const key = `${groupId}:${userId}`;
  if (!all[key]) all[key] = { count: 0, reasons: [] };
  all[key].count += 1;
  all[key].reasons.push(reason || 'No reason');
  writeJSON(FILES.warnings, all);
  return all[key];
}

function clearWarnings(groupId, userId) {
  const all = readJSON(FILES.warnings, {});
  const key = `${groupId}:${userId}`;
  delete all[key];
  writeJSON(FILES.warnings, all);
}

function normalizeBanKey(userId) {
  return String(userId || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

function getBanned() {
  return readJSON(FILES.banned, []).map(normalizeBanKey).filter(Boolean);
}

function isBanned(userId) {
  return getBanned().includes(normalizeBanKey(userId));
}

function banUser(userId) {
  const key = normalizeBanKey(userId);
  if (!key) return;
  const banned = getBanned();
  if (!banned.includes(key)) {
    banned.push(key);
    writeJSON(FILES.banned, banned);
  }
}

function unbanUser(userId) {
  const key = normalizeBanKey(userId);
  const banned = getBanned().filter(u => u !== key);
  writeJSON(FILES.banned, banned);
}

// ── Per-user mute (message auto-delete) ──────────────────────────────────────

function normalizeMuteKey(jid) {
  return String(jid || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '');
}

function getMutedUsers(groupId) {
  const all = readJSON(FILES.mutedUsers, {});
  return all[groupId] || [];
}

function isMuted(groupId, userId) {
  return getMutedUsers(groupId).includes(normalizeMuteKey(userId));
}

function muteUser(groupId, userId) {
  const key  = normalizeMuteKey(userId);
  if (!key) return;
  const all  = readJSON(FILES.mutedUsers, {});
  if (!all[groupId]) all[groupId] = [];
  if (!all[groupId].includes(key)) {
    all[groupId].push(key);
    writeJSON(FILES.mutedUsers, all);
  }
}

function unmuteUser(groupId, userId) {
  const key = normalizeMuteKey(userId);
  const all = readJSON(FILES.mutedUsers, {});
  if (!all[groupId]) return;
  all[groupId] = all[groupId].filter(u => u !== key);
  if (all[groupId].length === 0) delete all[groupId];
  writeJSON(FILES.mutedUsers, all);
}

function getModerators() {
  return readJSON(FILES.moderators, []);
}

function isModerator(number) {
  return getModerators().includes(number);
}

function addModerator(number) {
  const mods = getModerators();
  if (!mods.includes(number)) {
    mods.push(number);
    writeJSON(FILES.moderators, mods);
  }
}

function removeModerator(number) {
  const mods = getModerators().filter(m => m !== number);
  writeJSON(FILES.moderators, mods);
}

// ── Per-Bot Isolated Settings ─────────────────────────────────────────────────
// Each bot session is identified by its phone number (digits only).
// Stored in data/botSettings.json:
// { "923xxxxxxxxx": { "autoReact": true, "autoReactMode": "bot", "prefix": ".", ... } }

function _normalizeBotId(botId) {
  return String(botId || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '') || 'default';
}

/**
 * Get all settings for a specific bot session.
 * @param {string} botId  - sock.user.id or phone number
 * @returns {object}
 */
function getBotSettings(botId) {
  const all = readJSON(FILES.botSettings, {});
  return all[_normalizeBotId(botId)] || {};
}

/**
 * Get a single setting for a bot session, with optional default.
 * @param {string} botId
 * @param {string} key
 * @param {*}      defaultVal
 * @returns {*}
 */
function getBotSetting(botId, key, defaultVal = null) {
  const settings = getBotSettings(botId);
  return key in settings ? settings[key] : defaultVal;
}

/**
 * Set a single setting for a bot session.
 * @param {string} botId
 * @param {string} key
 * @param {*}      value
 */
function setBotSetting(botId, key, value) {
  const id  = _normalizeBotId(botId);
  const all = readJSON(FILES.botSettings, {});
  if (!all[id]) all[id] = {};
  all[id][key] = value;
  // Bot settings are read/modify/write operations. Writing the complete
  // object through the async queue after the read can lose a concurrent
  // session's update because both callers may have read the same snapshot.
  // The file is small, so keep this operation atomic within the Node process.
  _writeJSONSync(FILES.botSettings, all);
  return value;
}

/**
 * Merge multiple settings at once for a bot session.
 * @param {string} botId
 * @param {object} updates
 * @returns {object}  updated settings object
 */
function updateBotSettings(botId, updates) {
  const id  = _normalizeBotId(botId);
  const all = readJSON(FILES.botSettings, {});
  all[id]   = { ...(all[id] || {}), ...updates };
  _writeJSONSync(FILES.botSettings, all);
  return all[id];
}

module.exports = {
  getGroupSettings,
  updateGroupSettings,
  getWarnings,
  addWarning,
  clearWarnings,
  getBanned,
  isBanned,
  banUser,
  unbanUser,
  getMutedUsers,
  isMuted,
  muteUser,
  unmuteUser,
  getModerators,
  isModerator,
  addModerator,
  removeModerator,
  // Per-bot settings
  getBotSettings,
  getBotSetting,
  setBotSetting,
  updateBotSettings,
};
