/**
 * WhatsApp MD Bot — Main Entry Point
 *
 * Responsibilities:
 *  1. Set env vars before any library loads (temp dirs, Puppeteer disable)
 *  2. Suppress Baileys signal-protocol noise from console
 *  3. Start keep-alive + memory monitoring
 *  4. Start the web panel (which manages all WhatsApp sessions)
 *  5. Bootstrap Session 1 from SESSION_ID env var if present
 *  6. Install global crash guards
 */

'use strict';

// ── Must happen before ANY library loads ──────────────────────────────────────
// Set Pakistan timezone globally — affects new Date(), toLocaleString(), logs
process.env.TZ                               = 'Asia/Karachi';
process.env.PUPPETEER_SKIP_DOWNLOAD          = 'true';
process.env.PUPPETEER_SKIP_CHROMIUM_DOWNLOAD = 'true';
process.env.PUPPETEER_CACHE_DIR              = process.env.PUPPETEER_CACHE_DIR || '/tmp/puppeteer_disabled';

const { initializeTempSystem } = require('./utils/tempManager');
initializeTempSystem(); // sets TMPDIR / TMP / TEMP before any library loads

// ── Baileys noise suppression (two-level: stdout.write + console.*) ──────────
// Baileys' signal-protocol layer writes "Closing session: SessionEntry {...}"
// and similar messages DIRECTLY to process.stdout.write — completely bypassing
// console.log. We must intercept at the lowest level (stdout/stderr write) to
// stop these from flooding the logs. console.log/error/warn are also patched for
// anything that goes through them.
const SUPPRESS_RE = new RegExp(
  'closing session|closing open session|sessionentry|' +
  'prekey bundle|pendingprekey|_chains|registrationid|' +
  'currentratchet|chainkey|ratchet|signal protocol|' +
  'ephemeralkeypair|indexinfo|ratchetkey|' +
  'decrypted message with closed session|' +
  'failed to decrypt message|messagecountererror|' +
  'key used already or never filled|' +
  'session_cipher|session error:|dosessionreset|' +
  'doDecryptWhisperMessage|decryptWithSessions|' +
  'privatekey|pubkey|remoteid|remoteidentitykey|' +
  'pendingprekey|signeykeyid|basekey',
  'i'
);

// ── Level 1: intercept raw process.stdout.write + process.stderr.write ────────
// This is the definitive catch — works even when Baileys bypasses console.*
const _stdoutWrite = process.stdout.write.bind(process.stdout);
const _stderrWrite = process.stderr.write.bind(process.stderr);

process.stdout.write = function(chunk, encoding, callback) {
  try {
    const str = typeof chunk === 'string' ? chunk : (chunk?.toString?.() || '');
    if (SUPPRESS_RE.test(str)) {
      if (typeof encoding === 'function') encoding();
      else if (typeof callback === 'function') callback();
      return true;
    }
  } catch (_) {}
  return _stdoutWrite.apply(process.stdout, arguments);
};

process.stderr.write = function(chunk, encoding, callback) {
  try {
    const str = typeof chunk === 'string' ? chunk : (chunk?.toString?.() || '');
    if (SUPPRESS_RE.test(str)) {
      if (typeof encoding === 'function') encoding();
      else if (typeof callback === 'function') callback();
      return true;
    }
  } catch (_) {}
  return _stderrWrite.apply(process.stderr, arguments);
};

// ── Level 2: also patch console.* for completeness ────────────────────────────
function shouldSuppress(...args) {
  try {
    const msg = args.map(a => {
      if (typeof a === 'string') return a;
      try { return JSON.stringify(a); } catch (_) { return String(a); }
    }).join(' ');
    return SUPPRESS_RE.test(msg);
  } catch (_) { return false; }
}

const _log   = console.log.bind(console);
const _error = console.error.bind(console);
const _warn  = console.warn.bind(console);

console.log   = (...a) => { if (!shouldSuppress(...a)) _log(...a);   };
console.error = (...a) => { if (!shouldSuppress(...a)) _error(...a); };
console.warn  = (...a) => { if (!shouldSuppress(...a)) _warn(...a);  };

// ── Startup message ───────────────────────────────────────────────────────────
const config   = require('./config');
const ownerStr = Array.isArray(config.ownerName) ? config.ownerName.join(', ') : config.ownerName;

_log('🚀 Starting WhatsApp MD Bot Panel...\n');
_log(`📦 Bot Name: ${config.botName}`);
_log(`⚡ Prefix: ${config.prefix}`);
_log(`👑 Owner: ${ownerStr}\n`);

// ── Cleanup & temp ────────────────────────────────────────────────────────────
const { startCleanup }         = require('./utils/cleanup');
const { start: startKeepAlive } = require('./utils/keepAlive');

startCleanup();

// ── Periodic GC (--expose-gc passed by startup.js) ───────────────────────────
if (typeof global.gc === 'function') {
  const gcTimer = setInterval(() => {
    try { global.gc(); } catch (_) {}
  }, 10 * 60 * 1000); // every 10 min
  gcTimer.unref?.();
}

// ── Remove stale Puppeteer cache that some dep may have downloaded ────────────
(function cleanPuppeteerCache() {
  try {
    const os   = require('os');
    const fs   = require('fs');
    const path = require('path');
    const dir  = path.join(os.homedir(), '.cache', 'puppeteer');
    if (fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
      _log('🧹 Removed stale Puppeteer cache');
    }
  } catch (_) {}
})();

// ── Global crash guards ───────────────────────────────────────────────────────
const { cleanupOldFiles } = require('./utils/cleanup');

process.on('uncaughtException', (err) => {
  if (err.code === 'ENOSPC' || err.message?.includes('no space left')) {
    _error('⚠️ ENOSPC: disk full — running emergency cleanup...');
    cleanupOldFiles();
    return; // don't crash
  }
  if (err.code === 'EADDRINUSE') {
    // Panel/server.js handles EADDRINUSE with built-in retry — no need to crash
    _warn('⚠️ EADDRINUSE caught — panel server retrying automatically...');
    return;
  }
  _error('💥 Uncaught Exception:', err?.message || err);
  // Don't exit for other errors — watchdog handles truly fatal ones
});

process.on('unhandledRejection', (reason) => {
  if (!reason) return;
  const msg = reason?.message || String(reason);
  if (msg.includes('rate-overlimit')) return; // suppress common WA noise
  if (reason?.code === 'ENOSPC' || msg.includes('no space left')) {
    _warn('⚠️ ENOSPC in promise — running emergency cleanup...');
    cleanupOldFiles();
    return;
  }
  _error('💥 Unhandled Rejection:', msg);
});

// Graceful shutdown — tell watchdog to stop (exit 0 = no restart)
process.on('SIGTERM', () => {
  _log('🛑 SIGTERM received — shutting down cleanly...');
  setTimeout(() => process.exit(0), 3000);
});

process.on('SIGINT', () => {
  _log('🛑 SIGINT received — shutting down...');
  setTimeout(() => process.exit(0), 2000);
});

// ── Start the web panel ───────────────────────────────────────────────────────
const { startPanelServer, startKeepAlive: startPanelKeepAlive } = require('./Panel/server');
startPanelServer();
// self-ping every 4 min — prevents sleep, ensures 24/7 uptime
setTimeout(() => startPanelKeepAlive(), 5000);

// ── Bootstrap Session 1 from SESSION_ID env var (if no sessions yet) ─────────
const sessionManager = require('./Panel/sessionManager');

if (config.sessionID && config.sessionID.startsWith('MrMuneebAliBot!')) {
  const existing = sessionManager.getSessions();
  if (existing.length === 0) {
    try {
      _log('📡 SESSION_ID detected — bootstrapping Session 1...');
      const session = sessionManager.createSession('Session 1', config.ownerNumber[0]);
      const [, b64data] = config.sessionID.split('!');
      if (b64data) {
        const zlib = require('zlib');
        const fs   = require('fs');
        const path = require('path');
        const compressedData   = Buffer.from(b64data.replace('...', ''), 'base64');
        const decompressedData = zlib.gunzipSync(compressedData);
        fs.writeFileSync(path.join(session.sessionPath, 'creds.json'), decompressedData, 'utf8');
        _log('✅ Session credentials restored from SESSION_ID');
      }
    } catch (e) {
      _error('⚠️ Error bootstrapping session from SESSION_ID:', e.message);
    }
  }
}

// Export store placeholder (some commands import this — kept for compatibility)
module.exports = { store: { messages: new Map(), loadMessage: async () => null } };
