/**
 * API Integration Utilities — Multi-source with full fallback support
 *
 * Speed improvements:
 *  • api default timeout: 12 s (was 30 s)
 *  • AXIOS_LONG timeout:  20 s (was 60 s)
 *  • tryRequest attempts:  1   (no per-source retries; withRace handles recovery)
 *  • TikTok source timeouts: 12 s (was 20 s)
 */

'use strict';

const axios = require('axios');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const api = axios.create({
  timeout: 12_000,   // was 30 000
  headers: { 'User-Agent': UA },
});

// Shared config for media/download endpoints
const AXIOS_LONG = {
  timeout: 45_000,   // raised from 20 s — gives slow APIs time to respond
  headers: { 'User-Agent': UA, Accept: 'application/json, */*' },
};

// One attempt only — the caller (withRace / withFallback) handles recovery
async function tryRequest(getter, attempts = 1) {
  let lastError;
  for (let i = 1; i <= attempts; i++) {
    try { return await getter(); }
    catch (err) {
      lastError = err;
      if (i < attempts) await new Promise(r => setTimeout(r, 800 * i));
    }
  }
  throw lastError;
}

// ──────────────────────────────────────────────────────────────────────────────
const APIs = {

  // ── General ──────────────────────────────────────────────────────────────────

  generateImage: async (prompt) => {
    const r = await api.get('https://api.siputzx.my.id/api/ai/stablediffusion', { params: { prompt } });
    return r.data;
  },

  chatAI: async (text) => {
    const r = await api.get(`https://api.shizo.top/ai/gpt?apikey=shizo&query=${encodeURIComponent(text)}`);
    if (r.data?.msg) return { msg: r.data.msg };
    return r.data;
  },

  igDownload: async (url) => {
    const r = await api.get('https://api.siputzx.my.id/api/d/igdl', { params: { url } });
    return r.data;
  },

  translate: async (text, to = 'en') => {
    const r = await api.get('https://api.siputzx.my.id/api/tools/translate', { params: { text, to } });
    return r.data;
  },

  getMeme: async () => {
    const r = await api.get('https://meme-api.com/gimme');
    return r.data;
  },

  getQuote: async () => {
    const r = await api.get('https://api.quotable.io/random');
    return r.data;
  },

  getJoke: async () => {
    const r = await api.get('https://official-joke-api.appspot.com/random_joke');
    return r.data;
  },

  getWeather: async (city) => {
    const r = await api.get('https://api.siputzx.my.id/api/tools/weather', { params: { city } });
    return r.data;
  },

  shortenUrl: async (url) => {
    const r = await api.get('https://tinyurl.com/api-create.php', { params: { url } });
    return r.data;
  },

  wikiSearch: async (query) => {
    const r = await api.get(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(query)}`);
    return r.data;
  },

  screenshotWebsite: async (url) => {
    const apiUrl = `https://eliteprotech-apis.zone.id/ssweb?url=${encodeURIComponent(url)}`;
    const r = await axios.get(apiUrl, { timeout: 20_000, responseType: 'arraybuffer', headers: { 'User-Agent': UA } });
    if (r.headers['content-type']?.includes('image')) return Buffer.from(r.data);
    try {
      const d = JSON.parse(Buffer.from(r.data).toString());
      return d.url || d.data?.url || d.image || apiUrl;
    } catch { return Buffer.from(r.data); }
  },

  textToSpeech: async (text) => {
    const apiUrl = `https://www.laurine.site/api/tts/tts-nova?text=${encodeURIComponent(text)}`;
    const r = await axios.get(apiUrl, { timeout: 15_000, headers: { 'User-Agent': UA } });
    const d = r.data;
    if (typeof d === 'string' && d.startsWith('http')) return d;
    if (d?.data?.URL) return d.data.URL;
    if (d?.data?.url) return d.data.url;
    if (d?.URL) return d.URL;
    if (d?.url) return d.url;
    throw new Error('Invalid TTS response');
  },

  // ── Song (MP3) download APIs ──────────────────────────────────────────────────

  getIzumiDownloadByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://izumiiiiiiii.dpdns.org/downloader/youtube?url=${encodeURIComponent(youtubeUrl)}&format=mp3`,
      AXIOS_LONG
    ));
    if (res?.data?.result?.download) return res.data.result;
    throw new Error('Izumi: no download');
  },

  getIzumiDownloadByQuery: async (query) => {
    const res = await tryRequest(() => axios.get(
      `https://izumiiiiiiii.dpdns.org/downloader/youtube-play?query=${encodeURIComponent(query)}`,
      AXIOS_LONG
    ));
    if (res?.data?.result?.download) return res.data.result;
    throw new Error('Izumi query: no download');
  },

  getYupraDownloadByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://api.yupra.my.id/api/downloader/ytmp3?url=${encodeURIComponent(youtubeUrl)}`,
      AXIOS_LONG
    ));
    if (res?.data?.success && res?.data?.data?.download_url) {
      return { download: res.data.data.download_url, title: res.data.data.title, thumbnail: res.data.data.thumbnail };
    }
    throw new Error('Yupra mp3: no download');
  },

  getOkatsuDownloadByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://okatsu-rolezapiiz.vercel.app/downloader/ytmp3?url=${encodeURIComponent(youtubeUrl)}`,
      AXIOS_LONG
    ));
    if (res?.data?.dl) return { download: res.data.dl, title: res.data.title, thumbnail: res.data.thumb };
    throw new Error('Okatsu mp3: no download');
  },

  getEliteProTechDownloadByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://eliteprotech-apis.zone.id/ytdown?url=${encodeURIComponent(youtubeUrl)}&format=mp3`,
      AXIOS_LONG
    ));
    if (res?.data?.success && res?.data?.downloadURL) return { download: res.data.downloadURL, title: res.data.title };
    throw new Error('Elite mp3: no download');
  },

  // ── YouTube VIDEO download APIs ───────────────────────────────────────────────

  getEliteProTechVideoByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://eliteprotech-apis.zone.id/ytdown?url=${encodeURIComponent(youtubeUrl)}&format=mp4`,
      AXIOS_LONG
    ));
    if (res?.data?.success && res?.data?.downloadURL) return { download: res.data.downloadURL, title: res.data.title };
    throw new Error('Elite video: no download');
  },

  getYupraVideoByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://api.yupra.my.id/api/downloader/ytmp4?url=${encodeURIComponent(youtubeUrl)}`,
      AXIOS_LONG
    ));
    if (res?.data?.success && res?.data?.data?.download_url) {
      return { download: res.data.data.download_url, title: res.data.data.title, thumbnail: res.data.data.thumbnail };
    }
    throw new Error('Yupra video: no download');
  },

  getOkatsuVideoByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://okatsu-rolezapiiz.vercel.app/downloader/ytmp4?url=${encodeURIComponent(youtubeUrl)}`,
      AXIOS_LONG
    ));
    if (res?.data?.result?.mp4) return { download: res.data.result.mp4, title: res.data.result.title };
    throw new Error('Okatsu video: no mp4');
  },

  getIzumiVideoByUrl: async (youtubeUrl) => {
    const res = await tryRequest(() => axios.get(
      `https://izumiiiiiiii.dpdns.org/downloader/youtube?url=${encodeURIComponent(youtubeUrl)}&format=mp4`,
      AXIOS_LONG
    ));
    if (res?.data?.result?.download) return { download: res.data.result.download, title: res.data.result.title };
    throw new Error('Izumi video: no download');
  },

  getCobaltVideoByUrl: async (youtubeUrl) => {
    // cobalt.tools now requires JWT auth — always throws so callers skip it
    throw new Error('Cobalt: JWT auth required (API no longer free)');
  },

  getYtdlVideoByUrl: async (_youtubeUrl) => {
    // ytdl-core v4.11.5 is BROKEN ("Could not extract functions") — disabled
    throw new Error('ytdl-core: broken (YouTube site update) — use yt-dlp instead');
  },

  // ── Facebook download sources — returns array of async fns ──────────────────
  // Each fn returns { videoUrl, title }
  // Sources tried sequentially via withFallback in facebook.js
  //
  // SOURCE PRIORITY (from testing on Replit vs VPS):
  //   1. v3.fdownloader.net       — CONFIRMED reachable from Replit (200 OK, JSON response)
  //   2. yt-dlp + cookies         — works anywhere when fb_cookies.txt is set
  //   3. yt-dlp without cookies   — works for public Reels / public page videos
  //   4. mbasic.facebook.com      — HTML scraper, no auth, works for embed-enabled public videos
  //   5. snapsave.app             — works from VPS / residential IP (Cloudflare 522 on Replit)
  //   6. fdown.net                — works from VPS (403 on Replit)
  //   7. getfvid.com              — works from VPS (CF 522 on Replit)
  //   8. sssinstagram.com         — works from VPS (404 endpoint on Replit)

  getFacebookSources: (url) => {
    const hdrs = (origin) => ({
      'User-Agent'      : UA,
      'Accept'          : 'text/html,application/xhtml+xml,*/*;q=0.8',
      'Accept-Language' : 'en-US,en;q=0.9',
      'Content-Type'    : 'application/x-www-form-urlencoded',
      'X-Requested-With': 'XMLHttpRequest',
      'Origin'          : origin,
      'Referer'         : origin + '/',
      'Sec-Fetch-Site'  : 'same-origin',
      'Sec-Fetch-Mode'  : 'cors',
    });

    return [

      // Source 1: v3.fdownloader.net — CONFIRMED working from Replit for public videos
      //
      // Successful response shape (v="v1"):
      //   { status:"ok", p:"facebook", v:"v1", live:false, data:"<HTML with download hrefs>" }
      // The data HTML contains:
      //   href="https://dl.snapcdn.app/download?token=JWT"  ← signed proxy URL → FB CDN mp4
      //   href="#note_convert"                              ← skip this
      //
      // Failure response shape (video private / login required):
      //   { status:"ok", p:"facebook", mess:"Error: Video is private...", url:"..." }
      //
      // Alternate success shape (links array — seen on some regions):
      //   { status:"ok", p:"facebook", links:[{url, quality}] }
      async () => {
        const res = await axios.post(
          'https://v3.fdownloader.net/api/ajaxSearch',
          `q=${encodeURIComponent(url)}&lang=en`,
          { timeout: 45_000, headers: hdrs('https://fdownloader.net') }
        );
        const d = res.data;
        if (!d || d.status !== 'ok') throw new Error('v3.fdownloader: bad status');

        // Shape A (most common): structured links array
        if (Array.isArray(d.links) && d.links.length > 0) {
          const hd   = d.links.find(l => /hd/i.test(l.quality || ''));
          const sd   = d.links.find(l => /sd/i.test(l.quality || ''));
          const best = hd || sd || d.links[0];
          const raw  = best?.url?.replace(/&amp;/g, '&');
          if (raw) return { videoUrl: raw, title: d.title || 'Facebook Video', quality: hd ? 'HD' : 'SD' };
        }

        // Shape B (v1 response): download links embedded in the "data" HTML field
        // Picks out dl.snapcdn.app proxy links (JWT-signed, expire in ~1h)
        // Order: first real href = HD 720p, second real href = SD 360p
        const dataHtml = typeof d.data === 'string' ? d.data : '';
        if (dataHtml) {
          // Extract all href values that are real download URLs (not anchors / ads)
          const hrefRe = /href=["'](https?:\/\/[^"']+)["']/gi;
          const allHrefs = [];
          let m;
          while ((m = hrefRe.exec(dataHtml)) !== null) allHrefs.push(m[1]);

          // Prefer dl.snapcdn.app proxy links (most reliable, pre-signed)
          const snapLinks = allHrefs.filter(h => h.startsWith('https://dl.snapcdn.app/'));
          if (snapLinks.length > 0) {
            return {
              videoUrl : snapLinks[0],          // [0] = HD
              sdUrl    : snapLinks[1] || null,  // [1] = SD (if available)
              title    : 'Facebook Video',
              quality  : 'HD',
            };
          }

          // Fallback: direct fbcdn.net mp4 URL embedded in data HTML
          const fbcdnMp4 = allHrefs.find(h => /fbcdn\.net/.test(h) && /\.mp4/.test(h));
          const anyMp4   = allHrefs.find(h => /\.mp4/.test(h));
          const raw      = fbcdnMp4 || anyMp4;
          if (raw) return { videoUrl: raw, title: 'Facebook Video' };
        }

        // Shape C: links embedded in the "mess" HTML field
        const mess = typeof d.mess === 'string' ? d.mess : '';
        if (mess) {
          const hd  = mess.match(/href=["']([^"']+)["'][^>]*>(?:[^<]*\s)?HD/i);
          const sd  = mess.match(/href=["']([^"']+)["'][^>]*>(?:[^<]*\s)?SD/i);
          const any = mess.match(/href=["'](https?:\/\/[^"']*(?:\.mp4|fbcdn)[^"']*)["']/i);
          const raw = (hd?.[1] || sd?.[1] || any?.[1])?.replace(/&amp;/g, '&');
          if (raw) return { videoUrl: raw, title: 'Facebook Video', quality: hd ? 'HD' : 'SD' };
          if (/private/i.test(mess)) throw new Error('v3.fdownloader: video is private or login required');
        }

        throw new Error('v3.fdownloader: no video URL in any response field');
      },

      // Source 2: yt-dlp with Facebook cookies — works from ANY server when cookies set
      // Owner sets cookies once via .setfbcookies command; then this always works
      async () => {
        const fs   = require('fs');
        const path = require('path');
        const ytdlp = require('./ytdlp');
        const { spawn } = require('child_process');
        const cookiesFile = path.join(__dirname, '..', 'config', 'fb_cookies.txt');

        if (!fs.existsSync(cookiesFile)) {
          throw new Error('yt-dlp: no fb_cookies.txt — set cookies with .setfbcookies');
        }

        return new Promise((resolve, reject) => {
          const args = [
            '--no-playlist', '--no-check-certificates', '--geo-bypass',
            '--no-warnings', '--no-simulate',
            '-f', 'best[ext=mp4]/best',
            '--print', 'url',
            '--cookies', cookiesFile,
            '--', url,
          ];
          if (ytdlp.FFMPEG_PATH) args.unshift('--ffmpeg-location', ytdlp.FFMPEG_PATH);

          const proc = spawn(ytdlp.YTDLP_PATH, args, { stdio: ['ignore', 'pipe', 'pipe'] });
          let out = '', err = '';
          proc.stdout.on('data', chunk => { out += chunk.toString(); });
          proc.stderr.on('data', chunk => { err += chunk.toString(); });
          const timer = setTimeout(() => { proc.kill('SIGKILL'); reject(new Error('yt-dlp FB timeout')); }, 60_000);
          proc.on('close', code => {
            clearTimeout(timer);
            if (code !== 0) return reject(new Error(err.slice(0, 200) || `yt-dlp exit ${code}`));
            const videoUrl = out.trim().split('\n').filter(Boolean)[0];
            if (!videoUrl) return reject(new Error('yt-dlp: no URL returned'));
            resolve({ videoUrl, title: 'Facebook Video' });
          });
          proc.on('error', e => { clearTimeout(timer); reject(e); });
        });
      },

      // Source 3: yt-dlp WITHOUT cookies — works for truly public FB videos / Reels
      // No cookie file required. Fast. Fails silently on login-walled content.
      async () => {
        const ytdlp  = require('./ytdlp');
        const { spawn } = require('child_process');
        return new Promise((resolve, reject) => {
          const args = [
            '--no-playlist', '--no-check-certificates', '--geo-bypass',
            '--no-warnings', '--no-simulate',
            '-f', 'best[ext=mp4]/best',
            '--print', 'url',
            '--', url,
          ];
          if (ytdlp.FFMPEG_PATH) args.unshift('--ffmpeg-location', ytdlp.FFMPEG_PATH);
          const proc = spawn(ytdlp.YTDLP_PATH, args, { stdio: ['ignore', 'pipe', 'pipe'] });
          let out = '', err = '';
          proc.stdout.on('data', c => { out += c.toString(); });
          proc.stderr.on('data', c => { err += c.toString(); });
          const timer = setTimeout(() => { proc.kill('SIGKILL'); reject(new Error('yt-dlp (no cookies) FB timeout')); }, 45_000);
          proc.on('close', code => {
            clearTimeout(timer);
            if (code !== 0) return reject(new Error(err.slice(0, 200) || `yt-dlp exit ${code}`));
            const videoUrl = out.trim().split('\n').filter(Boolean)[0];
            if (!videoUrl || !videoUrl.startsWith('http')) return reject(new Error('yt-dlp: no URL'));
            resolve({ videoUrl, title: 'Facebook Video' });
          });
          proc.on('error', e => { clearTimeout(timer); reject(e); });
        });
      },

      // Source 4: mbasic.facebook.com HTML scraper — no auth, no API
      // mbasic is a lightweight text-only version of Facebook that sometimes
      // embeds hd_src / sd_src JSON keys directly in the page HTML.
      async () => {
        // Normalise any fb.watch / m.facebook.com URL → mbasic.facebook.com
        const mbasicUrl = url
          .replace(/^https?:\/\/(?:www\.|m\.|web\.)?facebook\.com/, 'https://mbasic.facebook.com')
          .replace(/^https?:\/\/(?:www\.)?fb\.com/, 'https://mbasic.facebook.com')
          .replace(/^https?:\/\/fb\.watch/, 'https://mbasic.facebook.com/watch');

        const res = await axios.get(mbasicUrl, {
          timeout     : 15_000,
          maxRedirects: 6,
          headers     : {
            'User-Agent'     : 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept'         : 'text/html,*/*',
          },
        });
        const html = typeof res.data === 'string' ? res.data : '';
        if (!html) throw new Error('mbasic: empty page');

        // Pattern A: JSON property "hd_src" / "sd_src" embedded in page scripts
        const decode = (s) => (s || '').replace(/\\u0026/g, '&').replace(/\\u003C/g, '<').replace(/\\/g, '');
        const hdM = html.match(/"hd_src"\s*:\s*"([^"]+)"/);
        const sdM = html.match(/"sd_src"\s*:\s*"([^"]+)"/);
        // Pattern B: browser_native_hd_url / browser_native_sd_url
        const hdM2 = html.match(/"browser_native_hd_url"\s*:\s*"([^"]+)"/);
        const sdM2 = html.match(/"browser_native_sd_url"\s*:\s*"([^"]+)"/);
        // Pattern C: <source src="..."> in HTML5 video tags
        const srcM = html.match(/<source[^>]+src=["']([^"']+\.mp4[^"']*)["']/i);

        const raw = decode(hdM?.[1] || hdM2?.[1] || sdM?.[1] || sdM2?.[1] || srcM?.[1] || '');
        if (!raw || !raw.startsWith('http')) throw new Error('mbasic scraper: no video URL found');
        return {
          videoUrl: raw,
          title   : html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() || 'Facebook Video',
          quality : (hdM || hdM2) ? 'HD' : 'SD',
        };
      },

      // Source 5: snapsave.app — works from VPS / residential IP
      async () => {
        const res = await axios.post(
          'https://snapsave.app/api/ajaxSearch',
          `q=${encodeURIComponent(url)}&lang=en`,
          { timeout: 45_000, headers: hdrs('https://snapsave.app') }
        );
        const html = res.data?.data || (typeof res.data === 'string' ? res.data : '');
        if (!html) throw new Error('snapsave: empty response');
        const hd  = html.match(/href=["']([^"']+)["'][^>]*>\s*(?:Download\s*)?HD/i);
        const sd  = html.match(/href=["']([^"']+)["'][^>]*>\s*(?:Download\s*)?SD/i);
        const any = html.match(/href=["'](https?:\/\/[^"']*\.mp4[^"']*)["']/i);
        const raw = (hd?.[1] || sd?.[1] || any?.[1])?.replace(/&amp;/g, '&');
        if (!raw) throw new Error('snapsave: no video URL in response');
        const title = html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() || 'Facebook Video';
        return { videoUrl: raw, title, quality: hd ? 'HD' : 'SD' };
      },

      // Source 6: fdown.net — works from VPS
      async () => {
        const res = await axios.post(
          'https://fdown.net/',
          `q=${encodeURIComponent(url)}`,
          { timeout: 45_000, headers: hdrs('https://fdown.net'), maxRedirects: 5 }
        );
        const html = typeof res.data === 'string' ? res.data : '';
        const hd   = html.match(/href=["'](https?:\/\/[^"']+)["'][^>]*>Download HD/i);
        const sd   = html.match(/href=["'](https?:\/\/[^"']+)["'][^>]*>Download SD/i);
        const raw  = (hd?.[1] || sd?.[1])?.replace(/&amp;/g, '&');
        if (!raw) throw new Error('fdown: no video link');
        return { videoUrl: raw, title: 'Facebook Video', quality: hd ? 'HD' : 'SD' };
      },

      // Source 7: getfvid.com — works from VPS
      async () => {
        const res = await axios.post(
          'https://www.getfvid.com/downloader',
          `url=${encodeURIComponent(url)}`,
          { timeout: 45_000, headers: hdrs('https://www.getfvid.com'), maxRedirects: 5 }
        );
        const html = typeof res.data === 'string' ? res.data : '';
        const hd   = html.match(/href=["'](https?:\/\/[^"']+)["'][^>]*>[^<]*HD/i);
        const sd   = html.match(/href=["'](https?:\/\/[^"']+)["'][^>]*>[^<]*SD/i);
        const raw  = (hd?.[1] || sd?.[1])?.replace(/&amp;/g, '&');
        if (!raw) throw new Error('getfvid: no video link');
        return { videoUrl: raw, title: 'Facebook Video', quality: hd ? 'HD' : 'SD' };
      },

      // Source 8: sssinstagram.com (handles FB too) — works from VPS
      async () => {
        const res = await axios.post(
          'https://sssinstagram.com/api/ajaxSearch',
          `q=${encodeURIComponent(url)}&lang=en`,
          { timeout: 45_000, headers: hdrs('https://sssinstagram.com') }
        );
        const html = res.data?.data || (typeof res.data === 'string' ? res.data : '');
        const m    = html.match(/href=["'](https?:\/\/[^"']*(?:\.mp4|fbcdn|facebook\.com\/video)[^"']*)["']/i);
        if (!m?.[1]) throw new Error('sssinstagram: no URL');
        return { videoUrl: m[1].replace(/&amp;/g, '&'), title: 'Facebook Video' };
      },

    ];
  },

  // ── Facebook comments — scrapes mbasic.facebook.com (no auth needed for public)
  // Returns { comments: [{author, text, likes}], postTitle }
  // Works for public posts/videos. Returns empty array for private content.
  getFacebookComments: async (url) => {
    // Convert any FB URL → mbasic.facebook.com equivalent
    let mbasicUrl = url
      .replace(/^https?:\/\/(?:www\.|m\.|web\.)?facebook\.com/, 'https://mbasic.facebook.com')
      .replace(/^https?:\/\/(?:www\.)?fb\.com/, 'https://mbasic.facebook.com')
      .replace(/^https?:\/\/fb\.watch/, 'https://mbasic.facebook.com/watch');

    // For video URLs, append ?_rdr to force redirect to post page
    if (!mbasicUrl.includes('?')) mbasicUrl += '?_rdr=1';

    const res = await axios.get(mbasicUrl, {
      timeout     : 15_000,
      maxRedirects: 6,
      headers     : {
        'User-Agent'     : 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept'         : 'text/html,*/*',
      },
    });

    const html = typeof res.data === 'string' ? res.data : '';
    if (!html) throw new Error('Empty page from mbasic');

    // Check for login redirect (private or login-required)
    if (/login\?|login\.php|You must log in/i.test(html) && !/<div[^>]+id=["']?comment/i.test(html)) {
      return { comments: [], postTitle: '', private: true };
    }

    // Extract post title
    const postTitle = (
      html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() ||
      html.match(/<h3[^>]*>([^<]+)<\/h3>/i)?.[1]?.trim() ||
      ''
    ).replace(/\s*[-|].*$/, '').trim();

    const comments = [];

    // Strategy A: mbasic comment blocks
    // Pattern: <div ...><h3><a ...>NAME</a></h3>...<div ...>COMMENT TEXT</div>...</div>
    const commentBlockRe = /<div[^>]+class="[^"]*[bB][sS][0-9a-zA-Z]*[^"]*"[^>]*>([\s\S]*?)<\/div>\s*<\/div>/g;

    // Strategy B: simpler regex — scan for comment author + text pairs
    // mbasic renders: <a href="/...">Author Name</a> comment_text likes_count
    const authorRe = /<a\s+href="\/[^"?#]+(?:\?[^"]*)?"\s*(?:class="[^"]*")?>([^<]{2,80})<\/a>/g;

    // Strategy C: most reliable — find all <h3> tags (author names in mbasic)
    // followed by a <div> containing the comment text
    const blocks = html.split(/<div\s+id=["']?u[^"']*["']?/i);
    for (const block of blocks) {
      if (comments.length >= 10) break;
      // Author: <h3><a href="...">Name</a></h3>
      const authorM = block.match(/<h3[^>]*>\s*<a[^>]*>([^<]{2,80})<\/a>\s*<\/h3>/i);
      if (!authorM) continue;
      const author = authorM[1].trim();
      // Text: next <div> after the author block, strip HTML
      const textM = block.match(/<\/h3>\s*<div[^>]*>([\s\S]{1,500}?)<\/div>/i);
      if (!textM) continue;
      const text = textM[1]
        .replace(/<[^>]+>/g, '')   // strip HTML tags
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#\d+;/g, '')
        .replace(/\s+/g, ' ')
        .trim();
      // Skip non-comment blocks (too short or looks like UI chrome)
      if (!text || text.length < 2 || /^(Like|Reply|See more|View|Share|\d+)$/i.test(text)) continue;

      // Likes: look for "X Likes" near the end of the block
      const likesM = block.match(/(\d+)\s*(?:Likes?|👍)/i);
      const likes = likesM ? parseInt(likesM[1], 10) : null;

      comments.push({ author, text: text.slice(0, 300), likes });
    }

    return { comments, postTitle, private: false };
  },

  // ── TikTok download sources — returns array of async fns ─────────────────────

  getTikTokSources: (url) => [

    // Source 1: tikwm.com — most reliable, HD support
    async () => {
      const res = await axios.get('https://www.tikwm.com/api/', {
        params:  { url, hd: 1 },
        timeout: 12_000,
        headers: { 'User-Agent': UA },
      });
      const d = res.data?.data;
      if (!d) throw new Error('tikwm: no data');
      const videoUrl = d.hdplay || d.play || d.wmplay;
      if (!videoUrl) throw new Error('tikwm: no video url');
      return { videoUrl, title: d.title || 'TikTok Video' };
    },

    // Source 2: tiklydown.eu.org
    async () => {
      const res = await axios.get('https://api.tiklydown.eu.org/api/download', {
        params:  { url },
        timeout: 12_000,
        headers: { 'User-Agent': UA },
      });
      const d = res.data;
      const videoUrl = d?.Video?.nwm || d?.Video?.watermark || d?.video;
      if (!videoUrl) throw new Error('tiklydown: no url');
      return { videoUrl, title: d?.title || 'TikTok Video' };
    },

    // Source 3: siputzx
    async () => {
      const res = await axios.get('https://api.siputzx.my.id/api/d/tiktok', {
        params:  { url },
        timeout: 12_000,
        headers: { 'User-Agent': UA },
      });
      const d = res.data?.data;
      const videoUrl = d?.urls?.[0] || d?.video_url || d?.url || d?.download_url;
      if (!videoUrl) throw new Error('siputzx: no url');
      return { videoUrl, title: d?.metadata?.title || 'TikTok Video' };
    },

    // Source 4: @bochilteam/scraper-tiktok (installed package)
    async () => {
      const { ttdown } = require('@bochilteam/scraper-tiktok');
      const d = await ttdown(url);
      const videoUrl = d?.videoUrl || d?.video || d?.play;
      if (!videoUrl) throw new Error('bochil: no url');
      return { videoUrl, title: d?.title || 'TikTok Video' };
    },

    // Source 5: yupra
    async () => {
      const res = await axios.get('https://api.yupra.my.id/api/downloader/tiktok', {
        params:  { url },
        timeout: 12_000,
        headers: { 'User-Agent': UA },
      });
      const d = res.data?.data || res.data;
      const videoUrl = d?.play || d?.download_url || d?.video || d?.url;
      if (!videoUrl) throw new Error('yupra tiktok: no url');
      return { videoUrl, title: d?.title || 'TikTok Video' };
    },

    // Source 6: okatsu
    async () => {
      const res = await axios.get('https://okatsu-rolezapiiz.vercel.app/downloader/tiktok', {
        params:  { url },
        timeout: 12_000,
        headers: { 'User-Agent': UA },
      });
      const d = res.data?.result || res.data;
      const videoUrl = d?.nowm || d?.video || d?.play || d?.download;
      if (!videoUrl) throw new Error('okatsu tiktok: no url');
      return { videoUrl, title: d?.title || 'TikTok Video' };
    },

    // Source 7: eliteprotech
    async () => {
      const res = await axios.get('https://eliteprotech-apis.zone.id/ttdl', {
        params:  { url },
        timeout: 12_000,
        headers: { 'User-Agent': UA },
      });
      const d = res.data;
      const videoUrl = d?.downloadURL || d?.url || d?.video;
      if (!videoUrl) throw new Error('elite tiktok: no url');
      return { videoUrl, title: d?.title || 'TikTok Video' };
    },

  ],

};

module.exports = APIs;
