'use strict';

/**
 * Strict Owner Guard — Full Security Control System
 *
 * Layer 1 — Admin role protection (promote/demote events):
 *   • Monitors all promote/demote events
 *   • Only the designated group owner (+ global bot owner) may change admin roles
 *   • Instantly reverses any unauthorized role changes
 *   • Punishes offenders: demote on 1st offense, remove on 2nd+
 *   • Anti-loop: tracks bot-initiated actions to prevent re-trigger
 *
 * Layer 2 — Message-level security (called from handleMessage in handler.js):
 *   • Anti-spam     : per-group per-user message rate limit (12 msgs / 15 s)
 *   • Command abuse : per-group per-user command rate limit (7 cmds / 20 s)
 *   • Repeat abuse  : same command ≥ 4 times → remove
 *   • Mass URL spam : ≥ 4 URLs in one message → remove
 *   • Mention flood : ≥ 8 @mentions in one message → remove
 *   • Admins and bot owner ALWAYS bypassed
 *
 * Performance:
 *   • checkStrictGuardMessage() is 100% synchronous — zero I/O, zero awaits
 *   • Config read from in-memory cache (30 s TTL) — no JSON on every message
 *   • All Maps are bounded — no unbounded memory growth
 *
 * State: persisted in data/strictGuard.json (survives restarts)
 */

const fs   = require('fs');
const path = require('path');

// ── Data file ─────────────────────────────────────────────────────────────────
const DATA_FILE = path.join(__dirname, '..', 'data', 'strictGuard.json');

// ── Global bot owner (hard-locked) ────────────────────────────────────────────
const GLOBAL_OWNER = '923196615238';

// ─────────────────────────────────────────────────────────────────────────────
// Config cache — avoids JSON reads on every message
// Map<groupId, { cfg: object, ts: number }>
// ─────────────────────────────────────────────────────────────────────────────
const _cfgCache     = new Map();
const CFG_CACHE_TTL = 30_000;   // 30 s — short enough to catch fresh on/off toggles

// ─────────────────────────────────────────────────────────────────────────────
// Anti-loop tracker (Layer 1)
// key = `groupId:phone`  →  timestamp of last bot action
// ─────────────────────────────────────────────────────────────────────────────
const _botActions    = new Map();
const BOT_ACTION_TTL = 20_000;   // 20 s

// ── KickAll / mass-remove detection tracker ───────────────────────────────────
// key = `groupId:actorPhone`  →  { count, windowStart }
const _removeTracker    = new Map();
const KICKALL_WINDOW_MS = 30_000;   // 30-second window
const KICKALL_THRESHOLD = 3;        // 3+ removes in window = KickAll attack

// ─────────────────────────────────────────────────────────────────────────────
// Per-group per-user message tracker (Layer 2)
// key = `groupId:senderPhone`
// value = {
//   msgCount, msgWindowStart,          ← total message rate
//   cmdCount, cmdWindowStart,          ← command rate
//   lastCmdText, cmdRepeat, cmdRepeatStart  ← repeated-command abuse
// }
// ─────────────────────────────────────────────────────────────────────────────
const _sgTracker     = new Map();
const MAX_TRACKER_SZ = 3000;

// ── Security thresholds ───────────────────────────────────────────────────────
const SG_MSG_WINDOW  = 15_000;   // 15 s window for message flood
const SG_MSG_MAX     = 12;       // max messages per window
const SG_CMD_WINDOW  = 20_000;   // 20 s window for command spam
const SG_CMD_MAX     = 7;        // max command messages per window
const SG_REPEAT_MAX  = 4;        // same command ≥ N times → abuse
const SG_URL_MAX     = 4;        // URLs per single message → spam
const SG_MENTION_MAX = 8;        // @mentions per single message → flood

// ── URL regex (safe — no catastrophic backtracking) ───────────────────────────
const URL_RE = /https?:\/\/[^\s]{4,}|(?:^|\s)(?:www\.|t\.me\/|bit\.ly\/|wa\.me\/)[^\s]{3,}/gi;

// ── Helpers ───────────────────────────────────────────────────────────────────
const getPhone = (jid) =>
  String(jid || '').split(':')[0].split('@')[0].replace(/[^0-9]/g, '');

const toSWNet = (jid) => {
  const num = getPhone(jid);
  return num ? `${num}@s.whatsapp.net` : null;
};

// ─────────────────────────────────────────────────────────────────────────────
// Persistent data I/O
// ─────────────────────────────────────────────────────────────────────────────
function readData() {
  try {
    if (fs.existsSync(DATA_FILE)) return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (_) {}
  return {};
}

function writeData(data) {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error('[StrictGuard] writeData error:', e.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Config cache helpers
// ─────────────────────────────────────────────────────────────────────────────
function _readCachedConfig(groupId) {
  const cached = _cfgCache.get(groupId);
  if (cached && Date.now() - cached.ts < CFG_CACHE_TTL) return cached.cfg;
  // Cache miss or expired → read from disk
  const data = readData();
  const cfg  = data[groupId] || { enabled: false, owner: null, offenses: {} };
  _cfgCache.set(groupId, { cfg, ts: Date.now() });
  return cfg;
}

function _invalidateCache(groupId) {
  _cfgCache.delete(groupId);
}

// ─────────────────────────────────────────────────────────────────────────────
// Public config API  (used by .strictguard and .setgowner command handlers)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Returns { enabled, owner, offenses } for a group.
 * Always reads fresh from disk so command handlers see current state.
 */
function getGuardConfig(groupId) {
  _invalidateCache(groupId);   // force fresh read
  const data = readData();
  return data[groupId] || { enabled: false, owner: null, offenses: {} };
}

function setGuardEnabled(groupId, enabled) {
  const data = readData();
  if (!data[groupId]) data[groupId] = { enabled: false, owner: null, offenses: {} };
  data[groupId].enabled = !!enabled;
  writeData(data);
  _invalidateCache(groupId);   // flush cache — handler picks up new state instantly
  // Also reset all per-user trackers for this group when toggling
  for (const key of _sgTracker.keys()) {
    if (key.startsWith(groupId + ':')) _sgTracker.delete(key);
  }
  console.log(`[StrictGuard] ${groupId.split('@')[0]}: guard ${enabled ? 'ENABLED 🟢' : 'DISABLED 🔴'}`);
}

/**
 * @param {string} groupId   - group JID
 * @param {string} ownerJid  - participant JID of the designated group owner
 */
function setGroupOwner(groupId, ownerJid) {
  const data = readData();
  if (!data[groupId]) data[groupId] = { enabled: false, owner: null, offenses: {} };
  data[groupId].owner = getPhone(ownerJid);
  writeData(data);
  _invalidateCache(groupId);
}

// ─────────────────────────────────────────────────────────────────────────────
// Anti-loop helpers (Layer 1)
// ─────────────────────────────────────────────────────────────────────────────
function markBotAction(groupId, jid) {
  const key = `${groupId}:${getPhone(jid)}`;
  _botActions.set(key, Date.now());
  if (_botActions.size > 500) {
    const cutoff = Date.now() - BOT_ACTION_TTL * 3;
    for (const [k, ts] of _botActions.entries()) {
      if (ts < cutoff) _botActions.delete(k);
    }
  }
}

function isBotAction(groupId, jid) {
  const key = `${groupId}:${getPhone(jid)}`;
  const ts  = _botActions.get(key);
  if (!ts) return false;
  if (Date.now() - ts < BOT_ACTION_TTL) return true;
  _botActions.delete(key);
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// Offense counter (Layer 1)
// ─────────────────────────────────────────────────────────────────────────────
function recordOffense(groupId, phone) {
  const data = readData();
  if (!data[groupId]) data[groupId] = { enabled: false, owner: null, offenses: {} };
  if (!data[groupId].offenses) data[groupId].offenses = {};
  data[groupId].offenses[phone] = (data[groupId].offenses[phone] || 0) + 1;
  writeData(data);
  _invalidateCache(groupId);
  return data[groupId].offenses[phone];
}

// ─────────────────────────────────────────────────────────────────────────────
// Layer 2 — Message-level security check
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Synchronous — zero I/O, zero awaits. Safe to call on EVERY group message.
 * Uses config cache (30 s TTL) and in-memory per-user trackers.
 *
 * @param {string}  groupId       - group JID  (e.g. "12345@g.us")
 * @param {string}  senderJid     - sender JID
 * @param {string}  textBody      - raw message text (or '' for media-only)
 * @param {boolean} senderIsAdmin - true if sender is a group admin
 * @param {boolean} senderIsOwner - true if sender is the global bot owner
 * @returns {{ blocked: boolean, reason: string, action: 'warn'|'remove' }}
 */
function checkStrictGuardMessage(groupId, senderJid, textBody, senderIsAdmin, senderIsOwner) {
  try {
    // ── 1. Fast-exit: is strict guard enabled for this group? ─────────────────
    const cfg = _readCachedConfig(groupId);
    if (!cfg.enabled) return { blocked: false, reason: '', action: 'warn' };

    // ── 2. Admins and global bot owner are ALWAYS bypassed ────────────────────
    if (senderIsAdmin || senderIsOwner) {
      console.log(`[StrictGuard] BYPASS (${senderIsOwner ? 'owner' : 'admin'}): ${getPhone(senderJid)} in ${groupId.split('@')[0]}`);
      return { blocked: false, reason: '', action: 'warn' };
    }

    const now         = Date.now();
    const senderPhone = getPhone(senderJid);
    const trackerKey  = `${groupId}:${senderPhone}`;

    // ── 3. Prune tracker Map if too large (memory safety) ─────────────────────
    if (_sgTracker.size > MAX_TRACKER_SZ) {
      const cutoff = now - Math.max(SG_MSG_WINDOW, SG_CMD_WINDOW) * 2;
      for (const [k, v] of _sgTracker.entries()) {
        if (v.msgWindowStart < cutoff && v.cmdWindowStart < cutoff) _sgTracker.delete(k);
      }
    }

    // ── 4. Get/init tracker for this user in this group ───────────────────────
    const t = _sgTracker.get(trackerKey) || {
      msgCount: 0,     msgWindowStart: now,
      cmdCount: 0,     cmdWindowStart: now,
      lastCmdText: '', cmdRepeat: 0, cmdRepeatStart: now,
    };

    const text  = (textBody || '').trim();
    const isCmd = text.length > 0 && ['.', '/', '!', '#'].includes(text[0]);

    // ── 5. Total message rate limit ───────────────────────────────────────────
    if (now - t.msgWindowStart > SG_MSG_WINDOW) {
      t.msgCount = 1; t.msgWindowStart = now;
    } else {
      t.msgCount++;
    }
    if (t.msgCount > SG_MSG_MAX) {
      _sgTracker.set(trackerKey, t);
      const reason = `Message flood (${t.msgCount} msgs / ${SG_MSG_WINDOW / 1000}s — limit ${SG_MSG_MAX})`;
      console.log(`[StrictGuard] BLOCKED ${senderPhone} in ${groupId.split('@')[0]}: ${reason}`);
      return { blocked: true, reason, action: 'warn' };
    }

    // ── 6. Command rate limit ─────────────────────────────────────────────────
    if (isCmd) {
      if (now - t.cmdWindowStart > SG_CMD_WINDOW) {
        t.cmdCount = 1; t.cmdWindowStart = now;
      } else {
        t.cmdCount++;
      }
      if (t.cmdCount > SG_CMD_MAX) {
        _sgTracker.set(trackerKey, t);
        const reason = `Command spam (${t.cmdCount} commands / ${SG_CMD_WINDOW / 1000}s — limit ${SG_CMD_MAX})`;
        console.log(`[StrictGuard] BLOCKED ${senderPhone} in ${groupId.split('@')[0]}: ${reason}`);
        return { blocked: true, reason, action: 'warn' };
      }

      // ── 7. Repeated command abuse ──────────────────────────────────────────
      // Take the first word of the command (e.g. ".sticker" from ".sticker foo bar")
      const cmdWord = text.split(/\s+/)[0].toLowerCase();
      if (now - t.cmdRepeatStart > SG_CMD_WINDOW) {
        t.cmdRepeat = 1; t.lastCmdText = cmdWord; t.cmdRepeatStart = now;
      } else if (cmdWord === t.lastCmdText) {
        t.cmdRepeat++;
      } else {
        t.cmdRepeat = 1; t.lastCmdText = cmdWord;
      }
      if (t.cmdRepeat >= SG_REPEAT_MAX) {
        _sgTracker.set(trackerKey, t);
        const reason = `Repeated command abuse ("${cmdWord}" × ${t.cmdRepeat} times)`;
        console.log(`[StrictGuard] BLOCKED ${senderPhone} in ${groupId.split('@')[0]}: ${reason}`);
        return { blocked: true, reason, action: 'remove' };
      }
    }

    // ── 8. Mass URL / link spam ───────────────────────────────────────────────
    if (text.length > 0) {
      const urlMatches = text.match(URL_RE);
      if (urlMatches && urlMatches.length >= SG_URL_MAX) {
        _sgTracker.set(trackerKey, t);
        const reason = `Mass link spam (${urlMatches.length} URLs — limit ${SG_URL_MAX})`;
        console.log(`[StrictGuard] BLOCKED ${senderPhone} in ${groupId.split('@')[0]}: ${reason}`);
        return { blocked: true, reason, action: 'remove' };
      }
    }

    // ── 9. Mention flood ──────────────────────────────────────────────────────
    const mentionCount = (text.match(/@\d{6,}/g) || []).length;
    if (mentionCount >= SG_MENTION_MAX) {
      _sgTracker.set(trackerKey, t);
      const reason = `Mention flood (${mentionCount} @mentions — limit ${SG_MENTION_MAX})`;
      console.log(`[StrictGuard] BLOCKED ${senderPhone} in ${groupId.split('@')[0]}: ${reason}`);
      return { blocked: true, reason, action: 'remove' };
    }

    // ── 10. Save updated tracker and allow ────────────────────────────────────
    _sgTracker.set(trackerKey, t);
    return { blocked: false, reason: '', action: 'warn' };

  } catch (e) {
    // Fail-open: NEVER crash the handler
    console.error('[StrictGuard] checkStrictGuardMessage error:', e.message);
    return { blocked: false, reason: '', action: 'warn' };
  }
}

/**
 * Reset per-user tracker for a group (e.g. after a remove action clears their slate).
 */
function resetUserTracker(groupId, senderJid) {
  _sgTracker.delete(`${groupId}:${getPhone(senderJid)}`);
}

// ─────────────────────────────────────────────────────────────────────────────
// Layer 1 — Core guard engine  (promote / demote events)
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Called by handleGroupUpdate in handler.js for every promote/demote event.
 * Async — errors are caught internally and never bubble up to the caller.
 */
async function handleStrictGuardEvent(sock, update) {
  try {
    const { id: groupId, participants, action } = update;
    if (!participants?.length) return;
    if (action !== 'promote' && action !== 'demote' && action !== 'remove') return;

    // Use cache here too — this is a high-frequency path during contested elections
    const cfg = _readCachedConfig(groupId);
    if (!cfg.enabled || !cfg.owner) return;

    const ownerPhone = cfg.owner;

    // ── Bot identity ──────────────────────────────────────────────────────────
    const botRawId = sock.user?.id;
    if (!botRawId) return;
    const botPhone = getPhone(botRawId);

    // ── Fresh metadata for current admin list ─────────────────────────────────
    let meta;
    try { meta = await sock.groupMetadata(groupId); } catch { return; }
    if (!meta?.participants) return;

    // ── Check bot is admin ────────────────────────────────────────────────────
    const botPart    = meta.participants.find(p => getPhone(p.id) === botPhone);
    const botIsAdmin = !!(botPart && (botPart.admin === 'admin' || botPart.admin === 'superadmin'));
    if (!botIsAdmin) return;   // bot has no power — bail silently

    // ── Actor: who performed the action ──────────────────────────────────────
    const actorJid   = update.author || update.by || null;
    const actorPhone = actorJid ? getPhone(actorJid) : null;

    const actorIsOwner =
      actorPhone === ownerPhone  ||
      actorPhone === GLOBAL_OWNER ||
      !actorPhone;   // cannot determine actor → benefit of the doubt

    for (const participantJid of participants) {
      const targetPhone = getPhone(participantJid);

      if (targetPhone === botPhone)     continue;   // never touch the bot itself
      if (targetPhone === GLOBAL_OWNER) continue;   // never touch global bot owner

      // Anti-loop: skip if this exact action was triggered by the bot moments ago
      if (isBotAction(groupId, participantJid)) {
        console.log(`[StrictGuard] Anti-loop: skipping bot-initiated ${action} for ${targetPhone}`);
        continue;
      }

      // ── PROMOTE event ─────────────────────────────────────────────────────
      if (action === 'promote') {
        if (actorIsOwner) {
          console.log(`[StrictGuard] Legitimate promote: ${targetPhone} by ${actorPhone}`);
          continue;
        }

        console.log(`[StrictGuard] UNAUTHORIZED promote: target=${targetPhone} actor=${actorPhone} in ${groupId.split('@')[0]}`);

        markBotAction(groupId, participantJid);
        try { await sock.groupParticipantsUpdate(groupId, [participantJid], 'demote'); } catch (_) {}

        const mentions    = [participantJid];
        let actorOffenses = 0;
        let actorFullJid  = null;

        if (actorPhone && actorPhone !== GLOBAL_OWNER) {
          actorFullJid = toSWNet(actorJid);
          if (actorFullJid) {
            markBotAction(groupId, actorFullJid);
            actorOffenses = recordOffense(groupId, actorPhone);
            if (actorOffenses >= 2) {
              try { await sock.groupParticipantsUpdate(groupId, [actorFullJid], 'remove'); } catch (_) {}
            } else {
              try { await sock.groupParticipantsUpdate(groupId, [actorFullJid], 'demote'); } catch (_) {}
            }
            mentions.push(actorFullJid);
          }
        }

        const actorTag   = actorPhone ? `@${actorPhone}` : 'Unknown';
        const punishLine = actorPhone
          ? (actorOffenses >= 2
              ? `🔴 *${actorTag} removed from group* (repeat offender — ${actorOffenses}x)\n`
              : `⚠️ ${actorTag} has been *demoted* (offense #${actorOffenses})\n`)
          : '';

        try {
          await sock.sendMessage(groupId, {
            text:
              `🚨 *[ STRICT GUARD ALERT ]*\n\n` +
              `🔒 *Unauthorized admin promotion blocked!*\n\n` +
              `👤 Promoter : ${actorTag}\n` +
              `👤 Target   : @${targetPhone}\n\n` +
              `${punishLine}` +
              `✅ @${targetPhone} has been *demoted back.*\n\n` +
              `> *Only the designated group owner may change admin roles.*\n` +
              `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`,
            mentions,
          });
        } catch (_) {}

      // ── DEMOTE event ──────────────────────────────────────────────────────
      } else if (action === 'demote') {
        const targetIsOwner = targetPhone === ownerPhone;

        if (actorIsOwner) {
          console.log(`[StrictGuard] Legitimate demote: ${targetPhone} by ${actorPhone}`);
          continue;
        }

        console.log(`[StrictGuard] UNAUTHORIZED demote: target=${targetPhone} actor=${actorPhone} in ${groupId.split('@')[0]} ownerTargeted=${targetIsOwner}`);

        markBotAction(groupId, participantJid);
        try { await sock.groupParticipantsUpdate(groupId, [participantJid], 'promote'); } catch (_) {}

        const mentions    = [participantJid];
        let actorOffenses = 0;
        let actorFullJid  = null;

        if (actorPhone && actorPhone !== GLOBAL_OWNER) {
          actorFullJid = toSWNet(actorJid);
          if (actorFullJid) {
            markBotAction(groupId, actorFullJid);
            actorOffenses = recordOffense(groupId, actorPhone);
            if (actorOffenses >= 2) {
              try { await sock.groupParticipantsUpdate(groupId, [actorFullJid], 'remove'); } catch (_) {}
            } else {
              try { await sock.groupParticipantsUpdate(groupId, [actorFullJid], 'demote'); } catch (_) {}
            }
            mentions.push(actorFullJid);
          }
        }

        const actorTag   = actorPhone ? `@${actorPhone}` : 'Unknown';
        const victimLine = targetIsOwner ? `⚠️ *OWNER was the target — MAXIMUM SEVERITY*\n\n` : '';
        const punishLine = actorPhone
          ? (actorOffenses >= 2
              ? `🔴 *${actorTag} removed from group* (repeat offender — ${actorOffenses}x)\n`
              : `⚠️ ${actorTag} has been *demoted* (offense #${actorOffenses})\n`)
          : '';

        try {
          await sock.sendMessage(groupId, {
            text:
              `🚨 *[ STRICT GUARD ALERT ]*\n\n` +
              `🔒 *Unauthorized admin removal blocked!*\n\n` +
              `${victimLine}` +
              `👤 Offender : ${actorTag}\n` +
              `👤 Target   : @${targetPhone}\n\n` +
              `${punishLine}` +
              `✅ @${targetPhone} has been *re-promoted.*\n\n` +
              `> *Only the designated group owner may change admin roles.*\n` +
              `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`,
            mentions,
          });
        } catch (_) {}

      // ── REMOVE event — KickAll / mass-remove protection ─────────────────────
      } else if (action === 'remove') {
        if (!actorPhone || actorIsOwner)          continue;   // authorized remove
        if (targetPhone === botPhone)             continue;   // never kick bot itself
        if (isBotAction(groupId, participantJid)) continue;   // bot-initiated remove

        // Track rapid removals by same actor to detect KickAll
        const _rmKey = `${groupId}:${actorPhone}`;
        const _rmNow = Date.now();
        const _rt    = _removeTracker.get(_rmKey) || { count: 0, windowStart: _rmNow };
        if (_rmNow - _rt.windowStart > KICKALL_WINDOW_MS) {
          _rt.count = 1; _rt.windowStart = _rmNow;
        } else {
          _rt.count++;
        }
        _removeTracker.set(_rmKey, _rt);

        if (_rt.count >= KICKALL_THRESHOLD) {
          // KickAll confirmed — remove attacker immediately, no delay
          _removeTracker.delete(_rmKey);
          const _actFull = toSWNet(actorJid);
          if (!_actFull) continue;

          markBotAction(groupId, _actFull);
          try { await sock.groupParticipantsUpdate(groupId, [_actFull], 'remove'); } catch (_) {}

          try {
            await sock.sendMessage(groupId, {
              text:
                `🚨 *[ STRICT GUARD — KICKALL ALERT ]*\n\n` +
                `⚠️ *An unauthorized admin was performing a dangerous action!*\n\n` +
                `👤 Attacker : @${actorPhone}\n` +
                `📊 Removed  : *${_rt.count} members* in ${KICKALL_WINDOW_MS / 1000}s\n\n` +
                `🔴 *@${actorPhone} has been removed from the group by Strict Guard.*\n\n` +
                `> ✅ Group hijack/KickAll attempt blocked.\n` +
                `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`,
              mentions: [_actFull],
            });
          } catch (_) {}
        }
      }
    }
  } catch (e) {
    console.error('[StrictGuard] handleStrictGuardEvent error:', e.message);
  }
}

module.exports = {
  // Config API (used by command handlers)
  getGuardConfig,
  setGuardEnabled,
  setGroupOwner,

  // Layer 1: promote/demote event enforcement
  handleStrictGuardEvent,

  // Layer 2: message-level security (synchronous, zero I/O)
  checkStrictGuardMessage,
  resetUserTracker,
};
