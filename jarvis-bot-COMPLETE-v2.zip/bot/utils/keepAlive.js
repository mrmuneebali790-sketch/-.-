/**
 * Keep-Alive + Memory Monitor utility
 *
 * • Sends a periodic HTTP self-ping to prevent Replit / free-hosting sleep
 * • Logs memory usage every 10 minutes
 * • Triggers manual GC when heap usage exceeds threshold (requires --expose-gc)
 */

'use strict';

const http  = require('http');
const https = require('https');
const os    = require('os');

const KEEP_ALIVE_MS  = 3 * 60 * 1000;   // self-ping every 3 min (was 4)
const MEM_LOG_MS     = 10 * 60 * 1000;  // memory log every 10 min
const GC_TRIGGER_MB  = 900;             // trigger GC if heap > 900 MB
const PANEL_PORT     = process.env.PORT || 5000;

// ── Replit external URL detection ─────────────────────────────────────────────
// Replit sleeps containers after ~5 min of NO EXTERNAL traffic.
// Internal self-pings to 127.0.0.1 are invisible to Replit's sleep detector.
// We must hit the PUBLIC URL to actually keep the container awake.
const REPLIT_DOMAIN = process.env.REPLIT_DEV_DOMAIN
  || process.env.REPLIT_DOMAIN
  || null;

let _kaTimer  = null;
let _memTimer = null;

// ── Internal localhost ping (keeps local server warm) ─────────────────────────
function _pingLocalhost() {
  try {
    const req = http.get({
      hostname: '127.0.0.1',
      port    : PANEL_PORT,
      path    : '/api/status',
      timeout : 8000,
      headers : { 'User-Agent': 'BotKeepAlive/1.0' },
    }, (res) => res.resume());
    req.on('error', () => {});
    req.on('timeout', () => req.destroy());
  } catch (_) {}
}

// ── External public-URL ping (CRITICAL for Replit — prevents container sleep) ─
function _pingExternal() {
  if (!REPLIT_DOMAIN) return;
  try {
    const req = https.get(
      `https://${REPLIT_DOMAIN}/api/status`,
      { timeout: 10000, headers: { 'User-Agent': 'BotKeepAlive/1.0' } },
      (res) => res.resume()
    );
    req.on('error', () => {});
    req.on('timeout', () => req.destroy());
  } catch (_) {}
}

// ── Combined self-ping ────────────────────────────────────────────────────────
function selfPing() {
  _pingLocalhost();
  _pingExternal();
}

// ── Memory logger + GC trigger ────────────────────────────────────────────────
function logMemory() {
  try {
    const m      = process.memoryUsage();
    const freeMB = Math.round(os.freemem()  / 1024 / 1024);
    const totMB  = Math.round(os.totalmem() / 1024 / 1024);
    const heapMB = Math.round(m.heapUsed    / 1024 / 1024);
    const maxMB  = Math.round(m.heapTotal   / 1024 / 1024);
    const rssMB  = Math.round(m.rss         / 1024 / 1024);

    console.log(
      `[Memory] Heap: ${heapMB}/${maxMB} MB | RSS: ${rssMB} MB | OS free: ${freeMB}/${totMB} MB`
    );

    // Trigger GC if heap is above threshold and --expose-gc was passed
    if (heapMB > GC_TRIGGER_MB && typeof global.gc === 'function') {
      try {
        global.gc();
        console.log(`[Memory] ♻️  Manual GC triggered (heap was ${heapMB} MB)`);
      } catch (_) {}
    }
  } catch (_) {}
}

// ── Public API ────────────────────────────────────────────────────────────────
function start(opts = {}) {
  const kaMs  = opts.keepAliveMs || KEEP_ALIVE_MS;
  const memMs = opts.memLogMs    || MEM_LOG_MS;

  // Self-ping
  _kaTimer = setInterval(selfPing, kaMs);
  _kaTimer.unref?.();

  // Memory monitoring
  _memTimer = setInterval(logMemory, memMs);
  _memTimer.unref?.();

  // Log initial memory 30s after start (give server time to boot)
  const initTimer = setTimeout(logMemory, 30_000);
  initTimer.unref?.();
}

function stop() {
  if (_kaTimer)  { clearInterval(_kaTimer);  _kaTimer  = null; }
  if (_memTimer) { clearInterval(_memTimer); _memTimer = null; }
}

module.exports = { start, stop, selfPing, logMemory };
