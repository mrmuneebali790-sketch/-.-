'use strict';
/**
 * Command Loader — loads all commands from commands/ subdirectories.
 * Supports hot-reload: clears require.cache before re-loading (used after GitHub update).
 */

const fs   = require('fs');
const path = require('path');

const COMMANDS_PATH = path.join(__dirname, '..', 'commands');
const SKIP_DIRS     = new Set(['lib', 'data']);

function _clearCommandCache() {
  const prefix = COMMANDS_PATH + path.sep;
  for (const key of Object.keys(require.cache)) {
    if (key.startsWith(prefix)) delete require.cache[key];
  }
}

function loadCommands(hotReload = false) {
  if (hotReload) _clearCommandCache();

  const commands = new Map();

  if (!fs.existsSync(COMMANDS_PATH)) {
    console.warn('[CommandLoader] commands/ directory not found:', COMMANDS_PATH);
    return commands;
  }

  let loaded = 0, failed = 0;

  for (const category of fs.readdirSync(COMMANDS_PATH)) {
    if (SKIP_DIRS.has(category)) continue;
    const categoryPath = path.join(COMMANDS_PATH, category);
    let stat;
    try { stat = fs.statSync(categoryPath); } catch { continue; }
    if (!stat.isDirectory()) continue;

    for (const file of fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'))) {
      const filePath = path.join(categoryPath, file);
      try {
        const cmd = require(filePath);
        if (!cmd || !cmd.name) continue;
        commands.set(cmd.name, cmd);
        if (Array.isArray(cmd.aliases)) {
          for (const alias of cmd.aliases) commands.set(alias, cmd);
        }
        loaded++;
      } catch (err) {
        console.error(`[CommandLoader] ❌ ${category}/${file}:`, err.message);
        failed++;
      }
    }
  }

  console.log(`[CommandLoader] ✅ ${loaded} commands loaded${failed ? ` (${failed} failed)` : ''}`);
  return commands;
}

module.exports = { loadCommands };
