'use strict';
/**
 * utils/antifakeState.js — In-memory state for Anti-Fake verification queue
 * Stores per-group pending verification requests.
 * Map: groupJid -> Map<userJid, { voiceReceived, joinedAt }>
 */

const _pending = new Map(); // groupJid → Map<userJid, {voiceReceived, joinedAt}>

/**
 * Get all pending verifications for a group.
 * @param {string} groupJid
 * @returns {Map<string, object>}
 */
const getPending = (groupJid) => _pending.get(groupJid) || new Map();

/**
 * Check if a user is pending verification in a group.
 */
const isPending = (groupJid, userJid) => {
  const m = _pending.get(groupJid);
  return m ? m.has(userJid) : false;
};

/**
 * Add a user to the pending queue.
 */
const addPending = (groupJid, userJid, data = {}) => {
  if (!_pending.has(groupJid)) _pending.set(groupJid, new Map());
  _pending.get(groupJid).set(userJid, {
    voiceReceived: false,
    joinedAt: Date.now(),
    ...data
  });
};

/**
 * Remove a user from the pending queue (verified or kicked).
 */
const removePending = (groupJid, userJid) => {
  const m = _pending.get(groupJid);
  if (!m) return;
  m.delete(userJid);
  if (m.size === 0) _pending.delete(groupJid);
};

/**
 * Mark that a user has sent their verification voice note.
 */
const setVoiceReceived = (groupJid, userJid) => {
  const m = _pending.get(groupJid);
  if (m && m.has(userJid)) {
    m.get(userJid).voiceReceived = true;
  }
};

/**
 * Clear all pending verifications for a group (e.g. when antifake is disabled).
 */
const clearGroup = (groupJid) => _pending.delete(groupJid);

module.exports = { getPending, isPending, addPending, removePending, setVoiceReceived, clearGroup };
