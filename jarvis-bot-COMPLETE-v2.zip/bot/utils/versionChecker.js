'use strict';

/**
 * versionChecker.js
 * Checks GitHub for a newer bot version and notifies the owner via WhatsApp.
 * Called once per session on connection open.
 *
 * Remote:  config.updateVersionUrl  → version.json  { "version": "1.2.0", "changes": "..." }
 * Local:   package.json             → { "version": "1.0.0" }
 */

const https   = require('https');
const config  = require('../config');

const OWNER_NUM     = config.mainDeveloper || '923196615238';
const VERSION_URL   = config.updateVersionUrl ||
  'https://raw.githubusercontent.com/mrmuneebali907-byte/muneeb-bot-updater/main/version.json';

// Semaphore: run once per process lifetime (all sessions share one check)
let _checked = false;

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, {
      headers: { 'User-Agent': 'MuneebAliBot-VersionChecker/1.0', 'Accept': 'application/json' },
      timeout: 10000,
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('Invalid JSON from version endpoint')); }
      });
    }).on('error', reject).on('timeout', () => reject(new Error('Timeout')));
  });
}

function semverGt(remoteVer, localVer) {
  try {
    const parse = v => String(v || '0.0.0').replace(/[^0-9.]/g, '').split('.').map(Number);
    const [rM, rm, rp] = parse(remoteVer);
    const [lM, lm, lp] = parse(localVer);
    if (rM !== lM) return rM > lM;
    if (rm !== lm) return rm > lm;
    return rp > lp;
  } catch { return false; }
}

async function checkForUpdate(sock) {
  if (_checked) return;
  _checked = true;

  // Small delay so the session is fully stable before sending
  await new Promise(r => setTimeout(r, 8000));

  try {
    const remote = await fetchJson(VERSION_URL);
    const remoteVersion = remote?.version;
    if (!remoteVersion) return;

    let localVersion = '1.0.0';
    try { localVersion = require('../package.json').version; } catch (_) {}

    if (!semverGt(remoteVersion, localVersion)) {
      console.log(`[VersionChecker] ✅ Up to date (v${localVersion})`);
      return;
    }

    console.log(`[VersionChecker] 🆕 Update available: v${localVersion} → v${remoteVersion}`);

    // Send to connected bot owner (whoever scanned QR / used pairing code)
    // NOT hardcoded owner — each session owner gets their own notification
    const connectedNum = sock.user?.id
      ? sock.user.id.split(':')[0].split('@')[0].replace(/[^0-9]/g, '')
      : null;

    if (!connectedNum) return; // session not ready yet, skip

    const recipientJid = `${connectedNum}@s.whatsapp.net`;
    const changes  = remote.changes ? `\n\n📋 *Changes:*\n${remote.changes}` : '';

    await sock.sendMessage(recipientJid, {
      text:
        `🔔 *Bot Update Available!*\n\n` +
        `📦 Current version : *v${localVersion}*\n` +
        `🆕 New version     : *v${remoteVersion}*${changes}\n\n` +
        `💡 Run *.update* to upgrade now!\n\n` +
        `> _Auto-check by ${config.botName || 'JARVIS'}_`,
    });

    console.log(`[VersionChecker] 📩 Update notice sent to ${connectedNum}`);
  } catch (e) {
    console.warn('[VersionChecker] Check failed (non-critical):', e.message);
    _checked = false; // allow retry on next session connect
  }
}

module.exports = { checkForUpdate };
