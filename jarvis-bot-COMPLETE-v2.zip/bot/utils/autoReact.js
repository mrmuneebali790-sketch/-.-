'use strict';
// utils/autoReact.js — Per-bot isolated auto-react settings
//
// Storage: database.js → data/botSettings.json
//   {
//     "923xxxxxxxxx": {
//       "autoReact":     true,
//       "autoReactMode": "bot",
//       "autoReactEmoji": "❤️"   ← new: fixed emoji (null = random)
//     }
//   }

const db     = require('../database');
const config = require('../config');

/**
 * Load auto-react settings for a specific bot session.
 * @param {string} [botId]  sock.user.id or phone number
 * @returns {{ enabled: boolean, mode: string, emoji: string|null }}
 */
function load(botId) {
  if (botId) {
    const enabled = db.getBotSetting(botId, 'autoReact',      null);
    const mode    = db.getBotSetting(botId, 'autoReactMode',  null);
    const emoji   = db.getBotSetting(botId, 'autoReactEmoji', null);
    if (enabled !== null) {
      return { enabled: Boolean(enabled), mode: mode || 'bot', emoji: emoji || null };
    }
  }
  // No per-bot value yet → use global config defaults
  return {
    enabled : config.autoReact     || false,
    mode    : config.autoReactMode || 'bot',
    emoji   : null,
  };
}

/**
 * Save auto-react settings for a specific bot session.
 * @param {{ enabled: boolean, mode: string, emoji?: string|null }} data
 * @param {string} [botId]  sock.user.id or phone number
 */
function save(data, botId) {
  if (botId) {
    db.updateBotSettings(botId, {
      autoReact     : data.enabled,
      autoReactMode : data.mode,
      autoReactEmoji: data.emoji ?? null,
    });
    return;
  }
  // Fallback: write to the global config.js (backward-compat when botId unavailable)
  try {
    const fs   = require('fs');
    const path = require('path');
    const CONFIG_PATH = path.join(__dirname, '../config.js');
    let content = fs.readFileSync(CONFIG_PATH, 'utf8');
    content = content.replace(/autoReact:\s*(true|false)/, `autoReact: ${data.enabled}`);
    if (content.includes('autoReactMode:')) {
      content = content.replace(/autoReactMode:\s*['"]\w+['"]/, `autoReactMode: '${data.mode}'`);
    } else {
      content = content.replace(
        /(autoReact:\s*(?:true|false),?)/,
        `$1\n    autoReactMode: '${data.mode}',`
      );
    }
    fs.writeFileSync(CONFIG_PATH, content, 'utf8');
    delete require.cache[require.resolve('../config.js')];
  } catch (err) {
    console.error('[autoReact] fallback save error:', err.message);
  }
}

module.exports = { load, save };
