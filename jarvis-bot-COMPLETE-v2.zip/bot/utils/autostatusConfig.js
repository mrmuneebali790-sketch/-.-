'use strict';
/**
 * utils/autostatusConfig.js — Per-bot isolated auto-status settings
 * Storage: database.js → botSettings[botId]['autoStatus'] / ['statusReact']
 * Legacy fallback: data/autoStatus.json (read-only, for migration)
 */

const fs   = require('fs');
const path = require('path');

let _db = null;
function _getDb() {
  if (!_db) { try { _db = require('../database'); } catch (_) {} }
  return _db;
}

const DATA_DIR    = path.join(__dirname, '..', 'data');
const CONFIG_FILE = path.join(DATA_DIR, 'autoStatus.json');

function _legacyRead() {
  try {
    if (fs.existsSync(CONFIG_FILE)) return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
  } catch (_) {}
  return { enabled: false, reactOn: false };
}
function _legacyWrite(data) {
  try {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(data, null, 2));
  } catch (_) {}
}

const isAutoStatusEnabled = (botId) => {
  if (botId) {
    const db = _getDb();
    const v  = db ? db.getBotSetting(botId, 'autoStatus', null) : null;
    if (v !== null) return v === true;
  }
  return _legacyRead().enabled === true;
};

const isStatusReactEnabled = (botId) => {
  if (botId) {
    const db = _getDb();
    const v  = db ? db.getBotSetting(botId, 'statusReact', null) : null;
    if (v !== null) return v === true;
  }
  return _legacyRead().reactOn === true;
};

const setAutoStatus = (v, botId) => {
  if (botId) {
    const db = _getDb();
    if (db) { db.setBotSetting(botId, 'autoStatus', !!v); return; }
  }
  const d = _legacyRead(); d.enabled = !!v; _legacyWrite(d);
};

const setStatusReact = (v, botId) => {
  if (botId) {
    const db = _getDb();
    if (db) { db.setBotSetting(botId, 'statusReact', !!v); return; }
  }
  const d = _legacyRead(); d.reactOn = !!v; _legacyWrite(d);
};

module.exports = { isAutoStatusEnabled, isStatusReactEnabled, setAutoStatus, setStatusReact };
