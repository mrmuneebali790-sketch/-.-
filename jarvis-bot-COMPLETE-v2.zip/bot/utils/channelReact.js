'use strict';

/**
 * Per-bot, per-WhatsApp-Channel auto-reaction settings.
 *
 * A WhatsApp account can add only one reaction to one channel post. The
 * command intentionally stores one emoji per channel; it does not attempt
 * bulk/multi-account reactions.
 */

const db = require('../database');

const DEFAULT_EMOJI = '❤️';
const MAX_CHANNELS = 100;

function normalizeJid(jid) {
  const value = String(jid || '').trim();
  return /^\d+@newsletter$/.test(value) ? value : '';
}

function load(botId) {
  const value = botId ? db.getBotSetting(botId, 'channelAutoReact', {}) : {};
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  return value;
}

function get(botId, jid) {
  const key = normalizeJid(jid);
  if (!key) return null;
  const cfg = load(botId)[key];
  if (!cfg || cfg.enabled !== true) return null;
  return {
    enabled: true,
    emoji: typeof cfg.emoji === 'string' && cfg.emoji.trim()
      ? cfg.emoji.trim()
      : DEFAULT_EMOJI,
    name: cfg.name || key,
  };
}

function set(botId, jid, updates) {
  const key = normalizeJid(jid);
  if (!botId || !key) throw new Error('Invalid bot or channel JID');

  const all = load(botId);
  all[key] = {
    ...(all[key] || {}),
    ...updates,
    jid: key,
    updatedAt: new Date().toISOString(),
  };

  const keys = Object.keys(all);
  if (keys.length > MAX_CHANNELS) {
    delete all[keys[0]];
  }
  db.setBotSetting(botId, 'channelAutoReact', all);
  return all[key];
}

function remove(botId, jid) {
  const key = normalizeJid(jid);
  if (!botId || !key) return;
  const all = load(botId);
  delete all[key];
  db.setBotSetting(botId, 'channelAutoReact', all);
}

function list(botId) {
  return Object.values(load(botId))
    .filter(cfg => cfg && cfg.enabled === true && /^\d+@newsletter$/.test(cfg.jid))
    .map(cfg => ({ ...cfg }));
}

module.exports = {
  DEFAULT_EMOJI,
  normalizeJid,
  load,
  get,
  set,
  remove,
  list,
};