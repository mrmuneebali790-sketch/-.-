/**
 * NSFW Image Scanner — Local pixel-level skin detection
 *
 * KEY BIOLOGICAL FACT USED:
 *   Real human skin absorbs blue light — so skin pixels always have Green > Blue.
 *   Pink / pastel / cartoon backgrounds have Blue ≈ Green or Blue > Green.
 *   Adding the `g > b` guard eliminates false positives on pink/pastel images
 *   while still catching every real skin tone (fair → dark).
 *
 * Pipeline:
 *   1. Resize to 150×150 px (fast, ~30–60 ms)
 *   2. Count meme-indicator pixels (near-white, near-black, saturated non-skin)
 *   3. If > 40% of image is "meme-like" → skip (cartoon / text screenshot)
 *   4. Count skin-tone pixels using the corrected Kovac-Peer-Solina rules
 *   5. If skin pixels > 65% of non-meme pixels → NSFW (very conservative)
 */

const sharp = require('sharp');

// ── Skin-tone classifier (false-positive safe) ───────────────────────────────
function isSkinPixel(r, g, b) {
  // CRITICAL GUARD: real skin always has G > B (absorbs blue light).
  // Pink/pastel have B ≈ G or B > G — this single check kills most false-positives.
  if (g <= b) return false;

  // Rule 1 — fair-to-medium skin (Kovac)
  const rule1 =
    r > 95 && g > 40 && b > 20 &&
    (Math.max(r, g, b) - Math.min(r, g, b)) > 15 &&
    Math.abs(r - g) > 15 &&
    r > g && r > b;

  // Rule 2 — very fair / overexposed skin
  const rule2 =
    r > 220 && g > 210 && b > 170 &&
    Math.abs(r - g) <= 15 &&
    r > b && g > b;

  // Rule 3 — medium-dark skin tones
  const rule3 =
    r > 60 && g > 30 && b > 10 &&
    r > g && r > b &&
    (r - Math.min(g, b)) > 20 &&
    r < 240;

  return rule1 || rule2 || rule3;
}

// ── Near-white pixel (meme text box, cartoon highlight, bright background) ───
function isNearWhite(r, g, b) {
  return r > 210 && g > 210 && b > 210;
}

// ── Near-black pixel (text, shadows) ────────────────────────────────────────
function isNearBlack(r, g, b) {
  return r < 40 && g < 40 && b < 40;
}

// ── Saturated non-skin color (cartoon, vivid backgrounds) ───────────────────
function isVividNonSkin(r, g, b) {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const saturation = max > 0 ? (max - min) / max : 0;
  // Vivid AND not reddish/yellowish (i.e. clearly not skin)
  return saturation > 0.5 && !(r > g && r > b);
}

// ── Main scanner ─────────────────────────────────────────────────────────────
/**
 * @param {Buffer} buffer  Raw image bytes (JPG / PNG / WEBP / GIF etc.)
 * @returns {{ nsfw: boolean, score: number, reason: string }}
 */
async function scanImageBuffer(buffer) {
  if (!buffer || buffer.length < 2000) {
    return { nsfw: false, score: 0, reason: 'image too small' };
  }

  try {
    const { data, info } = await sharp(buffer)
      .resize(150, 150, { fit: 'fill' })
      .removeAlpha()
      .raw()
      .toBuffer({ resolveWithObject: true });

    const totalPx = info.width * info.height;
    let skinPx    = 0;
    let memePx    = 0;   // white + black + vivid cartoon pixels

    for (let i = 0; i < data.length; i += 3) {
      const r = data[i], g = data[i + 1], b = data[i + 2];

      if (isNearWhite(r, g, b) || isNearBlack(r, g, b) || isVividNonSkin(r, g, b)) {
        memePx++;
      } else if (isSkinPixel(r, g, b)) {
        skinPx++;
      }
    }

    const memeRatio = memePx / totalPx;

    // If > 40% of the image is clearly cartoon/meme/text → not a nude photo
    if (memeRatio > 0.40) {
      return { nsfw: false, score: 0, reason: `cartoon/meme image (${Math.round(memeRatio * 100)}% non-skin content)` };
    }

    // Among the remaining "realistic" pixels, what fraction is skin?
    const realisticPx = totalPx - memePx;
    const score       = realisticPx > 0 ? skinPx / realisticPx : 0;

    // Threshold = 65% — requires a very high proportion of bare skin to trigger.
    // A selfie of a fully-clothed person peaks at ~25-35%.
    // A nude image peaks at ~70-90%.
    const nsfw = score > 0.65;

    return {
      nsfw,
      score,
      reason: nsfw
        ? `High skin exposure: ${Math.round(score * 100)}% of image is bare skin`
        : 'normal'
    };
  } catch (err) {
    return { nsfw: false, score: 0, reason: `scan error: ${err.message}` };
  }
}

module.exports = { scanImageBuffer };
