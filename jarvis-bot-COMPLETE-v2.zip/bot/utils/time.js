'use strict';

/**
 * Pakistan Time Helper — utils/time.js
 *
 * Single source of truth for all time/date formatting in the bot.
 * Always returns Asia/Karachi (PKT, UTC+5) time regardless of server TZ.
 *
 * Usage:
 *   const { pkTime, pkDate, pkDateTime, pkMoment } = require('./utils/time');
 *   pkTime()          → "03:45 PM"
 *   pkDate()          → "03/05/2026"
 *   pkDateTime()      → "03/05/2026 03:45 PM"
 *   pkMoment()        → moment-timezone object (full API available)
 */

const moment = require('moment-timezone');

const TZ = 'Asia/Karachi';

/**
 * Current Pakistan time as a formatted string.
 * @param {string} [fmt='hh:mm A']  moment format string
 * @returns {string}
 */
const pkTime = (fmt = 'hh:mm A') => moment().tz(TZ).format(fmt);

/**
 * Current Pakistan date as a formatted string.
 * @param {string} [fmt='DD/MM/YYYY']
 * @returns {string}
 */
const pkDate = (fmt = 'DD/MM/YYYY') => moment().tz(TZ).format(fmt);

/**
 * Current Pakistan date+time.
 * @param {string} [fmt='DD/MM/YYYY hh:mm A']
 * @returns {string}
 */
const pkDateTime = (fmt = 'DD/MM/YYYY hh:mm A') => moment().tz(TZ).format(fmt);

/**
 * Returns a live moment-timezone object for advanced formatting/manipulation.
 * @returns {moment.Moment}
 */
const pkMoment = () => moment().tz(TZ);

module.exports = { pkTime, pkDate, pkDateTime, pkMoment, TZ };
