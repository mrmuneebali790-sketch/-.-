/**
 * Media Downloader — v3
 *
 * Exports:
 *   withRace(sources, label)           — race all sources in parallel, first win
 *   withFallback(sources, label)       — sequential fallback
 *   withRetry(fn, times, delayMs)      — retry a single async fn N times
 *   downloadBuffer(url, options)       — download URL → Buffer (with retries)
 *   streamToFile(url, options)         — stream URL → /tmp file with progress
 *   deleteTempFile(path)               — safe temp file cleanup
 *   getFileSizeMB(url)                 — HEAD request → file size in MB (0 if unknown)
 *   urlCache                           — 10-min TTL in-memory result cache
 */

'use strict';

const axios              = require('axios');
const fs                 = require('fs');
const os                 = require('os');
const path               = require('path');
const { pipeline }       = require('stream/promises');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

// ── URL Result Cache (10-min TTL, max 200 entries) ────────────────────────────
const _cacheStore = new Map();
const CACHE_TTL   = 10 * 60 * 1000;

const urlCache = {
  get(key) {
    const e = _cacheStore.get(key);
    if (!e) return null;
    if (Date.now() > e.exp) { _cacheStore.delete(key); return null; }
    return e.data;
  },
  set(key, data) {
    if (_cacheStore.size >= 200) {
      const first = _cacheStore.keys().next().value;
      _cacheStore.delete(first);
    }
    _cacheStore.set(key, { data, exp: Date.now() + CACHE_TTL });
  },
  has(key) { return this.get(key) !== null; },
};

// ── withRace ──────────────────────────────────────────────────────────────────
// Fire ALL sources simultaneously. Resolve on first truthy result.
// Reject only when every source has failed.
function withRace(sources, label) {
  if (!sources?.length) return Promise.reject(new Error(`No ${label} sources`));
  return new Promise((resolve, reject) => {
    let done = false, fails = 0, lastErr;
    const onOk = r => {
      if (done) return;
      if (r) { done = true; resolve(r); }
      else     onFail(new Error('Source returned empty result'));
    };
    const onFail = e => {
      if (done) return;
      lastErr = e;
      if (++fails === sources.length) {
        done = true;
        reject(lastErr || new Error(`All ${label} sources failed`));
      }
    };
    for (const src of sources) {
      try { src().then(onOk).catch(onFail); }
      catch (e) { onFail(e); }
    }
  });
}

// ── withFallback ──────────────────────────────────────────────────────────────
async function withFallback(sources, label) {
  let lastErr;
  for (const src of sources) {
    try { const r = await src(); if (r) return r; }
    catch (e) { lastErr = e; }
  }
  throw lastErr || new Error(`All ${label} sources failed`);
}

// ── withRetry ─────────────────────────────────────────────────────────────────
// Retry a single async function up to `times` times with `delayMs` between.
async function withRetry(fn, times = 2, delayMs = 1500) {
  let lastErr;
  for (let i = 0; i < times; i++) {
    try { return await fn(); }
    catch (e) {
      lastErr = e;
      if (i < times - 1) await new Promise(r => setTimeout(r, delayMs));
    }
  }
  throw lastErr;
}

// ── getFileSizeMB ─────────────────────────────────────────────────────────────
// HEAD probe — returns 0 if unknown or unreachable (5 s timeout).
async function getFileSizeMB(url) {
  try {
    const r = await axios.head(url, {
      timeout      : 5_000,
      headers      : { 'User-Agent': UA },
      validateStatus: s => s < 500,
    });
    const cl = parseInt(r.headers['content-length'] || '0', 10);
    return cl / (1024 * 1024);
  } catch { return 0; }
}

// ── downloadBuffer ────────────────────────────────────────────────────────────
// Download URL to Buffer. options: { timeout, retries, headers }.
async function downloadBuffer(url, options = {}) {
  const timeout = options.timeout || 90_000;
  const retries = options.retries || 2;
  let lastErr;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await axios.get(url, {
        responseType    : 'arraybuffer',
        timeout,
        maxContentLength: 200 * 1024 * 1024,
        maxBodyLength   : 200 * 1024 * 1024,
        headers         : { 'User-Agent': UA, ...(options.headers || {}) },
        validateStatus  : s => s >= 200 && s < 400,
      });
      const buf = Buffer.from(res.data);
      if (!buf.length) throw new Error('Empty response buffer');
      return buf;
    } catch (e) {
      lastErr = e;
      if (i < retries - 1) await new Promise(r => setTimeout(r, 1200));
    }
  }
  throw lastErr;
}

// ── streamToFile ─────────────────────────────────────────────────────────────
// Stream URL directly to a /tmp file. Returns { tmpPath, sizeMB }.
// options.onProgress({ pct, downloadedMB, totalMB }) fires ~every 3 s.
async function streamToFile(url, options = {}) {
  const tmpPath = path.join(
    os.tmpdir(),
    `mdl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.mp4`
  );

  const response = await axios({
    url,
    method          : 'GET',
    responseType    : 'stream',
    timeout         : options.timeout || 120_000,
    maxContentLength: 500 * 1024 * 1024,
    headers         : { 'User-Agent': UA, ...(options.headers || {}) },
    validateStatus  : s => s >= 200 && s < 400,
  });

  const totalBytes = parseInt(response.headers['content-length'] || '0', 10);
  let downloaded = 0, lastCb = 0;

  response.data.on('data', chunk => {
    downloaded += chunk.length;
    if (options.onProgress && Date.now() - lastCb >= 3000) {
      lastCb = Date.now();
      options.onProgress({
        pct         : totalBytes ? Math.round((downloaded / totalBytes) * 100) : -1,
        downloadedMB: +(downloaded / 1024 / 1024).toFixed(1),
        totalMB     : totalBytes ? +(totalBytes / 1024 / 1024).toFixed(1) : '?',
      });
    }
  });

  await pipeline(response.data, fs.createWriteStream(tmpPath));
  return { tmpPath, sizeMB: +(downloaded / 1024 / 1024).toFixed(1) };
}

// ── deleteTempFile ────────────────────────────────────────────────────────────
function deleteTempFile(filePath) {
  if (!filePath) return;
  try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch (_) {}
}

// ── probeSize ─────────────────────────────────────────────────────────────────
// HEAD request → { size (bytes or 0), contentType (string or null) }
// Used by facebook.js for smart send logic (same as getFileSizeMB but richer)
async function probeSize(url, options = {}) {
  try {
    const r = await axios.head(url, {
      timeout      : options.timeout || 8_000,
      headers      : { 'User-Agent': UA, ...(options.headers || {}) },
      validateStatus: s => s < 500,
      maxRedirects : 5,
    });
    const size        = parseInt(r.headers['content-length'] || '0', 10) || 0;
    const contentType = r.headers['content-type'] || null;
    return { size, contentType };
  } catch {
    return { size: 0, contentType: null };
  }
}

module.exports = {
  withRace, withFallback, withRetry,
  downloadBuffer, streamToFile, deleteTempFile,
  getFileSizeMB, probeSize, urlCache,
};
