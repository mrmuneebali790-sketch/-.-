/**
 * Non-blocking download queue
 *
 * - Limits concurrent downloads (default: 5)
 * - runInBackground(fn, onError): fire-and-forget job dispatch
 * - globalQueue: singleton shared across all downloaders
 *
 * This lets the bot reply INSTANTLY and run downloads in the
 * background without blocking the WhatsApp message handler.
 */

'use strict';

class DownloadQueue {
  constructor(concurrency = 5) {
    this._max    = concurrency;
    this._active = 0;
    this._queue  = [];
  }

  /**
   * Enqueue an async job. Returns a Promise that resolves/rejects
   * when the job eventually runs and completes.
   */
  run(fn) {
    return new Promise((resolve, reject) => {
      this._queue.push({ fn, resolve, reject });
      this._tick();
    });
  }

  _tick() {
    while (this._active < this._max && this._queue.length) {
      const { fn, resolve, reject } = this._queue.shift();
      this._active++;
      Promise.resolve()
        .then(fn)
        .then(
          result => { this._active--; resolve(result); this._tick(); },
          error  => { this._active--; reject(error);   this._tick(); }
        );
    }
  }

  get pending() { return this._queue.length; }
  get active()  { return this._active; }
}

// Singleton — imported by all media commands
const globalQueue = new DownloadQueue(5);

/**
 * Fire-and-forget: run fn in background via globalQueue.
 * Errors go to onError(err); if omitted, they are just logged.
 */
function runInBackground(fn, onError) {
  globalQueue.run(fn).catch(err => {
    if (onError) {
      try { onError(err); } catch (_) {}
    } else {
      console.error('[DownloadQueue] background job error:', err?.message || err);
    }
  });
}

module.exports = { DownloadQueue, globalQueue, runInBackground };
