'use strict';

/**
 * Islamic Greeting Handler — utils/islamicGreeting.js
 *
 * Handles two non-command auto-reply behaviors:
 *
 *  1. SALAM REPLY
 *     Trigger: salam / assalamualaikum / aslam o alikum / slm / aoa / aslm
 *     Response: Stylish Walekum Salam reply (5 random variations)
 *     Cooldown: 15 s per user — prevents spam in busy groups
 *
 *  2. HI / HELLO CORRECTION
 *     Trigger: hi / hello / hey / hlo / helo / heya (exact or leading word)
 *     Response: Polite, friendly Islamic-greeting guidance (5 variations)
 *     Cooldown: 20 s per user
 *
 * Both systems:
 *  ✔ Work in private + group chats
 *  ✔ Case-insensitive
 *  ✔ Random variation so replies never feel robotic
 *  ✔ Never fire on bot's own messages (msg.key.fromMe guard in handler)
 *  ✔ Never crash — all errors silently swallowed
 *
 * Exported:
 *  handleGreeting(sock, msg, body, sender, from) → Promise<boolean>
 *    Returns true if a greeting was handled (handler should return early).
 */

// ── Cooldown maps (per sender, milliseconds) ───────────────────────────────────
const salamCooldown  = new Map();   // senderJid → lastRepliedAt
const hiCooldown     = new Map();   // senderJid → lastRepliedAt
const SALAM_CD_MS    = 15_000;      // 15 s
const HI_CD_MS       = 20_000;      // 20 s

// Auto-cleanup: prevent these maps from growing forever
setInterval(() => {
  const now = Date.now();
  for (const [k, t] of salamCooldown) if (now - t > SALAM_CD_MS * 4)  salamCooldown.delete(k);
  for (const [k, t] of hiCooldown)    if (now - t > HI_CD_MS   * 4)  hiCooldown.delete(k);
}, 5 * 60 * 1000).unref();

// ── Trigger patterns ───────────────────────────────────────────────────────────
// Salam: exact word (or the whole message IS a salam phrase)
const SALAM_RE = /^(assalamu?\s*alaikum|assalam\s*o\s*alaikum|aslam\s*o\s*alikum|salam\s*alaikum|salam|slm|aoa|aslm|as salam|asalam|as-salam)[\s!.✨🤲]*$/i;

// Hi/Hello: leading word only (so "hi bhai" also triggers, but "bahishti" doesn't)
// Anchored at start, word-boundary checked on the keyword
const HI_RE = /^(hi|hello|hey|hlo|helo|heya)\b[\s!.,?😊🙂]*/i;

// ── Salam reply pool (5 unique styles) ────────────────────────────────────────
const SALAM_REPLIES = [
  `✨ *Walekum Salam!* ✨\n\nHow are you doing? 😊\nMay Allah keep you happy 🤲\nAnd protect you from all troubles! 🌹`,

  `🌙 *Wa Alaikum Salam!* 🌙\n\nYour salam is graciously received! 😌\nMay Allah grant your heart peace 🤲\nStay blessed! ✨`,

  `☀️ *Walekum Assalam wa Rahmatullahi wa Barakatuh!* ☀️\n\nSubhan Allah — what a lovely greeting! 🥰\nMay Allah shower His mercy upon you 🌹\nI hope all is well with you? 😊`,

  `🤝 *Wa Alaikum Salam!* 🤝\n\nWell done — giving salam is a Sunnah! 🌟\nMay Allah grant you health and happiness 🤲\nWishing you goodness in every moment! 💫`,

  `💚 *Walekum Salam wa Rahmatullah!* 💚\n\nMasha Allah — you've fulfilled the Sunnah of salam! 😊\nMay Allah grant you success in this life and the next 🤲\nStay happy, stay blessed! 🌷`,
];

// ── Hi/Hello correction pool (5 unique polite variations) ─────────────────────
const HI_REPLIES = [
  `😊 *Hello there!*\n\nSaying *"Assalamu Alaikum"* instead of\n"Hi / Hello" is so much better! 🌟\n\nIt's a Sunnah, and it becomes\na prayer for both of you 🤲\n\nDo give it a try! 💚`,

  `🌹 *Friend,* let me share the benefits of salam!\n\nSaying "Assalamu Alaikum" means:\n✅ A new chain of prayer begins\n✅ Good is prayed for both of you\n✅ The Sunnah of the Prophet ﷺ is fulfilled 🤲\n\nFrom now on, say *Salam* instead of "Hi"! 😊`,

  `✨ *Start with Salam!* ✨\n\nInstead of saying "Hi" or "Hello",\ntry saying *"Assalamu Alaikum"* 🌙\n\nIt's part of our identity —\na beautiful practice among Muslims! 💚\n\nMay Allah bless you! 🤲`,

  `😌 *A small request:*\n\nInstead of "Hi/Hello",\nif you say *Assalamu Alaikum* —\n\n— the Sunnah is fulfilled ✅\n— the angels say Ameen 🌟\n— blessings follow, insha'Allah 🤲\n\nThank you — Jazak Allah Khair! 💚`,

  `🌙 *A gentle reminder:*\n\nNot "Hello",\nbut start with *"As-Salamu Alaykum"*! 😊\n\nThe Prophet ﷺ of Allah said:\n_"Spread the greeting of Salam"_ 🤲\n\nA small act, a great reward! ✨\nMay Allah grant you the ability! 💚`,
];

// ── Random picker ──────────────────────────────────────────────────────────────
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

// ── Main exported function ─────────────────────────────────────────────────────
/**
 * @param {object} sock    — Baileys socket
 * @param {object} msg     — raw message object
 * @param {string} body    — extracted text body (already trimmed)
 * @param {string} sender  — sender JID
 * @param {string} from    — chat JID (group or private)
 * @returns {Promise<boolean>}  true = handled (caller should return early)
 */
async function handleGreeting(sock, msg, body, sender, from) {
  if (!body) return false;
  const now  = Date.now();
  const text = body.trim();

  // ── 1. Salam reply ───────────────────────────────────────────────────────────
  if (SALAM_RE.test(text)) {
    const last = salamCooldown.get(sender) || 0;
    if (now - last < SALAM_CD_MS) return false;   // still in cooldown — skip silently
    salamCooldown.set(sender, now);

    try {
      await sock.sendMessage(from, { text: pick(SALAM_REPLIES) }, { quoted: msg });
    } catch (_) {}
    return true;
  }

  // ── 2. Hi / Hello correction ─────────────────────────────────────────────────
  if (HI_RE.test(text)) {
    const last = hiCooldown.get(sender) || 0;
    if (now - last < HI_CD_MS) return false;
    hiCooldown.set(sender, now);

    try {
      await sock.sendMessage(from, { text: pick(HI_REPLIES) }, { quoted: msg });
    } catch (_) {}
    return true;
  }

  return false;
}

module.exports = { handleGreeting };
