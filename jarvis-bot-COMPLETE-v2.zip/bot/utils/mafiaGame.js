'use strict';

/**
 * Mafia Game Engine — Fast Mode (~10 minutes max, 3 rounds)
 * Developed by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡
 *
 * Roles:   1 Mafia 😈 | 1 Doctor 💉 | 1 Police 👮 (6+ players) | Normal 👤
 * Flow:    JOIN (60s) → NIGHT (35s) → DAY RESULT → DISCUSS (2m) → VOTE (60s) → repeat ×3
 * Storage: all state in-memory; cleaned up on game end or timeout
 */

// ── Constants ─────────────────────────────────────────────────────────────────
const MIN_PLAYERS        = 5;
const MAX_PLAYERS        = 8;
const MAX_ROUNDS         = 3;
const JOIN_MS            = 60_000;    // 60 s join window
const NIGHT_MS           = 35_000;    // 35 s night phase
const DAY_PAUSE_MS       = 4_000;     // 4 s pause before discussion
const DISCUSSION_MS      = 120_000;   // 2 min discussion
const VOTE_MS            = 60_000;    // 60 s voting

const ROLES = {
  MAFIA:  { label: 'Mafia',  emoji: '😈', team: 'mafia'   },
  DOCTOR: { label: 'Doctor', emoji: '💉', team: 'village' },
  POLICE: { label: 'Police', emoji: '👮', team: 'village' },
  NORMAL: { label: 'Citizen',emoji: '👤', team: 'village' },
};

// ── Global state ──────────────────────────────────────────────────────────────
const games         = new Map(); // groupId → game object
const playerPhoneMap = new Map(); // phoneDigits → groupId  (DM lookup)

// ── Phone-number extractor (digits only, strips @server and :device) ──────────
const dig = (jid) => String(jid || '').split(':')[0].split('@')[0].replace(/\D/g, '');

// ── Shuffle helper ────────────────────────────────────────────────────────────
function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ── Add a managed timer (auto-removed on fire, clearable via game.timers) ─────
function addTimer(game, fn, ms) {
  let id;
  id = setTimeout(() => {
    game.timers.delete(id);
    fn().catch(e => console.error('[Mafia] timer error:', e.message));
  }, ms);
  game.timers.add(id);
  return id;
}

function clearTimers(game) {
  for (const t of game.timers) clearTimeout(t);
  game.timers.clear();
}

// ── Safe send helpers ─────────────────────────────────────────────────────────
async function sendGroup(game, text, extra = {}) {
  try {
    const mentions = extra.mentions || [...game.players.keys()];
    await game.sock.sendMessage(game.groupId, { text, mentions });
  } catch (e) { console.error('[Mafia] sendGroup error:', e.message); }
}

async function sendDM(game, jid, text) {
  try {
    const dmJid = dig(jid) + '@s.whatsapp.net';
    await game.sock.sendMessage(dmJid, { text });
  } catch (e) { console.error('[Mafia] DM error to', dig(jid), ':', e.message); }
}

// ── Build numbered alive-player list for display ──────────────────────────────
function buildAliveList(game) {
  let i = 1, out = '';
  for (const [jid, p] of game.players) {
    out += `${i++}. @${dig(jid)}${p.alive ? '' : ' ☠️'}\n`;
  }
  return out;
}

// ── Resolve a target from @mention or number arg ──────────────────────────────
// senderPhone: raw digits of the sender
// allowSelf: whether sender can target themselves (Doctor's save)
function resolveTarget(game, senderPhone, args, msg, allowSelf = false) {
  // Pass 1 — @mention in message context
  const ctx = msg.message?.extendedTextMessage?.contextInfo
           || msg.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo;
  for (const mJid of (ctx?.mentionedJid || [])) {
    const mPhone = dig(mJid);
    for (const [jid, info] of game.players) {
      if (info.alive && dig(jid) === mPhone && (allowSelf || dig(jid) !== senderPhone)) {
        return jid;
      }
    }
  }

  // Pass 2 — number from numbered list (excludes self unless allowSelf)
  const num = parseInt((args[0] || '').trim());
  if (!isNaN(num) && num >= 1) {
    const pool = [...game.players.entries()]
      .filter(([j, i]) => i.alive && (allowSelf || dig(j) !== senderPhone));
    if (num <= pool.length) return pool[num - 1][0];
  }

  return null;
}

// ── Role assignment ───────────────────────────────────────────────────────────
function assignRoles(jids) {
  const slots = ['MAFIA', 'DOCTOR'];
  if (jids.length >= 6) slots.push('POLICE');
  while (slots.length < jids.length) slots.push('NORMAL');
  const sRoles   = shuffle(slots);
  const sPlayers = shuffle([...jids]);
  const map = new Map();
  sPlayers.forEach((jid, i) => {
    map.set(jid, { role: sRoles[i], alive: true, hasActed: false });
  });
  return map;
}

// ── Win-condition check ───────────────────────────────────────────────────────
function checkWin(game) {
  const alive      = [...game.players.values()].filter(p => p.alive);
  const mafiaAlive = alive.filter(p => p.role === 'MAFIA').length;
  const villAlive  = alive.length - mafiaAlive;
  if (mafiaAlive === 0) return 'VILLAGE';
  if (mafiaAlive >= villAlive) return 'MAFIA';
  return null;
}

// ── Night-actors-done check ───────────────────────────────────────────────────
function nightActorsDone(game) {
  for (const [, p] of game.players) {
    if (!p.alive) continue;
    if ((p.role === 'MAFIA' || p.role === 'DOCTOR' || p.role === 'POLICE') && !p.hasActed) {
      return false;
    }
  }
  return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PHASE CONTROLLERS
// ═══════════════════════════════════════════════════════════════════════════════

// ── NIGHT ─────────────────────────────────────────────────────────────────────
async function startNight(game) {
  if (game.phase === 'GAME_OVER') return;
  game.round++;
  game.phase = 'NIGHT';
  game.nightActions = { kill: null, save: null };

  // Reset hasActed for active night roles
  for (const [, p] of game.players) {
    p.hasActed = (p.role === 'NORMAL' || !p.alive);
  }

  await sendGroup(game,
    `🌙 *Round ${game.round} — Night Phase!*\n\n` +
    `😴 Everyone goes to sleep...\n` +
    `📬 *Special roles: check your DMs now!*\n\n` +
    `⏱️ Night ends in *35 seconds*`
  );

  // Build alive-others list for DMs
  const aliveList = (excludeJid) =>
    [...game.players.entries()]
      .filter(([j, p]) => p.alive && (excludeJid == null || dig(j) !== dig(excludeJid)))
      .map(([j], idx) => `  ${idx + 1}. @${dig(j)}`)
      .join('\n');

  for (const [jid, p] of game.players) {
    if (!p.alive) continue;
    if (p.role === 'MAFIA') {
      await sendDM(game, jid,
        `😈 *MAFIA — Round ${game.round} Night*\n\n` +
        `Choose who to *eliminate*:\n${aliveList(jid)}\n\n` +
        `Reply: *.kill @user*  or  *.kill 1* (number)\n` +
        `⏱️ 35 seconds!`);
    } else if (p.role === 'DOCTOR') {
      await sendDM(game, jid,
        `💉 *DOCTOR — Round ${game.round} Night*\n\n` +
        `Choose who to *protect* (you can protect yourself):\n${aliveList(null)}\n\n` +
        `Reply: *.save @user*  or  *.save 1* (number)\n` +
        `⏱️ 35 seconds!`);
    } else if (p.role === 'POLICE') {
      await sendDM(game, jid,
        `👮 *POLICE — Round ${game.round} Night*\n\n` +
        `Choose someone to *investigate*:\n${aliveList(jid)}\n\n` +
        `Reply: *.check @user*  or  *.check 1* (number)\n` +
        `⏱️ 35 seconds!`);
    }
  }

  addTimer(game, () => processNight(game), NIGHT_MS);
}

// ── DAY RESULT ────────────────────────────────────────────────────────────────
async function processNight(game) {
  if (game.phase !== 'NIGHT') return;
  game.phase = 'DAY_RESULT';

  const { kill, save } = game.nightActions;

  let resultLine;
  let died = null;

  if (!kill) {
    resultLine = `😴 The Mafia couldn't decide — *Nobody died tonight!*`;
  } else if (kill === save || dig(kill) === dig(save || '')) {
    resultLine = `💊 The Doctor saved @${dig(kill)}!\n*Nobody died tonight!*`;
  } else {
    died = kill;
    const pInfo = game.players.get(died);
    if (pInfo) pInfo.alive = false;
    const r = ROLES[pInfo?.role || 'NORMAL'];
    resultLine =
      `💀 *@${dig(died)} was found dead!*\n` +
      `📋 They were a *${r.label} ${r.emoji}*`;
  }

  const mentions = died ? [died, ...game.players.keys()] : [...game.players.keys()];

  await game.sock.sendMessage(game.groupId, {
    text:
      `━━━━━━━━━━━━━━━━━\n` +
      `☀️ *DAY — Round ${game.round}*\n` +
      `━━━━━━━━━━━━━━━━━\n\n` +
      `${resultLine}\n\n` +
      `👥 *Alive Players:*\n${buildAliveList(game)}\n` +
      `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`,
    mentions: [...new Set(mentions)],
  }).catch(() => {});

  const win = checkWin(game);
  if (win) { addTimer(game, () => announceWinner(game, win), 3_000); return; }

  addTimer(game, () => startDiscussion(game), DAY_PAUSE_MS);
}

// ── DISCUSSION ────────────────────────────────────────────────────────────────
async function startDiscussion(game) {
  if (game.phase !== 'DAY_RESULT') return;
  game.phase = 'DISCUSSION';

  await sendGroup(game,
    `💬 *Discussion Phase — Round ${game.round}*\n\n` +
    `🗣️ You have *2 minutes* — talk, accuse, defend!\n` +
    `🗳️ Voting starts after discussion.\n\n` +
    `⏱️ *2:00 remaining*`
  );

  addTimer(game, async () => {
    if (game.phase !== 'DISCUSSION') return;
    await sendGroup(game, `⏱️ *1 minute left to discuss! Prepare your vote...*`);
  }, DISCUSSION_MS / 2);

  addTimer(game, async () => {
    if (game.phase !== 'DISCUSSION') return;
    await sendGroup(game, `⏱️ *30 seconds left! Voting is coming...*`);
  }, DISCUSSION_MS - 30_000);

  addTimer(game, () => startVoting(game), DISCUSSION_MS);
}

// ── VOTING ────────────────────────────────────────────────────────────────────
async function startVoting(game) {
  if (game.phase !== 'DISCUSSION') return;
  game.phase = 'VOTING';
  game.votes.clear();

  // Build numbered list (used for .vote 1, .vote 2…)
  game.voteList = [...game.players.entries()]
    .filter(([, p]) => p.alive)
    .map(([jid]) => jid);

  let listText = '';
  game.voteList.forEach((jid, i) => { listText += `${i + 1}. @${dig(jid)}\n`; });

  await sendGroup(game,
    `🗳️ *VOTING PHASE — Round ${game.round}*\n\n` +
    `Vote to *eliminate*:\n${listText}\n` +
    `Send: *.vote @user*  or  *.vote 1* (number)\n` +
    `⏱️ *60 seconds to vote!*\n\n` +
    `Only alive players can vote.`
  );

  addTimer(game, () => processVotes(game), VOTE_MS);
}

// ── VOTE RESULTS ──────────────────────────────────────────────────────────────
async function processVotes(game) {
  if (game.phase !== 'VOTING') return;
  game.phase = 'VOTE_RESULT';

  // Tally
  const tally = new Map();
  for (const target of game.votes.values()) {
    tally.set(target, (tally.get(target) || 0) + 1);
  }

  if (tally.size === 0) {
    await sendGroup(game, `🗳️ *No votes cast!* Nobody eliminated this round.`);
  } else {
    const maxV = Math.max(...tally.values());
    const tied = [...tally.entries()].filter(([, v]) => v === maxV).map(([k]) => k);
    const eliminated = tied[Math.floor(Math.random() * tied.length)];
    const elInfo = game.players.get(eliminated);
    if (elInfo) elInfo.alive = false;
    const r = ROLES[elInfo?.role || 'NORMAL'];

    let tallyText = '';
    for (const [jid, cnt] of [...tally.entries()].sort((a, b) => b[1] - a[1])) {
      tallyText += `• @${dig(jid)} — ${cnt} vote${cnt > 1 ? 's' : ''}\n`;
    }

    await game.sock.sendMessage(game.groupId, {
      text:
        `🗳️ *Voting Result — Round ${game.round}*\n\n` +
        `📊 *Tally:*\n${tallyText}\n` +
        `☠️ @${dig(eliminated)} has been *eliminated!*\n` +
        `📋 They were a *${r.label} ${r.emoji}*\n\n` +
        `👥 *Alive Players:*\n${buildAliveList(game)}`,
      mentions: [...game.players.keys()],
    }).catch(() => {});
  }

  // Win check
  const win = checkWin(game);
  if (win) { addTimer(game, () => announceWinner(game, win), 3_000); return; }

  // Max rounds reached
  if (game.round >= MAX_ROUNDS) {
    const finalWin = checkWin(game) || 'VILLAGE';
    addTimer(game, () => announceWinner(game, finalWin), 3_000);
    return;
  }

  addTimer(game, () => startNight(game), 5_000);
}

// ── WINNER ────────────────────────────────────────────────────────────────────
async function announceWinner(game, winner) {
  if (game.phase === 'GAME_OVER') return;

  const winLine = winner === 'MAFIA'
    ? `😈 *MAFIA WINS!*\nThe Mafia survived and took control of the village!`
    : `👤 *VILLAGERS WIN!*\nThe Mafia has been defeated! Peace is restored!`;

  let roleReveal = '';
  for (const [jid, p] of game.players) {
    const r = ROLES[p.role];
    roleReveal += `${p.alive ? '✅' : '☠️'} @${dig(jid)} — ${r.label} ${r.emoji}\n`;
  }

  await game.sock.sendMessage(game.groupId, {
    text:
      `🏆 *GAME OVER — ${MAX_ROUNDS} Rounds*\n\n` +
      `${winLine}\n\n` +
      `📋 *Full Role Reveal:*\n${roleReveal}\n` +
      `> *Developed by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡*`,
    mentions: [...game.players.keys()],
  }).catch(() => {});

  cleanStop(game.groupId);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  INTERNAL HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

function cleanStop(groupId) {
  const game = games.get(groupId);
  if (!game) return;
  clearTimers(game);
  game.phase = 'GAME_OVER';
  for (const jid of game.players.keys()) playerPhoneMap.delete(dig(jid));
  games.delete(groupId);
}

async function beginGame(game) {
  game.phase = 'STARTING';
  const jids = [...game.players.keys()];

  game.players  = assignRoles(jids);
  game.votes    = new Map();
  game.voteList = [];

  let listText = '';
  jids.forEach((j, i) => { listText += `${i + 1}. @${dig(j)}\n`; });

  await sendGroup(game,
    `✅ *Mafia Game Begins! (${jids.length} players)*\n\n` +
    `${listText}\n` +
    `📬 *Roles sent to your DMs — keep them SECRET!*\n` +
    `🌙 Night starts in *5 seconds...*`
  );

  // Send private role DMs
  for (const [jid, p] of game.players) {
    const r = ROLES[p.role];
    const tips = {
      MAFIA:  `Your goal: eliminate villagers each night using *.kill @user* in DM.`,
      DOCTOR: `Your goal: protect one person each night using *.save @user* in DM.`,
      POLICE: `Your goal: investigate one person each night using *.check @user* in DM.`,
      NORMAL: `Find the Mafia! Discuss and vote wisely.`,
    };
    await sendDM(game, jid,
      `🎭 *Your Secret Role:*\n\n` +
      `${r.emoji} *${r.label}*\n\n` +
      `${tips[p.role]}\n\n` +
      `🔒 *Do NOT reveal your role in the group!*\n` +
      `> ᴘᴏᴡᴇʀᴇᴅ ʙʏ ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡`
    );
  }

  addTimer(game, () => startNight(game), 5_000);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PUBLIC API
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Start a new Mafia game in a group.
 */
async function startGame(sock, groupId, starterJid) {
  if (games.has(groupId)) {
    return { ok: false, error: `A game is already running! Use *.mafia stop* to stop it.` };
  }

  const game = {
    sock,
    groupId,
    phase: 'JOINING',
    players: new Map(),
    round: 0,
    nightActions: { kill: null, save: null },
    votes: new Map(),
    voteList: [],
    timers: new Set(),
  };

  game.players.set(starterJid, { role: null, alive: true, hasActed: false });
  playerPhoneMap.set(dig(starterJid), groupId);
  games.set(groupId, game);

  await sendGroup(game,
    `🎮 *MAFIA GAME — Starting!*\n\n` +
    `👥 Need *5–8* players to play.\n\n` +
    `Type *.join* to enter!\n` +
    `⏱️ Auto-starts in *60 seconds* or when 8 players join.\n\n` +
    `*Joined (1/${MAX_PLAYERS}):*\n1. @${dig(starterJid)}\n\n` +
    `> *Developed by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡*`
  );

  // Auto-start/cancel timer after JOIN_MS
  addTimer(game, async () => {
    if (game.phase !== 'JOINING') return;
    const cnt = game.players.size;
    if (cnt < MIN_PLAYERS) {
      await sendGroup(game,
        `❌ *Game cancelled!*\n\n` +
        `Only *${cnt}* player${cnt !== 1 ? 's' : ''} joined — need at least *${MIN_PLAYERS}*.\n` +
        `Try again when more people are available!`
      );
      cleanStop(groupId);
      return;
    }
    await beginGame(game);
  }, JOIN_MS);

  return { ok: true };
}

/**
 * Join the current game in a group.
 */
async function joinGame(sock, groupId, playerJid) {
  const game = games.get(groupId);
  if (!game)                          return { ok: false, error: `No game running! Start one with *.mafia start*` };
  if (game.phase !== 'JOINING')       return { ok: false, error: `Game has already started! Wait for the next round.` };
  if (game.players.has(playerJid))    return { ok: false, error: `You're already in the game! 😄` };
  if (game.players.size >= MAX_PLAYERS) return { ok: false, error: `Game is full (${MAX_PLAYERS}/${MAX_PLAYERS})! Wait for the next one.` };
  if (playerPhoneMap.has(dig(playerJid))) return { ok: false, error: `You're already in a Mafia game in another group!` };

  game.players.set(playerJid, { role: null, alive: true, hasActed: false });
  playerPhoneMap.set(dig(playerJid), groupId);

  const cnt = game.players.size;
  let listText = '';
  [...game.players.keys()].forEach((j, i) => { listText += `${i + 1}. @${dig(j)}\n`; });

  await game.sock.sendMessage(groupId, {
    text:
      `✅ @${dig(playerJid)} *joined!* (${cnt}/${MAX_PLAYERS})\n\n` +
      `${listText}\n` +
      (cnt >= MAX_PLAYERS ? `🚀 *Max players! Starting now...*` : `Type *.join* to enter!`),
    mentions: [...game.players.keys()],
  }).catch(() => {});

  if (cnt >= MAX_PLAYERS) {
    clearTimers(game);
    await beginGame(game);
  }

  return { ok: true };
}

/**
 * Leave the game (join phase only).
 */
async function leaveGame(sock, groupId, playerJid) {
  const game = games.get(groupId);
  if (!game)                        return { ok: false, error: `No game running here.` };
  if (!game.players.has(playerJid)) return { ok: false, error: `You're not in this game!` };
  if (game.phase !== 'JOINING')     return { ok: false, error: `Can't leave after the game has started!` };

  game.players.delete(playerJid);
  playerPhoneMap.delete(dig(playerJid));

  await game.sock.sendMessage(groupId, {
    text: `👋 @${dig(playerJid)} *left* the game. (${game.players.size}/${MAX_PLAYERS})`,
    mentions: [playerJid],
  }).catch(() => {});

  return { ok: true };
}

/**
 * Mafia: kill someone during night phase (called from DM).
 */
async function nightKill(sock, senderJid, args, msg) {
  const groupId = playerPhoneMap.get(dig(senderJid));
  if (!groupId) return { ok: false, error: `You're not in any Mafia game.` };

  const game = games.get(groupId);
  if (!game || game.phase !== 'NIGHT') return { ok: false, error: `It's not night phase right now.` };

  const sPhone = dig(senderJid);
  let playerInfo = null;
  for (const [j, p] of game.players) {
    if (dig(j) === sPhone) { playerInfo = p; break; }
  }

  if (!playerInfo || !playerInfo.alive) return { ok: false, error: `You're eliminated or not in this game.` };
  if (playerInfo.role !== 'MAFIA')      return { ok: false, error: `Only the Mafia can use *.kill*` };
  if (playerInfo.hasActed)              return { ok: false, error: `You've already chosen your target tonight!` };

  const target = resolveTarget(game, sPhone, args, msg, false);
  if (!target) return { ok: false, error: `Invalid target.\nUse: *.kill @user*  or  *.kill 1* (number from the list in your DM)` };

  game.nightActions.kill = target;
  playerInfo.hasActed = true;

  await sendDM(game, senderJid,
    `✅ *Target locked:* @${dig(target)}\n🌙 Wait for dawn...`);

  if (nightActorsDone(game)) {
    clearTimers(game);
    await processNight(game);
  }

  return { ok: true };
}

/**
 * Doctor: save someone during night phase (called from DM).
 */
async function nightSave(sock, senderJid, args, msg) {
  const groupId = playerPhoneMap.get(dig(senderJid));
  if (!groupId) return { ok: false, error: `You're not in any Mafia game.` };

  const game = games.get(groupId);
  if (!game || game.phase !== 'NIGHT') return { ok: false, error: `It's not night phase right now.` };

  const sPhone = dig(senderJid);
  let playerInfo = null;
  for (const [j, p] of game.players) {
    if (dig(j) === sPhone) { playerInfo = p; break; }
  }

  if (!playerInfo || !playerInfo.alive) return { ok: false, error: `You're eliminated or not in this game.` };
  if (playerInfo.role !== 'DOCTOR')     return { ok: false, error: `Only the Doctor can use *.save*` };
  if (playerInfo.hasActed)              return { ok: false, error: `You've already chosen who to protect tonight!` };

  // Doctor CAN save themselves (allowSelf = true)
  const target = resolveTarget(game, sPhone, args, msg, true);
  if (!target) return { ok: false, error: `Invalid target.\nUse: *.save @user*  or  *.save 1* (number from the list in your DM)` };

  game.nightActions.save = target;
  playerInfo.hasActed = true;

  await sendDM(game, senderJid,
    `✅ *Protecting:* @${dig(target)} tonight.\n💊 Let's hope for the best...`);

  if (nightActorsDone(game)) {
    clearTimers(game);
    await processNight(game);
  }

  return { ok: true };
}

/**
 * Police: investigate someone during night phase (called from DM).
 */
async function nightCheck(sock, senderJid, args, msg) {
  const groupId = playerPhoneMap.get(dig(senderJid));
  if (!groupId) return { ok: false, error: `You're not in any Mafia game.` };

  const game = games.get(groupId);
  if (!game || game.phase !== 'NIGHT') return { ok: false, error: `It's not night phase right now.` };

  const sPhone = dig(senderJid);
  let playerInfo = null;
  for (const [j, p] of game.players) {
    if (dig(j) === sPhone) { playerInfo = p; break; }
  }

  if (!playerInfo || !playerInfo.alive) return { ok: false, error: `You're eliminated or not in this game.` };
  if (playerInfo.role !== 'POLICE')     return { ok: false, error: `Only the Police can use *.check*` };
  if (playerInfo.hasActed)              return { ok: false, error: `You've already investigated someone tonight!` };

  const target = resolveTarget(game, sPhone, args, msg, false);
  if (!target) return { ok: false, error: `Invalid target.\nUse: *.check @user*  or  *.check 1* (number from the list in your DM)` };

  const tInfo    = game.players.get(target);
  const isMafia  = tInfo?.role === 'MAFIA';
  playerInfo.hasActed = true;

  await sendDM(game, senderJid,
    `🔍 *Investigation Result:*\n\n` +
    `@${dig(target)} is...\n\n` +
    (isMafia
      ? `😈 *MAFIA!* Warn the group carefully in discussion!`
      : `✅ *Innocent!* Not a Mafia member.`)
  );

  if (nightActorsDone(game)) {
    clearTimers(game);
    await processNight(game);
  }

  return { ok: true };
}

/**
 * Cast a vote to eliminate someone (called from group).
 */
async function castVote(sock, groupId, senderJid, args, msg) {
  const game = games.get(groupId);
  if (!game || game.phase !== 'VOTING') return { ok: false, error: `Voting isn't open right now.` };

  const sPhone = dig(senderJid);
  let playerInfo = null;
  for (const [j, p] of game.players) {
    if (dig(j) === sPhone) { playerInfo = p; break; }
  }
  if (!playerInfo || !playerInfo.alive) return { ok: false, error: `Only alive players can vote!` };

  // Resolve target
  let target = null;
  const ctx = msg.message?.extendedTextMessage?.contextInfo
           || msg.message?.ephemeralMessage?.message?.extendedTextMessage?.contextInfo;
  for (const mJid of (ctx?.mentionedJid || [])) {
    const mPhone = dig(mJid);
    for (const [j, p] of game.players) {
      if (p.alive && dig(j) === mPhone) { target = j; break; }
    }
    if (target) break;
  }

  if (!target) {
    const num = parseInt((args[0] || '').trim());
    if (!isNaN(num) && num >= 1 && num <= game.voteList.length) {
      target = game.voteList[num - 1];
    }
  }

  if (!target)                          return { ok: false, error: `Invalid vote.\nUse: *.vote @user*  or  *.vote 1* (number from the voting list)` };
  if (dig(target) === sPhone)           return { ok: false, error: `You can't vote for yourself!` };
  if (!game.players.get(target)?.alive) return { ok: false, error: `That player is already eliminated!` };

  const changed = game.votes.has(senderJid);
  game.votes.set(senderJid, target);

  await game.sock.sendMessage(groupId, {
    text: `🗳️ @${dig(senderJid)} voted${changed ? ' (changed)' : ''} → @${dig(target)}`,
    mentions: [senderJid, target],
  }).catch(() => {});

  // Auto-process if all alive players voted
  const aliveCount = [...game.players.values()].filter(p => p.alive).length;
  if (game.votes.size >= aliveCount) {
    clearTimers(game);
    await processVotes(game);
  }

  return { ok: true };
}

/**
 * Force-stop the game (admin command).
 */
async function forceStop(sock, groupId) {
  const game = games.get(groupId);
  if (!game) return { ok: false, error: `No Mafia game is running in this group.` };

  await sendGroup(game,
    `🛑 *Mafia game forcefully stopped.*\n\n` +
    `> *Developed by ⚡ 𝐉𝐀𝐑𝐕𝐈𝐒 ⚡*`
  );

  cleanStop(groupId);
  return { ok: true };
}

/**
 * Get the game for a group, or null.
 */
function getGame(groupId) { return games.get(groupId) || null; }

module.exports = {
  startGame,
  joinGame,
  leaveGame,
  nightKill,
  nightSave,
  nightCheck,
  castVote,
  forceStop,
  getGame,
  games,
  playerPhoneMap,
};
