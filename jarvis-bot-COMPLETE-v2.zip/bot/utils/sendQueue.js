/**
 * Send Queue v2 — Per-JID rate-limited message queue
 *
 * WHY v1 was broken:
 *   The old implementation used a SINGLE global 1000 ms delay shared across
 *   all sessions and all JIDs. With 20 sessions each receiving messages:
 *     Session-1 sends → everyone waits 1 s → Session-2 can send → everyone
 *     waits 1 s → ...  This serialises the entire bot to ~1 msg/sec globally.
 *
 * v2 fixes:
 *   • Per-JID async queue — messages to different JIDs run in parallel
 *   • 600 ms minimum between messages to the SAME JID (WhatsApp safe limit)
 *   • 60 ms global anti-burst guard (prevents simultaneous socket floods)
 *   • Queue depth limit (20 per JID) — oldest dropped if limit exceeded
 *   • Idle queues auto-cleaned after 10 min of inactivity
 */

'use strict';

const PER_JID_DELAY_MS  = 200;  // min ms between messages to same JID (was 600)
const GLOBAL_DELAY_MS   = 30;   // min ms between ANY two sends (was 60)
const MAX_QUEUE_DEPTH   = 20;   // drop oldest if JID queue exceeds this
const QUEUE_IDLE_TTL_MS = 10 * 60 * 1000; // clean idle queues after 10 min
const CLEANUP_INTERVAL  = 15 * 60 * 1000; // run idle-queue cleanup every 15 min

// ── Per-JID queue ─────────────────────────────────────────────────────────────
class JidQueue {
  constructor(delay) {
    this.delay    = delay;
    this.lastSend = 0;
    this.queue    = [];
    this.running  = false;
  }

  enqueue(fn) {
    return new Promise((resolve, reject) => {
      // Drop oldest item if queue is full (protects against memory build-up)
      if (this.queue.length >= MAX_QUEUE_DEPTH) {
        const dropped = this.queue.shift();
        if (dropped) dropped.reject(new Error('sendQueue overflow — oldest message dropped'));
      }
      this.queue.push({ fn, resolve, reject });
      if (!this.running) this._drain();
    });
  }

  async _drain() {
    this.running = true;
    while (this.queue.length > 0) {
      const item = this.queue.shift();
      const wait = Math.max(0, this.lastSend + this.delay - Date.now());
      if (wait > 0) await new Promise(r => setTimeout(r, wait));
      this.lastSend = Date.now();
      try { item.resolve(await item.fn()); }
      catch (e) { item.reject(e); }
    }
    this.running = false;
  }

  isIdle() {
    return !this.running && this.queue.length === 0;
  }
}

// ── Socket patcher ────────────────────────────────────────────────────────────
function patchSocket(sock) {
  if (!sock || sock._sendQueuePatched) return;
  sock._sendQueuePatched = true;

  const originalSend = sock.sendMessage.bind(sock);
  const jidQueues    = new Map();  // jid → JidQueue
  let   _globalLast  = 0;

  // Periodic cleanup of idle JID queues (prevents Map growth over long uptime)
  const cleanupTimer = setInterval(() => {
    const now = Date.now();
    for (const [jid, q] of jidQueues.entries()) {
      if (q.isIdle() && now - q.lastSend > QUEUE_IDLE_TTL_MS) {
        jidQueues.delete(jid);
      }
    }
  }, CLEANUP_INTERVAL);
  cleanupTimer.unref?.();

  sock.sendMessage = async (jid, ...rest) => {
    // ── Global anti-burst: minimum gap between any two sends ────────────────
    const globalWait = Math.max(0, _globalLast + GLOBAL_DELAY_MS - Date.now());
    if (globalWait > 0) await new Promise(r => setTimeout(r, globalWait));
    _globalLast = Date.now();

    // ── Per-JID queue ────────────────────────────────────────────────────────
    if (!jidQueues.has(jid)) jidQueues.set(jid, new JidQueue(PER_JID_DELAY_MS));
    return jidQueues.get(jid).enqueue(() => originalSend(jid, ...rest));
  };
}

module.exports = { patchSocket };
