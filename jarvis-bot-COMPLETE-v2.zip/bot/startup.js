/**
 * WATCHDOG v3 — Production-grade bot supervisor
 *
 * Features:
 *  • Spawns index.js as a child process with optimised Node.js flags
 *  • Unlimited auto-restart with exponential back-off (3 s → 30 s cap)
 *  • Crash-loop guard: 5 crashes in 2 min → 60 s cool-down before next try
 *  • Forwards SIGTERM / SIGINT to child for graceful shutdown
 *  • Memory monitor: logs heap + OS RAM every 5 min
 *  • Keep-alive HTTP self-ping every 4 min (prevents Replit / hosting sleep)
 *  • PM2-compatible (PM2 handles outer restarts; watchdog handles inner ones)
 *
 * Restart codes from child:
 *   exit(0)  → clean stop (OS / Replit shutdown) — watchdog also stops
 *   exit(42) → intentional restart (.restart command) — immediate relaunch
 *   anything else → crash → watchdog restarts with back-off
 */

'use strict';

const { spawn } = require('child_process');
const http      = require('http');
const https     = require('https');
const os        = require('os');
const path      = require('path');
const fs        = require('fs');

// ── Config ────────────────────────────────────────────────────────────────────
const RESTART_EXIT_CODE   = 42;
const BASE_DELAY_MS       = 3_000;
const MAX_DELAY_MS        = 30_000;
const CRASH_WINDOW_MS     = 2 * 60 * 1000;  // 2-min window for loop detection
const CRASH_LOOP_THRESH   = 5;               // 5 crashes in window = loop
const CRASH_LOOP_WAIT_MS  = 60_000;          // cool-down in crash loop
const PANEL_PORT          = process.env.PORT || 5000;
const KEEP_ALIVE_MS       = 3 * 60 * 1000;  // ping every 3 min (was 4)
const MEM_LOG_MS          = 5 * 60 * 1000;  // log RAM every 5 min

// Replit public domain — must be pinged externally to prevent container sleep
const REPLIT_DOMAIN = process.env.REPLIT_DEV_DOMAIN || process.env.REPLIT_DOMAIN || null;

// Ensure logs/ directory exists so PM2 log files can be written
try { fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true }); } catch (_) {}

// Node.js flags passed to child process
const NODE_FLAGS = [
  '--max-old-space-size=1536',  // 1.5 GB heap cap
  '--expose-gc',                 // allow manual GC from code
  '--optimize-for-size',         // trade speed for lower memory
];

let restartCount  = 0;
let recentCrashes = [];
let child         = null;

// ── Memory monitor ───────────────────────────────────────────────────────────
setInterval(() => {
  try {
    const m      = process.memoryUsage();
    const freeMB = Math.round(os.freemem()   / 1024 / 1024);
    const totMB  = Math.round(os.totalmem()  / 1024 / 1024);
    console.log(
      `[WATCHDOG] 📊 Heap: ${Math.round(m.heapUsed/1024/1024)}/${Math.round(m.heapTotal/1024/1024)} MB` +
      ` | RSS: ${Math.round(m.rss/1024/1024)} MB` +
      ` | System free: ${freeMB}/${totMB} MB` +
      ` | Restarts: ${restartCount - 1}`
    );
  } catch (_) {}
}, MEM_LOG_MS).unref();

// ── Keep-alive self-ping (prevents Replit / free-hosting from sleeping) ───────
// TWO pings every cycle:
//  1. Localhost — keeps the local Express server warm
//  2. External Replit URL — the ONLY ping that actually prevents container sleep
//     (Replit ignores internal 127.0.0.1 traffic for sleep detection)
setInterval(() => {
  // Ping 1: localhost
  try {
    const req = http.get({
      hostname: '127.0.0.1',
      port    : PANEL_PORT,
      path    : '/api/status',
      timeout : 8000,
    }, (res) => res.resume());
    req.on('error', () => {});
    req.on('timeout', () => req.destroy());
  } catch (_) {}

  // Ping 2: external public URL (critical on Replit)
  if (REPLIT_DOMAIN) {
    try {
      const req2 = https.get(
        `https://${REPLIT_DOMAIN}/api/status`,
        { timeout: 10000 },
        (res) => res.resume()
      );
      req2.on('error', () => {});
      req2.on('timeout', () => req2.destroy());
    } catch (_) {}
  }
}, KEEP_ALIVE_MS).unref();

// ── Crash-loop detector ───────────────────────────────────────────────────────
function isCrashLoop() {
  const now = Date.now();
  recentCrashes = recentCrashes.filter(t => now - t < CRASH_WINDOW_MS);
  recentCrashes.push(now);
  return recentCrashes.length >= CRASH_LOOP_THRESH;
}

// ── Exponential back-off delay ────────────────────────────────────────────────
function getDelay(attempt) {
  return Math.min(BASE_DELAY_MS * Math.pow(1.5, Math.max(0, attempt - 1)), MAX_DELAY_MS);
}

// ── Kill any stale process holding the panel port (prevents EADDRINUSE loops) ─
function freePort() {
  try {
    // SIGKILL whatever has port 5000 open so our child can bind cleanly
    require('child_process').execSync(
      `fuser -k ${PANEL_PORT}/tcp 2>/dev/null || true`,
      { timeout: 3000, stdio: 'ignore' }
    );
  } catch (_) {}
}

// ── Main launcher ─────────────────────────────────────────────────────────────
function launchBot() {
  restartCount++;
  if (restartCount === 1) {
    console.log('[WATCHDOG] 🚀 Launching bot...');
  } else {
    console.log(`\n[WATCHDOG] 🔄 Restart #${restartCount - 1} — bot coming back up...\n`);
  }

  // Free port before every launch so EADDRINUSE is impossible
  freePort();

  child = spawn(process.execPath, [...NODE_FLAGS, 'index.js'], {
    stdio: 'inherit',
    env  : { ...process.env, NODE_ENV: process.env.NODE_ENV || 'production' },
    cwd  : __dirname,
  });

  child.on('exit', (code, signal) => {
    child = null;

    // ── Clean stop ──────────────────────────────────────────────────────────
    if (code === 0) {
      console.log('[WATCHDOG] ✅ Bot exited cleanly (exit 0). Watchdog stopping.');
      process.exit(0);
      return;
    }

    // ── Intentional restart (.restart command) ──────────────────────────────
    if (code === RESTART_EXIT_CODE) {
      console.log('[WATCHDOG] 🔁 Intentional restart — relaunching immediately...');
      recentCrashes = [];
      setImmediate(launchBot);
      return;
    }

    // ── Crash ───────────────────────────────────────────────────────────────
    const loop  = isCrashLoop();
    const delay = loop ? CRASH_LOOP_WAIT_MS : getDelay(restartCount);

    console.log(
      `\n[WATCHDOG] ⚠️  Crash (code=${code ?? 'null'}, signal=${signal ?? 'none'}).` +
      `${loop ? ' 🔥 Crash-loop detected!' : ''}` +
      ` Restarting in ${(delay / 1000).toFixed(0)}s...\n`
    );

    const t = setTimeout(launchBot, delay);
    t.unref?.();
  });

  child.on('error', (err) => {
    console.error('[WATCHDOG] ❌ Failed to spawn bot process:', err.message);
    child = null;
    const t = setTimeout(launchBot, BASE_DELAY_MS);
    t.unref?.();
  });
}

// ── Forward signals to child for graceful shutdown ────────────────────────────
function forwardSignal(sig) {
  if (child && !child.killed) {
    try { child.kill(sig); } catch (_) {}
  }
}

process.on('SIGTERM', () => {
  console.log('[WATCHDOG] 🛑 SIGTERM received — forwarding to bot...');
  forwardSignal('SIGTERM');
  setTimeout(() => process.exit(0), 8000);
});

process.on('SIGINT', () => {
  console.log('[WATCHDOG] 🛑 SIGINT received — forwarding to bot...');
  forwardSignal('SIGINT');
  setTimeout(() => process.exit(0), 5000);
});

// Watchdog must never crash — absorb all errors
process.on('uncaughtException',  (err) => console.error('[WATCHDOG] Uncaught exception:', err.message));
process.on('unhandledRejection', (r)   => console.error('[WATCHDOG] Unhandled rejection:', r?.message || r));

// ── Boot ──────────────────────────────────────────────────────────────────────
launchBot();
